<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
        body {
            margin: 0;
            font-family: Arial, sans-serif;
        }

        nav {
            position: fixed;
            background-color: #0000008a;
            display: flex;
            flex-direction: row;
            justify-content: space-between;
            color: white;
            height: 64px;
            width: 100%;
            top: 0;
            left: 0;
            z-index: 1000;
        }

        .image-container {
            position: relative;
            perspective: 1000px; /* Control the level of 3D effect */
        }

        .image-3d {
            width: 133px; /* Ensure width is set */
            height: 133px; /* Ensure height is set */
            margin-top: -27px;
            cursor: pointer;
            margin-left: 20px;
            transform-style: preserve-3d;
            animation: flip 7s infinite ease-in-out; /* 13s: 3s for flipping + 10s pause */
            position: relative;
            z-index: 1; /* Ensure the shine effect is below the image */
            filter: drop-shadow(0 0 5px rgba(255, 255, 255, 0.5)); /* Add a subtle shadow */
           
        }

        

        @keyframes flip {
            0% {
                transform: rotateY(0deg);
            }
            40% {
                transform: rotateY(180deg); /* 3s of the 13s total duration */
            }
            40% {
                transform: rotateY(360deg); /* 6s of the 13s total duration */
            }
            100% {
                transform: rotateY(360deg); /* Remain still for the last 7s */
            }
        }

       
        nav img {
            width: 133px;
            height: 133px;
            margin-top: -27px;
            cursor: pointer;
            margin-left: 20px;
        }

        .navigation {
            display: flex;
            justify-content: flex-end;
            align-items: center;
            margin-right: 20px;
        }

        nav .navigation ul {
            display: flex;
            justify-content: flex-end;
            align-items: center;
            list-style: none;
            padding: 0;
            margin: 0;
        }

        nav .navigation ul li {
            margin: 0 15px;
        }

        nav .navigation ul li a {
            text-decoration: none;
            color: white;
            font-size: 16px;
            padding: 5px;
            transition: 0.3s;
        }

        nav .navigation ul li a:hover {
            color: black;
            background-color: white;
            border-radius: 2px;
        }

        .menu-toggle {
            display: none;
            flex-direction: column;
            justify-content: space-around;
            width: 30px;
            height: 30px;
            background: transparent;
            border: none;
            cursor: pointer;
            margin-right: 20px;
            position: relative;
            z-index: 1001;
            border-radius: 4px;
            padding: 3px;
            padding-left: 5px;
            padding-right: 5px;
            margin-top: 16px;
        }

        .menu-toggle .bar {
            width: 100%;
            height: 2.5px;
            background-color: white;
            transition: background-color 0.3s;
        }

        .menu-toggle.active {
            background-color: gray;
        }

        .dropdown {
            display: none;
            flex-direction: column;
            background-color: gray;
            position: absolute;
            top: 64px;
            right: 20px;
            width: auto;
            text-align: center;
            z-index: 1000;
            padding: 10px;
            border-radius: 5px;
            margin-top: -17px;
        }

        .dropdown a {
            color: white;
            padding: 10px;
            text-decoration: none;
            display: block;
            transition: background-color 0.3s;
        }

        .dropdown a:hover {
            background-color: white;
            color: black;
            border-radius: 2px;
        }

        .dropdown.active {
            display: flex;
            position: fixed;
        }

        @media (max-width: 768px) {
            .navigation {
                display: none;
            }

            .menu-toggle {
                display: flex;
            }
        }
    </style>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" integrity="sha512-DTOQO9RWCH3ppGqcWaEA1BIZOC6xxalwEsw9c2QQeAIftl+Vegovlnee1c9QX4TctnWMn13TZye+giMm8e2LwA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
</head>
<body>
<nav>
    <!-- <img src="./images/logon3.png" alt="logo photo"> -->
    <div class="image-container">
        <img src="./images/logon3.png" alt="3D Image" class="image-3d">
        
    </div>
    <button class="menu-toggle">
        <div class="bar"></div>
        <div class="bar"></div>
        <div class="bar"></div>
    </button>
    <div class="navigation">
        <ul>
            <li><a href="unipulse.php">Home</a></li>
            <li><a href="about us.php">About Us</a></li>
            <li><a href="notices.php">Notices</a></li>
            <!-- <li><a href="uni2.php">University</a></li> -->
            <?php
            if(isset($_SESSION['loggedin']) && $_SESSION['loggedin'] === true) {
                echo '<li><a href="logout.php">Logout</a></li>';
            } else {
                echo '<li><a href="login.php">Login</a></li>';
            }
            ?>
        </ul>
    </div>
</nav>

<div class="dropdown" id="dropdown-menu">
    <a href="unipulse.php">Home</a>
    <a href="about us.php">About Us</a>
    <a href="notices.php">Notices</a>
    <a href="uni2.php">University</a>
    <?php
    if(isset($_SESSION['loggedin']) && $_SESSION['loggedin'] === true) {
        echo '<a href="logout.php">Logout</a>';
    } else {
        echo '<a href="login.php">Login</a>';
    }
    ?>
</div>

<script>
   document.querySelector('.image-container').addEventListener('mousemove', function(e) {
            const image = document.querySelector('.image-3d');
            const xAxis = (window.innerWidth / 2 - e.pageX) / 25;
            const yAxis = (window.innerHeight / 2 - e.pageY) / 25;
            image.style.transform = `rotateY(${xAxis}deg) rotateX(${yAxis}deg)`;
        });

        document.querySelector('.image-container').addEventListener('mouseleave', function() {
            const image = document.querySelector('.image-3d');
            image.style.transform = 'rotateY(0deg) rotateX(0deg)';
        });

    document.querySelector('.menu-toggle').addEventListener('click', function() {
        this.classList.toggle('active');
        document.getElementById('dropdown-menu').classList.toggle('active');
    });
</script>
</body>
</html>

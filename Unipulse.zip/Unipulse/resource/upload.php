<?php
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $subject = $_POST['subject'];
    $part = $_POST['part'];
    $chapter = $_POST['chapter'];
    $pdf = $_FILES['pdf'];
    $pdf_title = $_POST['pdf_title'];
    $video = $_POST['video'];
    $video_title = $_POST['video_title'];

    $uploads_dir = 'uploads';
    $resource = [];

    if ($pdf['error'] == UPLOAD_ERR_OK) {
        $tmp_name = $pdf['tmp_name'];
        $name = basename($pdf['name']);
        move_uploaded_file($tmp_name, "$uploads_dir/$name");
        $resource['pdf'] = $name;
        $resource['pdf_title'] = $pdf_title;
    }

    if (!empty($video)) {
        $resource['video'] = $video;
        $resource['video_title'] = $video_title;
    }

    $data_file = "resources/$subject.json";
    $data = json_decode(file_get_contents($data_file), true);
    
    // Add the new resource to the data
    $data[$part][$chapter][] = $resource;
    
    // Sort parts and chapters numerically
    ksort($data, SORT_NUMERIC);
    foreach ($data as $part_key => $chapters) {
        ksort($chapters, SORT_NUMERIC);
        $data[$part_key] = $chapters;
    }

    // Save the sorted data back to the JSON file
    file_put_contents($data_file, json_encode($data, JSON_PRETTY_PRINT));

    header('Location: admin.php');
}
?>

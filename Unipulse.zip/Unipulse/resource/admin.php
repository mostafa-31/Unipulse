<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin - Upload Resources</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f0f0f0;
        }
        header {
            background-color: #333;
            color: #fff;
            text-align: center;
            padding: 1em 0;
        }
        main {
            padding: 2em;
        }
        .form-group {
            margin-bottom: 1em;
        }
        label {
            display: block;
            margin-bottom: 0.5em;
            color: #333;
        }
        input[type="text"],
        input[type="number"],
        input[type="file"],
        input[type="url"],
        select {
            width: 100%;
            padding: 0.5em;
            margin-bottom: 1em;
            border-radius: 5px;
            border: 1px solid #ccc;
        }
        button {
            padding: 0.7em 1.5em;
            background-color: #333;
            color: #fff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        button:hover {
            background-color: #555;
        }
    </style>
</head>
<body>
    <header>
        <h1>Admin - Upload Resources</h1>
    </header>
    <main>
        <form action="upload.php" method="post" enctype="multipart/form-data">
            <div class="form-group">
                <label for="subject">Subject:</label>
                <select name="subject" id="subject">
                    <option value="physics">Physics</option>
                    <option value="chemistry">Chemistry</option>
                    <option value="math">Math</option>
                </select>
            </div>
            <div class="form-group">
                <label for="part">Part:</label>
                <select name="part" id="part">
                    <option value="1">1</option>
                    <option value="2">2</option>
                </select>
            </div>
            <div class="form-group">
                <label for="chapter">Chapter:</label>
                <input type="number" name="chapter" id="chapter" min="1" max="10">
            </div>
            <div class="form-group">
                <label for="pdf">PDF:</label>
                <input type="file" name="pdf" id="pdf">
            </div>
            <div class="form-group">
                <label for="pdf_title">PDF Title:</label>
                <input type="text" name="pdf_title" id="pdf_title">
            </div>
            <div class="form-group">
                <label for="video">Video URL:</label>
                <input type="url" name="video" id="video">
            </div>
            <div class="form-group">
                <label for="video_title">Video Title:</label>
                <input type="text" name="video_title" id="video_title">
            </div>
            <button type="submit">Upload</button>
        </form>
    </main>
</body>
</html>

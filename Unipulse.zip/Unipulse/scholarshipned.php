<?php
    session_start();
    if(!isset($_SESSION['loggedin']) || isset($_SESSION['loggedin'])!=true){
        header("location:login.php");
        exit;
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>scholarship in UK</title>
    <!-- <link rel="stylesheet" href="scholarshipned.css"> -->
     <style>
        *{
    padding: 0;
    margin: 0;
  
}
body{
    
    background-color: #7bcd6b57;
}
.img{
    background-image:  linear-gradient(to top, rgba(1, 1, 5, 0.853),rgba(2, 2, 12, 0.233)),url(images/Picture2.jpg); 
    width: 70%;
    height: 400px;
    background-repeat: no-repeat;
    background-size: cover;
  margin-top: 98px;
  margin-left: 250px;
  border-radius: 15px;
  
}
.imagtitle{
    padding-top: 375px;padding-left: 21px;
   color: whitesmoke;
   font-family: 'Franklin Gothic Medium', 'Arial Narrow', Arial, sans-serif;
  
}
.bar{
    height: 50px;
    width: 500px;
    background-color: rgb(255, 162, 0);
    margin-top: 50px;
    margin-left: 300px;
    margin-right: 300px;
    
    border-radius: 5px;
    font-family: 'Gill Sans', 'Gill Sans MT', Calibri, 'Trebuchet MS', sans-serif;
    

}
.bar p{
    margin-left: 18px;padding-top: 14px;
   
}
.bar p a{
    text-decoration: none;
    color: black;
}
.bar:hover{
    background-color: rgba(255, 162, 0, 0.684);
}
.con1 {
    margin-top: 50px;
    margin-left: 300px;
    margin-right: 300px;
    font-family: Cambria, Cochin, Georgia, Times, 'Times New Roman', serif;
    color: rgb(39, 37, 37);
    line-height: 1.5;
    font-size: 1.1rem;
}
.con2{
    margin-top: 50px;
    margin-left: 300px;
    margin-right: 300px;
    font-family: Cambria, Cochin, Georgia, Times, 'Times New Roman', serif;
    color: rgb(39, 37, 37);
    font-size: 2.5rem;
    line-height: 1.5;
    
}
.con3{
    margin-top: 50px;
    margin-left: 300px;
    margin-right: 300px;
    font-family: Georgia, 'Times New Roman', Times, serif;
    color: rgb(39, 37, 37);
    line-height: 1.5;
   padding-bottom: 30px;

}
.con3 a{
    text-decoration: none;
    line-height: 1.5;
   /* padding-bottom: 30px; */
    color: rgba(31, 6, 251, 0.836);
}
.con3 a:hover{
    
    color: rgb(31, 6, 251);
}

     </style>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.2/css/all.min.css"/>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" integrity="sha512-DTOQO9RWCH3ppGqcWaEA1BIZOC6xxalwEsw9c2QQeAIftl+Vegovlnee1c9QX4TctnWMn13TZye+giMm8e2LwA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
</head>
<body>
    <?php include 'header.php';?>
    
    <div class="img">
        <div class="imagtitle">Scholarships to Study in the Netherland </div>
    </div>
<div class="bar">
    <p> <a href="std_ned_study.php">Find out all you need to know about studying in the Netherlands!</a></p>
</div>
    <div class="con1">
    <p>The Netherlands (formerly also known as Holland) was one of the first non-native English speaking countries to offer courses taught in English to international students. The people of the Netherlands have a long standing reputation for being very tolerant and open minded, meaning that you will find yourself in a welcoming and diverse environment.
</p>
<br>
       <p>
        Below you’ll find a selection of scholarships to study in the UK, some funded by the Netherland government, some by external organizations, and many by individual Netherland universities.</p>
    </div>
    <div class="con2">
        Government-funded scholarships for international students
    </div>
    <div class="con3">
        <ul>
            <li><a href="https://www.studyinnl.org/finances/nl-scholarship">NL Scholarship (formerly Holland Scholarship) </a> The NL Scholarship is meant for international students from outside the European Economic Area (EEA) who want to pursue their bachelor’s or master’s degrees in the Netherlands.</li> <br> <br>
            <li><a href="https://www.wur.nl/en/education-programmes/bachelor/practical-information/scholarships/nl-scholarship.htm">Wageningen University & Research NL Scholarship </a>  Wageningen University offers the NL Scholarship for international bachelor students.The scholarship is made available by Wageningen University & Research, the Association of Universities in the Netherlands (VSNU), Nuffic, and the Netherlands Association of Universities of Applied Sciences.</li> <br> <br>
            <li><a href="http://www.marshallscholarship.org/">Marshall Scholarships </a>  – Postgraduate scholarships for  students showing academic merit, leadership potential and ambassadorial potential to study in the Netherlands. Excludes MBAs and certain courses.</li>
        </ul>
    </div>
    <div class="con2">
        Non-governmental scholarships for international students
    </div>
    <div class="con3">
        <ul>
            <li><a href="https://www.erasmusplus.nl/english">Erasmus+ </a>   Erasmus+ provides various funding opportunities for education and training.The program is run both centrally by the European Commission’s Education, Audiovisual and Culture Executive Agency (EACEA) and decentrally by Dutch National Agencies.</li> <br> <br>
            <li><a href="https://tneg.nl/publications/find-your-scholarship/">Grantfinder </a>  Grantfinder is a portal where you can search for scholarships based on your criteria.Additionally, check funding possibilities at the Dutch Embassy in your home country or your institution’s international office.</li> <br> <br>
            <li><a href="https://surfshark.com/student-discount">Surfshark Privacy and Security Scholarship</a>A $2,000 prize is available to a student currently enrolled in  any study destination as a high school, undergraduate or graduate student. You will need to submit an essay to apply and the scholarship is open to all nationalities. </li><br> <br>
            <li><a href="https://royalsociety.org/grants/">The Royal Society Grants</a>Various grants and fellowships are available for talented researchers in the Netherlands and beyond </li>

        </ul>
    </div>
    
   
        
    <?php include 'footer.php';?>
</body>
</html>
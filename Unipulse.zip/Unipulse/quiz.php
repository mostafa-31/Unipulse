<?php
session_start();
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $selected_subjects = $_POST['subjects'];
    if (empty($selected_subjects)) {
        echo "<p>Please select at least one subject.</p>";
        exit;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Quiz</title>
   <style>
      .quiz-container {
         margin: 20px auto;
         width: 60%;
      }
      .timer {
         position: fixed;
         top: 10px;
         right: 10px;
         background: #f1c40f;
         padding: 10px;
         font-size: 20px;
         font-weight: bold;
      }
   </style>
   <script>
      // Timer functionality
      let timeLeft = 30 * 60; // 30 minutes in seconds
      const timerElement = document.getElementById('timer');

      function startTimer() {
         const timer = setInterval(function() {
            const minutes = Math.floor(timeLeft / 60);
            const seconds = timeLeft % 60;
            timerElement.textContent = `Time Left: ${minutes}m ${seconds}s`;

            timeLeft--;
            if (timeLeft < 0) {
               clearInterval(timer);
               document.getElementById('quizForm').submit(); // Auto-submit when time is over
            }
         }, 1000);
      }

      window.onload = startTimer;
   </script>
</head>
<body>
   <div class="timer" id="timer">Time Left: 30m 0s</div>
   <div class="quiz-container">
      <h2>Quiz</h2>
      <form id="quizForm" action="quiz_results.php" method="POST">
         <?php
         // Generate random 30 questions based on selected subjects
         foreach ($selected_subjects as $subject) {
             $filePath = "./new folder/resources/$subject_questions.json";
             if (file_exists($filePath)) {
                 $data = file_get_contents($filePath);
                 $questions = json_decode($data, true);

                 // Shuffle questions to randomize their order
                 shuffle($questions);

                 // Display 30 questions
                 for ($i = 0; $i < min(30, count($questions)); $i++) {
                     echo "<p>Question " . ($i+1) . ": {$questions[$i]['question']}</p>";
                     foreach ($questions[$i]['options'] as $option) {
                         echo "<label><input type='radio' name='q{$i}' value='$option'> $option</label><br>";
                     }
                 }
             } else {
                 echo "<p>No questions available for $subject.</p>";
             }
         }
         ?>
         <button type="submit">Submit Quiz</button>
      </form>
   </div>
</body>
</html>

<?php
    session_start();
    if(!isset($_SESSION['loggedin']) || isset($_SESSION['loggedin'])!=true){
        header("location:login.php");
        exit;
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Scholarship</title>
    <!-- <link rel="stylesheet" href="scholar2a.css"> -->
     <style>
      *{
    padding: 0;
    margin: 0;
  
}
.back{
    background-image: url(https://www.studyinfinland.fi/sites/default/files/styles/hero/public/2023-11/Investment-Scholarships-16by6ratio-notext_0.jpg?h=e0d9a4bb&itok=yRWQlN0xs);
    width: 100%;
height: 100vh;
background-size: cover;
background-position: center;
display: flex;
flex-direction: column;
justify-content: start;
align-items: start;
text-align: start;
}
.back h2{
    font-family: serif;
    color: bisque;
    margin-left: 400px;
  margin-top: 248px;
    font-size: 6rem;
}
.contenti h2{
    font-family: Arial, sans-serif;
    text-align: center;
    font-size: 2.5rem;
    color: #333;
    margin-bottom: 2rem;
  margin-top: 80px;
  font-weight: 69px;
}
.contenti  .scholarship{
    color:  rgb(255, 162, 0);
}
.content2d p{
    font-family: 'Franklin Gothic Medium', 'Arial Narrow', Arial, sans-serif;
    text-align: center;
    margin-top: 10px;
    font-size: 1.2rem;
    letter-spacing: .5px;
}
 .agem {
    border-radius: 10px;
    display:grid;
    grid-template-columns: repeat(auto-fit,minmax(300px,auto));
    grid-gap:20px;
    justify-content: center;
    margin-top:20px;
}
 .agem .cardy {
    margin-top: 60px;
 height:100px;
 width:250px;
 padding:10px;
 font-family: 'Lucida Sans', 'Lucida Sans Regular', 'Lucida Grande', 'Lucida Sans Unicode', Geneva, Verdana, sans-serif;
color: rgb(70, 70, 80);
text-align: center;
border: 1px solid #333;
/* border: 2px solid rgba(0, 0, 255, 0.416); */
box-shadow: 3px 3px 4px #333;



}
 .agem .cardy:hover{
    cursor: pointer;
    /* box-shadow:5px 5px 10px #dfdcdc; */
    color: darkorange;
    transition-duration: .4s;
    transform: scale(1.1)  translateY(-10px);
}
.head2a h2{
   
    text-align: center;
    font-family: Arial, sans-serif;
    text-align: center;
    font-size: 2.5rem;
    color: #333;
    margin-bottom: 2rem;
  margin-top: 100px;
  font-weight: 69px;
}
.contc{
    border-radius: 10px;
    display:grid;
    grid-template-columns: repeat(auto-fit,minmax(300px,auto));
    grid-gap:20px;
    justify-content: center;
    margin-top:20px;
}
.contc .cardy{
    margin-top: 60px;
    height:200px;
    width:300px;
    padding:10px;
    font-family: 'Lucida Sans', 'Lucida Sans Regular', 'Lucida Grande', 'Lucida Sans Unicode', Geneva, Verdana, sans-serif;
   color: rgb(70, 70, 80);
   text-align: bottom;
   border: 1px solid #333;
   /* border: 2px solid rgba(0, 0, 255, 0.416); */
   box-shadow: 3px 3px 4px #333;
   margin-bottom: 50px;
   
   
}
.contc .cardy a{
    text-decoration: none;
}
.contc .cardy span{
    color: rgba(119, 119, 136, 0.596);
    
}
.contc .cardy:hover{
    cursor: pointer;
    /* box-shadow:5px 5px 10px #333; */
    color: darkorange;
    transition-duration: .4s;
    transform: scale(1.1)  translateY(-10px);
}
     </style>
    <link rel="stylesheet" href="style.css" >
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.2/css/all.min.css"/>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" integrity="sha512-DTOQO9RWCH3ppGqcWaEA1BIZOC6xxalwEsw9c2QQeAIftl+Vegovlnee1c9QX4TctnWMn13TZye+giMm8e2LwA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
</head>
<body>
    
      
      <?php include 'header.php';?>
    
    <section>
      <div class="back">
        <h2> SCHOLARSHIPS </h2>
      </div>
      <div class="contenti">
        <h2> The Latest <span class="scholarship">SCHOLARSHIPS </span> </h2>
      </div>
      <div class="content2d">
        <p>UniPulse offer a range of options for scholarships both for bachelor's and master's level University students.</p>
      </div>
      <div class="agem">
        <div class="cardy">
         
          <h3>Admission test Merit Scholarship</h3>
        </div>
        
        <div class="cardy">
          
          <h3>Prime Minister's Excelence Scholarship </h3>
        </div>
        <div class="cardy">
         
          <h3>Alumni's Fund Scholarship</h3>
        </div>
      </div>
        <div class="head2a">
          <h2>Scholarships in Most Popular Countries </h2>
          <div class="contc">
            <div class="cardy">
            <a href="scholarshipger.php"> <img src="https://www.studying-in-germany.org/wp-content/uploads/2013/11/most-employable-degrees-in-germany.jpg" alt="" style=" width: 302px;
  height: 172px;">
              <h3><span class="light">Scholarship in</span> Germany</h3></a>
            </div>
            
            <div class="cardy">
            <a href="scholarshipned.php">
              <img src="https://images.ctfassets.net/szez98lehkfm/3CqIjJrns20Mf299rrjyll/8f351a77b796a53ef63069ef8e1bf826/MyIC_Article134049?fm=webp" alt="" style=" width: 302px;
  height: 172px;">
              <h3><span class="light">Scholarship in</span> Netherland</h3></a>
            </div>
            <div class="cardy">
              <a href="scholarshipuk.php">
              <img src="https://images.ctfassets.net/szez98lehkfm/4GHHOnp8bESWzChgr2wA1A/d431e6e754e076426804e737138a575f/MyIC_Article_90422?w=1106&h=622&fm=webp&fit=fill" alt=""style=" width: 302px;
  height: 172px;">
              <h3><span class="light">Scholarship in</span> UK</h3> </a>
            </div>
            <div class="cardy">
            <a href="scholarshipusa.php">
              <img src="https://admissionsight.com/wp-content/uploads/2023/01/shutterstock_174437531-1.jpg" alt="" style=" width: 302px;
  height: 172px;">
              <h3><span class="light">Scholarship in</span>  USA</h3></a>
            </div>
        </div>
    </section>

    <?php include 'footer.php';?>
    
     
     
</body>

</html>
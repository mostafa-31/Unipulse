<?php
session_start();
if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] != true) {
    header("location: login.php");
    exit;
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    require 'db_config.php';

    $notice_name = $_POST['notice_name'];
    $publication_date = $_POST['publication_date'];
    $pdf_file = $_FILES['pdf_file'];

    // Check if the file is a valid PDF
    if ($pdf_file['type'] != 'application/pdf') {
        die("Only PDF files are allowed.");
    }

    // Define the upload directory and file path
    $upload_dir = 'uploads/';
    if (!is_dir($upload_dir)) {
        mkdir($upload_dir, 0777, true);
    }
    $file_path = $upload_dir . basename($pdf_file['name']);

    // Move the uploaded file to the designated directory
    if (move_uploaded_file($pdf_file['tmp_name'], $file_path)) {
        // Insert notification details into the database
        $stmt = $conn->prepare("INSERT INTO notifications (notice_name, publication_date, pdf_path) VALUES (?, ?, ?)");
        $stmt->bind_param("sss", $notice_name, $publication_date, $file_path);

        if ($stmt->execute()) {
            echo "Notice added successfully!";
        } else {
            echo "Error: " . $stmt->error;
        }

        $stmt->close();
        $conn->close();
    } else {
        echo "Failed to upload the file.";
    }
} else {
    echo "Invalid request method.";
}
?>

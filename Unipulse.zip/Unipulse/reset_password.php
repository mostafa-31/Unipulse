<?php
session_start();
include_once('connection.php');

if (isset($_POST['pwdrst'])) {
    $email = $_POST['email'];
    $pwd = password_hash($_POST['pwd'], PASSWORD_DEFAULT);
    $cpwd = password_hash($_POST['cpwd'], PASSWORD_DEFAULT);

    if (password_verify($_POST['pwd'], $cpwd)) {
        $reset_pwd = mysqli_query($conn, "UPDATE signup SET password='$pwd' WHERE email='$email'");
        if ($reset_pwd) {
            $msg = 'Your password has been updated successfully. <a href="login.php">Click here</a> to login';
        } else {
            $msg = "Error while updating password.";
        }
    } else {
        $msg = "Password and Confirm Password do not match.";
    }
}

if (isset($_GET['secret'])) {
    $email = base64_decode($_GET['secret']);
    $check_details = mysqli_query($conn, "SELECT email FROM signup WHERE email='$email'");
    $res = mysqli_num_rows($check_details);

    if ($res > 0) {
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="logsig.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.2/css/all.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" integrity="sha512-DTOQO9RWCH3ppGqcWaEA1BIZOC6xxalwEsw9c2QQeAIftl+Vegovlnee1c9QX4TctnWMn13TZye+giMm8e2LwA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <title>Reset Password</title>
    <style>
        
        .error {
            color: red;
            font-weight: 700;
        }
        #pwdr, #cpwdr {
            margin-bottom: 10px;
            padding-left:0px;
        }
        .field{
            margin-bottom: 29px;
        }
        .field .btn{
           
    background-color: #ffa442;
    /* margin-left: 196px; */
    border: none;
    color: black;
    font-size: 18px;
    font-weight: 100;
    cursor: pointer;
    border-radius: 4px;
    padding: 5px;
    margin-top:8px;
}
.underline{
    background-color: rgb(255, 119, 0);
  margin: 8px 120px 40px 106px;
    
  height: 2.5px;
  width: 198px;
}
        
    </style>
</head>
<body>
    <?php include "header.php"; ?>
    <section class="container forms">
        <div class="form login">
            <h3 class="heading">Reset Password</h3>
            <form id="validate_form" method="post" class="contentl">
                <input type="hidden" name="email" value="<?php echo $email; ?>"/>
                <div class="line underline"></div>
                <div class="field input">
                    <label for="pwd">Password</label>
                    <input type="password" name="pwd" id="pwdr" placeholder="Enter Password" required class="form-control">
                </div>
                <div class="field input">
                    <label for="cpwd">Confirm Password</label>
                    <input type="password" name="cpwd" id="cpwdr" placeholder="Enter Confirm Password" required class="form-control">
                </div>
                <div class="field btn">
                    <input type="submit" id="login" name="pwdrst" value="Reset Password" class="btn btn-success">
                </div>
                <p class="error"><?php if(!empty($msg)){ echo $msg; } ?></p>
            </form>
        </div>
    </section>
    <script src="./script.js"></script>
    <?php include 'footer.php'; ?>
</body>
</html>
<?php
    } else {
        echo "Invalid password reset link.";
    }
}
?>

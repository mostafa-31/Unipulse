<?php
    session_start();
    if(!isset($_SESSION['loggedin']) || isset($_SESSION['loggedin'])!=true){
        header("location:login.php");
        exit;
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Visa Application Steps</title>
    <style>
       .how-to-apply {
        text-align: initial;
    font-size: 1.1rem;
    color: #666;
    /* margin-bottom: 2rem; */
    margin: 70px;
    font-family: Arial, sans-serif;
}
.how-to-apply p {
       
    margin-bottom: 2rem; 
   
}

.how-to-apply h1 {
    font-size: 2.5rem;
    color: #333;
    margin-bottom: 1rem;
    
}
.how-to-apply h2 {
    font-size: 2rem;
    color: #333;
    margin-bottom: 1rem;
}
.steps-container {
    display: flex;
    justify-content: space-around;
    flex-wrap: wrap;
}

.step {
    background-color: #f8f9fa;
    border: 1px solid #333;
    border-radius: 8px;
    box-shadow: 0 2px 5px rgba(0,0,0,0.1);
    max-width: 250px;
    margin: 1rem;
    text-align: center;
    padding: 1rem;
    overflow: hidden;
}

.step h3 {
    font-size: 2rem;
    color: #333;
    margin: 0.5rem 0;
}

.step img {
    width: 267px;
    height: auto;
    margin-bottom: 1rem;
}

.step h4 {
    font-size: 1.2rem;
    color: #333;
}
.step p {
    font-size: 1rem;
    color: #666;
    padding: 0 1rem;
}

.apply-now {
    text-align: center;
    margin-top: 2rem;
}

.apply-now h4 {
    font-size: 1.5rem;
    color: #333;
    margin-bottom: 1rem;
}

.apply-button {
    display: inline-block;
    padding: 0.5rem 1.5rem;
    background-color: #004a45;
    color: #fff;
    text-decoration: none;
    border-radius: 4px;
    transition: background-color 0.3s ease;
    cursor: pointer;
}

.apply-button:hover {
    background-color: #00332f;
}
    </style>
</head>
<body>
<?php include 'header.php';?>
<section class="how-to-apply">
        <h1>Do I need a visa to study abroad? </h1>
        <p>If you want to study abroad in the UK, US or Australia, you may need to apply for  a student visa. A student visa is a permit that allows you to live and study in your chosen country for a set amount of time.Visa requirements vary depending on the country you want to study in, and the type of course you’re taking. For example, if you’re studying a short course, you may be able to travel on a tourist visa. But if you’re studying a degree, you’ll need a student visa.</p>
        <h1>How to apply for a student visa</h1>
        <p>
        How you apply for your visa will vary depending on the type of visa and where you want to study. Not sure where to start? We offer plenty of support to help you with your visa application – which might be why INTO students have a 99% visa success rate
        </p>
        <h2>Secure your visa in 5 simple steps</h2>
        <div class="steps-container">
            <div class="step">
                <!-- <h3>1</h3> -->
                <img src="https://media.intostudy.com/image/upload/w_1080,q_auto/v1712132303/visa_Step1.gif">
                <h4>Accept your offer</h4>
                <p>Confirm your place, then meet any conditions of your offer (if applicable).</p>
            </div>
            <div class="step">
                <!-- <h3>2</h3> -->
                <img src="https://media.intostudy.com/image/upload/w_1080,q_auto/v1713275445/visa_Step2.gif">
                <h4>Complete the CAS data check</h4>
                <p>And any required credibility tasks. Once submitted, you should receive your CAS in 1 working day</p>
            </div>
            <div class="step">
                <!-- <h3>3</h3> -->
                <img src="https://media.intostudy.com/image/upload/w_1080,q_auto/v1712135594/visa_Step3.gif">
                <h4>Apply and pay for your visa online</h4>
                <p>You can apply up to 6 months before your course start date, once you have your CAS.</p>
            </div>
            <div class="step">
                <!-- <h3>4</h3> -->
                <img src="https://media.intostudy.com/image/upload/w_1080,q_auto/v1712138052/visa_Step4.gif">
                <h4>Pay the Immigration Health Surcharge</h4>
                <p>PThis grants you access to the  National Health Service (NHS). </p>
            </div>
            <div class="step">
                <!-- <h3>5</h3> -->
                <img src="https://media.intostudy.com/image/upload/w_1080,q_auto/v1712069455/How_to_apply_Step5.gif">
                <h4>Attend a biometrics appointment</h4>
                <p>Submit the required supporting documents and confirm your identity.</p>
            </div>
            <div class="step">
                <!-- <h3>6</h3> -->
                <img src="https://media.intostudy.com/image/upload/w_1080,q_auto/v1713275526/visa_Step6.gif">
                <h4>Wait for a decision</h4>
                <p>This can take 1–4 weeks on average depending on the service you choose.</p>
            </div>
        </div>
    </section>
    <!-- <script src="scripts.js"></script> -->
    <?php include 'footer.php';?>
</body>
</html>

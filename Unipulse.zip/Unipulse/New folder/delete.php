<?php 


include 'config.php';
session_start();

if (!isset($_SESSION['admin_id'])) {
    header("Location: logina.php");
    exit();
}
?>
<?php
include('dbn.php');

$message = "";

if (isset($_GET['id'])) {
    $id = intval($_GET['id']);

    // Get the file name to delete the file from the server
    $sql = "SELECT pdf_file FROM notices WHERE id=$id";
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $pdf_file = $row['pdf_file'];
        
        // Delete the record from the database
        $sql = "DELETE FROM notices WHERE id=$id";
        if ($conn->query($sql) === TRUE) {
            // Delete the file from the server
            if (file_exists("uploads/" . $pdf_file)) {
                unlink("uploads/" . $pdf_file);
            }
            $message = "<p class='success'>Notice deleted successfully.</p>";
        } else {
            $message = "<p class='error'>Error deleting notice: " . $conn->error . "</p>";
        }
    } else {
        $message = "<p class='error'>No such notice found.</p>";
    }
} else {
    $message = "<p class='error'>Invalid request.</p>";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Delete Notice</title>
    <link rel="stylesheet" href="css/styles2.css">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@700&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Roboto', sans-serif;
            background-color: #f4f4f4;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }
        .container {
            text-align: center;
            background-color: #fff;
            padding: 20px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.2);
            border-radius: 8px;
            border: 1px solid #ddd;
        }
        .success {
            color: green;
        }
        .error {
            color: red;
        }
        .button {
            display: inline-block;
            padding: 10px 20px;
            margin-top: 20px;
            color: #fff;
            background-color: #007BFF;
            text-decoration: none;
            border-radius: 5px;
            transition: background-color 0.3s ease;
        }
        .button:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>
    
    <div class="container">
        <?php echo $message; ?>
        <a href="manage.php" class="button">Back to Manage Notices</a>
    </div>
</body>
</html>

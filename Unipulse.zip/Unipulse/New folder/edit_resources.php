<?php include 'sidebar.php';?>
<?php
function loadResources($subject) {
    $data_file = "resources/$subject.json";
    if (file_exists($data_file)) {
        return json_decode(file_get_contents($data_file), true);
    }
    return [];
}

function saveResources($subject, $resources) {
    $data_file = "resources/$subject.json";
    file_put_contents($data_file, json_encode($resources, JSON_PRETTY_PRINT));
}

$action_performed = false;

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['action'])) {
    $subject = $_POST['subject'];
    $part = $_POST['part'];
    $chapter = $_POST['chapter'];
    $action = $_POST['action'];
    $resourceIndex = $_POST['resourceIndex'];

    $resources = loadResources($subject);

    if ($action == 'delete') {
        unset($resources[$part][$chapter][$resourceIndex]);
        // Remove empty arrays
        $resources[$part][$chapter] = array_values($resources[$part][$chapter]);
        if (empty($resources[$part][$chapter])) {
            unset($resources[$part][$chapter]);
        }
        if (empty($resources[$part])) {
            unset($resources[$part]);
        }
    } elseif ($action == 'update') {
        $pdf_title = $_POST['pdf_title'];
        $video_title = $_POST['video_title'];
        $video_link = $_POST['video_link'];
        
        if (isset($resources[$part][$chapter][$resourceIndex]['pdf'])) {
            $resources[$part][$chapter][$resourceIndex]['pdf_title'] = $pdf_title;

            // Handle PDF file upload
            if (isset($_FILES['pdf_file']) && $_FILES['pdf_file']['error'] == UPLOAD_ERR_OK) {
                $pdf_file = $_FILES['pdf_file'];
                $pdf_path = 'uploads/' . basename($pdf_file['name']);
                move_uploaded_file($pdf_file['tmp_name'], $pdf_path);
                $resources[$part][$chapter][$resourceIndex]['pdf'] = $pdf_file['name'];
            }
        }
        
        if (isset($resources[$part][$chapter][$resourceIndex]['video'])) {
            $resources[$part][$chapter][$resourceIndex]['video_title'] = $video_title;
            $resources[$part][$chapter][$resourceIndex]['video'] = $video_link;
        }
    }

    saveResources($subject, $resources);
    $action_performed = true;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Resources</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: antiquewhite;
        }
        h1 {
            margin-top: 50px;
            text-align: center;
            margin-bottom: 20px;
            background: linear-gradient(135deg, #cf9aff,#95c0ff);
            font-family: 'Arial', sans-serif;
            font-size: 2rem;
        }

        .mainbl #subject{
            padding: 0.5em;
            /* font-size: 0.5em; */
            border-radius: 5px;
            border: 1px solid #ccc;
            /* margin-bottom: 1em; */
        }
        .mainbl {
            padding: 2em;
            max-width: 1000px;
            margin: 2em auto;
            background: linear-gradient(135deg, #cf9aff,#95c0ff);
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            border: 1px solid #ccc;
        }
        .mainbl .subject {
            margin-bottom: 2em;
        }
        .mainbl h2 {
            color: #0056b3;
            margin-bottom: 0.5em;
        }
        .mainbl ul {
            list-style-type: none;
            padding: 0;
        }
        .mainbl li {
            margin: 0.5em 0;
            padding: 0.5em;
            background-color: #f9f9f9;
            border-radius: 5px;
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
        }
        .mainbl .pdfe,
        .mainbl .vdo {
            display: flex;
            align-items: center;
            gap: 0.2em;
        }
        .mainbl .pdfe img,
        .mainbl .vdo img {
            width: 40px;
            height: 40px;
        }
        .resource-form {
            display: inherit;
            flex-direction: column;
            gap: 1em;
            margin-top: 1em;
            background-color: #f0f4f8;
            padding: 1em;
            padding-top: 0em;
            padding-right: 0em;
  padding-left: 0em;
            border-radius: 5px;
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
        }
        .resource-form input[type="text"],
        .resource-form input[type="file"],
        .resource-form select {
            padding: 0.8em;
            border: 1px solid #ccc;
            border-radius: 5px;
            font-size: 0.8em;
            margin: 1em;
        }
        .resource-form button {
            padding: 0.75em;
            background-color: #28a745;
            color: #fff;
            border: none;
            border-radius: 5px;
            font-size: 1em;
            cursor: pointer;
        }
        .resource-form button:hover {
            background-color: #218838;
        }
        .resource-actions {
            display: flex;
            gap: 1em;
        }
        .resource-actions form {
            margin: 0;
        }
        .resource-actions  .sub{
            padding: 0.5em 1em;
            font-size: 0.875em;
            background-color: green;
            border: none;
            color: #fff;
            border-radius: 5px;
            cursor: pointer;
            margin-left: 498px;
        }
        .resource-actions  .sub:hover{
            background-color: darkgreen;
        }
        .resource-actions button {
            padding: 0.5em 1em;
            font-size: 0.875em;
            background-color: #dc3545;
            border: none;
            color: #fff;
            border-radius: 5px;
            cursor: pointer;
        }
        .resource-actions button:hover {
            background-color: #c82333;
        }
        .subject select {
            padding: 0.5em;
            font-size: 1em;
            border-radius: 5px;
            border: 1px solid #ccc;
            margin-bottom: 1em;
        }
    </style>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <script>
        function showPopup(message) {
            alert(message);
        }

        <?php if ($action_performed): ?>
            window.onload = function() {
                showPopup("Action performed successfully!");
            };
        <?php endif; ?>
    </script>
</head>
<body>
    
        <h1>Edit Resources</h1>
    
    <main class="mainbl">
        <form method="post">
            <input type="hidden" name="subject" value="<?php echo isset($_POST['subject']) ? $_POST['subject'] : ''; ?>">
            <label for="subject">Subject:</label>
            <select name="subject" id="subject" onchange="this.form.submit()">
                <option value="physics" <?php echo isset($_POST['subject']) && $_POST['subject'] == 'physics' ? 'selected' : ''; ?>>Physics</option>
                <option value="chemistry" <?php echo isset($_POST['subject']) && $_POST['subject'] == 'chemistry' ? 'selected' : ''; ?>>Chemistry</option>
                <option value="math" <?php echo isset($_POST['subject']) && $_POST['subject'] == 'math' ? 'selected' : ''; ?>>Math</option>
            </select>
        </form>
        
        <?php
        if (isset($_POST['subject'])) {
            $subject = $_POST['subject'];
            $resources = loadResources($subject);

            // Sort parts and chapters numerically
            ksort($resources, SORT_NUMERIC);
            foreach ($resources as $part => $chapters) {
                ksort($chapters, SORT_NUMERIC);
                $resources[$part] = $chapters;
            }

            foreach ($resources as $part => $chapters) {
                echo "<div class='subject'>";
                echo "<h2>Part $part</h2>";
                echo "<ul>";
                foreach ($chapters as $chapter => $chapterResources) {
                    echo "<li><strong>Chapter $chapter</strong>";
                    foreach ($chapterResources as $index => $resource) {
                        echo "<ul>";
                        if (isset($resource['pdf'])) {
                            echo "<li class='pdfe'><a href='uploads/{$resource['pdf']}' target='_blank'><img src='pdf_icon.png' alt='PDF Icon'style='width: 40px;height: 50px;'></a>{$resource['pdf_title']}</li>";
                        }
                        if (isset($resource['video'])) {
                            echo "<li class='vdo'><img src='vd.png' alt='Video Icon'style='width: 50px;height: 40px;'> <a href='{$resource['video']}' target='_blank'></a>{$resource['video_title']}</li>";
                        }
                        echo "<li class='resource-actions'>";
                        echo "<form method='post' class='resource-form' style='display:inline;' enctype='multipart/form-data'>";
                        echo "<input type='hidden' name='subject' value='$subject'>";
                        echo "<input type='hidden' name='part' value='$part'>";
                        echo "<input type='hidden' name='chapter' value='$chapter'>";
                        echo "<input type='hidden' name='resourceIndex' value='$index'>";
                        echo "<input type='text' name='pdf_title' placeholder='PDF Title' value='" . (isset($resource['pdf_title']) ? $resource['pdf_title'] : '') . "'>";
                        echo "<input type='file' name='pdf_file'>";
                        echo "<input type='text' name='video_title' placeholder='Video Title' value='" . (isset($resource['video_title']) ? $resource['video_title'] : '') . "'>";
                        echo "<input type='text' name='video_link' placeholder='Video Link' value='" . (isset($resource['video']) ? $resource['video'] : '') . "'>";
                        echo "<button class='sub' type='submit' name='action' value='update'>Update</button>";
                        echo "</form>";
                        
                        echo "<form method='post' class='resource-form' style='display:inline;'>";
                        echo "<input type='hidden' name='subject' value='$subject'>";
                        echo "<input type='hidden' name='part' value='$part'>";
                        echo "<input type='hidden' name='chapter' value='$chapter'>";
                        echo "<input type='hidden' name='resourceIndex' value='$index'>";
                        echo "<button type='submit' name='action' value='delete'style='margin-top: 130px;margin-right: 209px;'>Delete</button>";
                        echo "</form>";
                        echo "</li>";
                        echo "</ul>";
                    }
                    echo "</li>";
                }
                echo "</ul>";
                echo "</div>";
            }
        }
        ?>
    </main>
</body>
</html>

<?php include 'sidebar.php';?>
<?php
require 'configq.php'; // Your database configuration

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['delete_question'])) {
        $question_id = $_POST['question_id'];
        // Delete the question from the database
        $stmt = $conn->prepare("DELETE FROM questions WHERE id = ?");
        $stmt->bind_param("i", $question_id);
        $stmt->execute();
    } elseif (isset($_POST['update_answer'])) {
        $question_id = $_POST['question_id'];
        $answer = $_POST['answer'];

        // Update the answer if it exists
        $stmt = $conn->prepare("UPDATE questions SET answer = ? WHERE id = ?");
        $stmt->bind_param("si", $answer, $question_id);
        $stmt->execute();
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Reply to Questions - UniPulse</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="QnA/stylrr.css">
    <style>
        body{
            background-color: antiquewhite;
        }
    /* QnA Section Styles */
    #reply-section {
        /* background: #f9f9f9; */
        /* padding: 50px 20px; */
        border-radius: 10px;
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.4);
        max-width: 800px;
        margin-left: 400px;
        /* margin-top: 50px; */
    }

    /* #reply-section h1 {
        text-align: left;
        font-size: 2.5em;
        color: #333;
        margin-bottom: 30px;
        text-transform: uppercase;
        letter-spacing: 1.5px;
    } */
    .rq h1 {
            margin-top: 50px;
            text-align: center;
            margin-bottom: 20px;
            background: linear-gradient(135deg, #cf9aff,#95c0ff);
            font-family: 'Arial', sans-serif;
            font-size: 2rem;
            text-transform: uppercase;
            letter-spacing: 1.px;
        }

    #questions {
        margin-top: 30px;
    }

    .question {
        background: #fff;
        border: 1px solid #ddd;
        border-radius: 10px;
        padding: 20px;
        margin-bottom: 20px;
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.05);
        font-size: 1rem;
    }

    .question p {
        margin: 0 0 10px;
        /* font-size: 1.1em; */
        font-size: 1rem;
        color: #333;
    }
    .question p  img{
        width: 35px;
        height: 35px;
       
    }
    
    .question p strong {
        color: blue;
        font-style: italic;
        font-size: 1rem;
    }

    .question p small {
        display: block;
        /* font-size: 1em; */
        font-size: 1rem;
        color: #456;
        margin-top: 5px;
    }

    .question textarea {
        width: 95%;
        resize: none;
        height: 50px;
        padding: 15px;
        border: 2px solid #ddd;
        border-radius: 8px;
        /* font-size: 1em; */
        font-size: 1rem;
        margin-bottom: 15px;
        box-shadow: inset 0 2px 4px rgba(0, 0, 0, 0.05);
        transition: border-color 0.3s;
    }

    .question textarea:focus {
        border-color: #007bff;
    }

    .question button {
        background-color: #007bff;
        color: #fff;
        border: none;
        padding: 10px 20px;
        border-radius: 8px;
        cursor: pointer;
        /* font-size: 1em; */
        font-size: 1rem;

        /* font-size: 0.5rem; */
        margin-right: 10px;
        transition: background-color 0.3s;
    }

    .question button:hover {
        background-color: #0056b3;
    }

    .question button[name="delete_question"] {
        background-color: #dc3545;
    }

    .question button[name="delete_question"]:hover {
        background-color: #c82333;
    }
    </style>
</head>
<body>

    <header class="navbar">
        
    </header>
    <div class="rq"><h1>Reply to Questions</h1></div>
    <section id="reply-section">
       
        <div id="questions">
            <?php
            $result = $conn->query("SELECT * FROM questions ORDER BY created_at DESC");
            while ($row = $result->fetch_assoc()) {
                echo '<div class="question">';
                echo '<p><small><strong>' . htmlspecialchars($row['username']) . '</strong> on ' . date('F j, Y, g:i a', strtotime($row['created_at'])) . '</small></p>';
                echo '<p><span class="icon"><img src="question.png" alt="Q" ></span> ' . htmlspecialchars($row['question']) . '</p>';
                echo '<form method="POST" action="reply_questions.php">';
                echo '<textarea name="answer" placeholder="Type your answer here...">' . htmlspecialchars($row['answer']) . '</textarea>';
                echo '<input type="hidden" name="question_id" value="' . $row['id'] . '">';
                echo '<button type="submit" name="update_answer"onclick="return confirm(\'Answer updated\');">Submit Answer</button>';
                echo '<button type="submit" name="delete_question" onclick="return confirm(\'Are you sure you want to delete this question?\');">Delete Question</button>';
                echo '</form>';
                echo '</div>';
            }
            ?>
        </div>
    </section>

    
</body>
</html>

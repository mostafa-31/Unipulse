<?php include('sidebar.php'); ?>
<?php 
include('dbn.php'); 

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_FILES['pdf_file'])) {
    $title = $_POST['title'];
    $notice_date = $_POST['notice_date'];
    $pdf_file = $_FILES['pdf_file']['name'];
    $target_dir = "uploads/";
    $target_file = $target_dir . basename($pdf_file);

    if (move_uploaded_file($_FILES['pdf_file']['tmp_name'], $target_file)) {
        $sql = "INSERT INTO notices (title, notice_date, pdf_file) VALUES ('$title', '$notice_date', '$pdf_file')";
        if ($conn->query($sql) === TRUE) {
            echo "<script>alert('Notice uploaded successfully!'); window.location.href = 'notic.php';</script>";
        } else {
            echo "<script>alert('Error: " . $sql . "<br>" . $conn->error . "'); window.location.href = 'notic.php';</script>";
        }
    } else {
        echo "<script>alert('Sorry, there was an error uploading your file.'); window.location.href = 'notic.php';</script>";
    }
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@700&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Roboto&display=swap" rel="stylesheet">
    <title>Upload Notice</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: antiquewhite;
        }

        .container {
            background: #11101d;
        }

        h1 {
            margin-top: 50px;
            text-align: center;
            margin-bottom: 20px;
            padding: 7px;
            background: linear-gradient(135deg, #cf9aff,#95c0ff);
            font-family: 'Arial', sans-serif;
        }

        form {
            margin-left: 550px;
            margin-top: 50px;
            display: flex;
            flex-direction: column;
            width: 400px;
            background: linear-gradient(135deg, #cf9aff,#95c0ff);
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        label {
            margin-bottom: 10px;
            font-weight: bold;
        }

        input[type="text"],
        input[type="date"],
        input[type="file"] {
            padding: 10px;
            margin-bottom: 20px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }

        button[type="submit"] {
            padding: 10px 20px;
            background: linear-gradient(#9418fd,#571094);
            color: #fff;
            font-weight: bold;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        button[type="submit"]:hover {
            background-color: #45a049;
        }
    </style>
</head>
<body>
    <div>
        <h1>Upload Notice</h1>
    </div>
    <form action="upload.php" method="post" enctype="multipart/form-data">
        <label for="title">Title:</label>
        <input type="text" name="title" id="title" required><br>
        <label for="notice_date">Date:</label>
        <input type="date" name="notice_date" id="notice_date" required><br>
        <label for="pdf_file">PDF File:</label>
        <input type="file" name="pdf_file" id="pdf_file" required><br>
        <button type="submit">Upload Notice</button>
    </form>
</body>
</html>

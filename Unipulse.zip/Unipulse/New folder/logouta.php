<?php
session_start();
if (isset($_SESSION['admin_id'])) {
    unset($_SESSION['admin_id']);
    unset($_SESSION['admin_loggedin']);
}
header("Location: logina.php");
exit();
?>

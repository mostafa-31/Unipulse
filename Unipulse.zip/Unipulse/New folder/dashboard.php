<?php include 'sidebar.php';?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/boxicons/2.0.7/css/boxicons.min.css" rel="stylesheet">
    <style>
        body {
            font-family: 'Arial', sans-serif;
            /* background-color: #f0f2f5; */
            background-color: antiquewhite;
            /* display: flex; */
            /* justify-content: center; */
            /* align-items: center; */
            /* height: 100vh; */
            margin: 0;
        }
        .greet {
            text-align: center;
            margin-top: 50px;
            margin-bottom: 20px;
        }

        .greet span {
            color: #9418fd;
        }

        .dashboard {
            display: flex;
            flex-wrap: wrap;
            gap: 20px;
            max-width: 1200px;
            margin-left: 253px;margin-top: 61px;
            justify-content: center;
        }
        .card {
            background-color: #ffffff;
            /* border-radius: 15px; */
            box-shadow: 4px 4px 8px rgba(0, 0, 0, 0.3);
            width: 200px;
            height: 166px;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            transition: transform 0.3s, box-shadow 0.3s;
            position: relative;
            border: 1px solid gray;
           
        }
        .card:hover {
            transform: translateY(-10px);
            box-shadow: 0 12px 24px rgba(0, 0, 0, 0.5);
            /* color: #9418fd; */
        }
        .card i {
            font-size: 48px;
            color: #11101d;
            margin-bottom: 10px;
        }
        .card i:hover, .link_name:hover {
            transition: color 0.1s;
            color: #9418fd;
        }
        .link_name {
            font-size: 18px;
            color: #11101d;
            font-weight: bold;
        }
        /* .card .link_name:hover {
            transition: color 0.1s;
            color: #9418fd;
        } */
        .dropdown {
            position: absolute;
            top: 100%;
            left: 0;
            width: 100%;
            background-color: #ffffff;

            /* border-radius: 0 0 15px 15px; */
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.3);
            opacity: 0;
            visibility: hidden;
            transform: translateY(-10px);
            transition: all 0.3s;
            
        }
        .card:hover .dropdown {
            opacity: 1;
            visibility: visible;
            transform: translateY(0);
        }
        .dropdown ul {
            list-style-type: none;
            padding: 0;
            margin: 0;
        }
        .dropdown li {
            padding: 10px;
            text-align: center;
            border-top: 1px solid #f0f0f0;
            border-bottom: 1px solid #666;
            

        }
        .dropdown li:first-child {
            border-top: none;
        }
        .dropdown li a {
            text-decoration: none;
            color: #11101d;
            display: block;
        }
        .dropdown li a:hover {
            background-color: #f0f2f5;
            color: #9418fd;
            font-weight: bold;
        }
    </style>
</head>
<body>
<div class="greet">
    <h1 data-shadow='WELCOME'>WELCOME to the Dashboard <span><?php echo $username; ?>!</span></h1>
    <p>You have successfully logged in to the admin Panel.</p>
</div>
    <div class="dashboard">
        <div class="card">
            <i class='bx bxs-user'></i>
            <span class="link_name">Admin</span>
            <div class="dropdown">
                <ul>
                    <li><a href="profile.php">Profile Edit</a></li>
                    <li><a href="viewadmins.php">View Admins</a></li>
                </ul>
            </div>
        </div>
        <div class="card">
            <i class='bx bx-bell'></i>
            <span class="link_name">Notices</span>
            <div class="dropdown">
                <ul>
                    <li><a href="notic.php">Users View</a></li>
                    <li><a href="upload.php">Add Notice</a></li>
                    <li><a href="manage.php">Manage Notice</a></li>
                </ul>
            </div>
        </div>
        
        <div class="card">
            <i class='bx bx-message-square-dots'></i>
            <span class="link_name">QnA</span>
            <div class="dropdown">
                <ul>
                    <li><a href="reply_questions.php">Manage QnA</a></li>
                </ul>
            </div>
        </div>
        <div class="card">
            <i class='bx bxs-user-detail'></i>
            <span class="link_name">Users Details</span>
            <div class="dropdown">
                <ul>
                    <li><a href="display_users.php">View Users Details</a></li>
                    <li><a href="edit_display_users.php">Edit Users Details</a></li>
                </ul>
            </div>
        </div>
        <div class="card">
            <i class='bx bx-note'></i>
            <span class="link_name">Resources</span>
            <div class="dropdown">
                <ul>
                    <li><a href="resadmin.php">Resources Upload</a></li>
                    <li><a href="edit_resources.php">Edit</a></li>
                    <li><a href="resview.php">View</a></li>
                </ul>
            </div>
        </div>
        <div class="card" style="margin-top: 35px;">
        <i class='bx bxs-bank'></i>
            <span class="link_name">Universities</span>
            <div class="dropdown">
                <ul>
                    <li><a href="upload_uni.php">Upload University</a></li>
                    <li><a href="edit_uni.php">Edit University Details</a></li>
                    
                </ul>
            </div>
        </div>
    </div>
</body>
</html>

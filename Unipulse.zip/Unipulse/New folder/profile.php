<?php
include 'config.php';
session_start();

if (!isset($_SESSION['admin_id'])) {
    header("Location: logina.php");
    exit();
}

$admin_id = $_SESSION['admin_id'];

$message = ''; // Initialize an empty message variable

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['usernamea'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $retype_password = $_POST['retype_password'];
    $profile_picture = $_FILES['profile_picture'];

    if ($password !== $retype_password) {
        $message = "Passwords do not match.";
    } else {
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);

        // Handle file upload
        if ($profile_picture['error'] === UPLOAD_ERR_OK) {
            $upload_dir = 'uploads/';
            $upload_file = $upload_dir . basename($profile_picture['name']);
            move_uploaded_file($profile_picture['tmp_name'], $upload_file);
            $profile_picture_url = $upload_file;
        } else {
            $profile_picture_url = ''; // Existing profile picture URL
        }

        $sql = "UPDATE admins SET usernamea=?, email=?, password=?, profile_picture=? WHERE id=?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ssssi", $username, $email, $hashed_password, $profile_picture_url, $admin_id);

        if ($stmt->execute()) {
            $message = "Record updated successfully";
        } else {
            $message = "Error updating record: " . $stmt->error;
        }

        $stmt->close();
    }
}

$sql = "SELECT usernamea, email, profile_picture FROM admins WHERE id=?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $admin_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $username = $row['usernamea'];
    $email = $row['email'];
    $profile_picture = $row['profile_picture'];
} else {
    $message = "No user found.";
}

$stmt->close();
$conn->close();
?>

<!DOCTYPE html>
<html>
<head>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: antiquewhite;
            color: #ffffff;
        }

        .form-container {
            background-color: #11101d;
            padding: 30px;
            border-radius: 10px;
            width: 400px;
            height: 600px;
            margin: 0 auto;
            margin-top: 50px;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.5);
            text-align: left;
        }

        .form-container h2 {
            text-align: center;
        }

        .form-container form {
            display: flex;
            flex-direction: column;
            align-items: left;
        }

        input[type="text"],
        input[type="email"],
        input[type="password"],
        input[type="file"] {
            background: transparent;
            border: none;
            border-bottom: 2px solid #ffffff;
            color: #ffffff;
            padding: 5px;
            margin-bottom: 13px;
            width: 100%;
            outline: none;
        }

        input[type="submit"] {
            background-color: #4CAF50;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            
                margin-top: 33px;
        }

        input[type="submit"]:hover {
            background-color: #45a049;
        }

        /* .form-container form span {
            cursor: pointer;
            position: absolute;
        }

        .eye-icon {
            right: 15px;
        } */
        .bx-hide {
            margin-left: 326px;
        } 
        .bx-show {
            margin-left: 326px;
        } 
        .ret{
    margin-top: 25px;
}
        .profile-picture {
            border-radius: 50%;
            width: 100px;
            height: 100px;
            object-fit: cover;
            margin-bottom: 15px;
            margin-left: 116px;
        }

        .profile-picture-placeholder {
            font-size: 50px;
            color: #ffffff;
            background-color: #fff;
            border-radius: 50%;
            width: 100px;
            height: 100px;
            display: flex;
            justify-content: center;
            align-items: center;
            margin-bottom: 15px;
            margin-left: 116px;
        }

        .logout-link {
            color: #ffffff;
            text-decoration: none;
            margin-top: 20px;
            display: inline-block;
        }

        .logout-link:hover {
            text-decoration: underline;
        }
    </style>
    <script>
        // function togglePasswordVisibility(id) {
        //     var passwordField = document.getElementById(id);
        //     if (passwordField.type === "password") {
        //         passwordField.type = "text";
        //     } else {
        //         passwordField.type = "password";
        //     }
        // }
        document.addEventListener('DOMContentLoaded', () => {
    const passwordInput = document.getElementById('password');
    const hideShowIcon = document.querySelector('.hide-show');

    hideShowIcon.addEventListener('click', () => {
        if (passwordInput.type === 'password') {
            passwordInput.type = 'text';
            hideShowIcon.classList.remove('bx-hide');
            hideShowIcon.classList.add('bx-show');
        } else {
            passwordInput.type = 'password';
            hideShowIcon.classList.remove('bx-show');
            hideShowIcon.classList.add('bx-hide');
        }
    });
});
document.addEventListener('DOMContentLoaded', () => {
    const passwordInput = document.getElementById('retype_password');
    const hideShowIcon = document.querySelector('.hide-show-retype');

    hideShowIcon.addEventListener('click', () => {
        if (passwordInput.type === 'password') {
            passwordInput.type = 'text';
            hideShowIcon.classList.remove('bx-hide');
            hideShowIcon.classList.add('bx-show');
        } else {
            passwordInput.type = 'password';
            hideShowIcon.classList.remove('bx-show');
            hideShowIcon.classList.add('bx-hide');
        }
    });
});

        function updateProfileContent(profilePicture, profileName) {
            const profileImg = document.querySelector('.profile-content img');
            const profileNameDiv = document.querySelector('.profile_name');
            profileImg.src = profilePicture;
            profileNameDiv.textContent = profileName;
        }

        function showMessage(message) {
            if (message) {
                alert(message);
            }
        }
    </script>
</head>
<body onload="showMessage('<?php echo $message; ?>')">
    <?php include 'sidebarpro.php'; ?>
    <div class="form-container">
        <h2>Edit Profile</h2>
        <?php if (!empty($profile_picture)) : ?>
            <img src="<?php echo $profile_picture; ?>" alt="Profile Picture" class="profile-picture">
        <?php else : ?>
            <div class="profile-picture-placeholder">👤</div>
        <?php endif; ?>
        <form method="post" action="<?php echo $_SERVER['PHP_SELF'];?>" enctype="multipart/form-data">
            Profile Picture: <input type="file" name="profile_picture"><br>
            Username: <input type="text" name="usernamea" value="<?php echo $username; ?>" required><br>
            Email: <input type="email" name="email" value="<?php echo $email; ?>" required><br>
            Password: 
            <input type="password" name="password" id="password" required>
            <!-- <span class="eye-icon eye-icon-password" onclick="togglePasswordVisibility('password')" style="left: 913px; margin-top: 237px;">👁️</span><br> --><i class="bx bx-hide hide-show" style="margin-top: -42px;"></i>
            <div class="ret"> Retype Password: </div>
            <input type="password" name="retype_password" id="retype_password" required>
            <!-- <span class="eye-icon eye-icon-retype" onclick="togglePasswordVisibility('retype_password')" style="left: 913.03px; margin-top: 305px;">👁️</span><br> -->
            <i class="bx bx-hide hide-show-retype" style="margin-top: -44px;"></i>
            <input type="submit" value="Update">
        </form>
        <br>
        <!-- <a href="logouta.php" class="logout-link">Logout</a> -->
    </div>
</body>
</html>

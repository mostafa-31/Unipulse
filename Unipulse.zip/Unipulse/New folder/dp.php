<?php
include 'config.php';
session_start();

if (!isset($_SESSION['admin_id'])) {
    header("Location: logina.php");
    exit();
}

$admin_id = $_SESSION['admin_id'];

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $retype_password = $_POST['retype_password'];
    $profile_picture = $_FILES['profile_picture'];

    if ($password !== $retype_password) {
        echo "Passwords do not match.";
    } else {
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);

        // Handle file upload
        if ($profile_picture['error'] === UPLOAD_ERR_OK) {
            $upload_dir = 'uploads/';
            $upload_file = $upload_dir . basename($profile_picture['name']);
            move_uploaded_file($profile_picture['tmp_name'], $upload_file);
            $profile_picture_url = $upload_file;
        } else {
            $profile_picture_url = ''; // Default or existing profile picture URL
        }

        $sql = "UPDATE admins SET username='$username', email='$email', password='$hashed_password', profile_picture='$profile_picture_url' WHERE id='$admin_id'";

        if ($conn->query($sql) === TRUE) {
            echo "Record updated successfully";
        } else {
            echo "Error updating record: " . $conn->error;
        }
    }
}

$sql = "SELECT username, email, profile_picture FROM admins WHERE id='$admin_id'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $username = $row['username'];
    $email = $row['email'];
    $profile_picture = $row['profile_picture'];
} else {
    echo "No user found.";
}

$conn->close();
?>
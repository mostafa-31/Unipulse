
<?php include('dbn.php'); ?>

<?php 


include 'config.php';
session_start();

if (!isset($_SESSION['admin_id'])) {
    header("Location: logina.php");
    exit();
    // include 'forall.php';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Message</title>
    <style>
        body {
            font-family: 'Roboto', sans-serif;
            background-color: #f4f4f4;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }
        .container {
            text-align: center;
            background-color: #fff;
            padding: 20px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.2);
            border-radius: 8px;
            border: 1px solid #ddd;
        }
        .success {
            color: green;
        }
        .error {
            color: red;
        }
        .button {
            display: inline-block;
            padding: 10px 20px;
            margin-top: 20px;
            color: #fff;
            background-color: #007BFF;
            text-decoration: none;
            border-radius: 5px;
            transition: background-color 0.3s ease;
        }
        .button:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>
    
    <div class="container">
    <?php echo $_GET['message']; ?> <br>
        <a href="index.php" class="button">Back to Notices</a>
    </div>
</body>
</html>

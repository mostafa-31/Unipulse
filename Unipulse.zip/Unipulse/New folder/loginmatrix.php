<?php
include 'config.php';
session_start();

if (isset($_SESSION['admin_id'])) {
    header("Location: profile.php");
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['usernamea'];
    $password = $_POST['password'];

    $sql = "SELECT id, password FROM admins WHERE usernamea=?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        if (password_verify($password, $row['password'])) {
            $_SESSION['admin_id'] = $row['id'];
            $_SESSION['admin_loggedin'] = true;

            echo '<script>
                alert("Log In Successful.");
                window.location.href = "dashboard.php";
              </script>';
            exit();
        } else {
            echo '<script>
                    alert("Invalid password.");
                    window.location.href = "logina.php";
                  </script>';
        }
    } else {
        echo '<script>
                alert("No user found with that username.");
                window.location.href = "logina.php";
              </script>';
    }

    $stmt->close();
    $conn->close();
}
?>
<!DOCTYPE html>
<html>
<head>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            overflow: hidden;
            background-color: black;
        }

        #matrixCanvas {
            display: block;
            position: fixed;
            top: 0;
            left: 0;
            z-index: -1; /* Ensure the canvas is behind other elements */
        }
.home-content{
    margin-top: -7px;
}

        .form-container {
            background-color: white; /* White background */
            color: black; /* Black text */
            padding: 20px;
            border-radius: 8px;
            width: 400px;
            height: 400px;
            margin: 0 auto;
            margin-top: 100px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.5);
            position: relative;
            z-index: 1; /* Ensure the form is above the canvas */
        }

        .form-container h2 {
            text-align: center;
            margin-bottom: 40px;
            color: black; /* Text color for better visibility */
        }

        .form-container form {
            display: flex;
            flex-direction: column;
        }

        label {
            color: black; /* Label color for better visibility */
            margin-bottom: 8px;
        }

        input[type="text"],
        input[type="password"] {
            background: transparent;
            border: none;
            border-bottom: 2px solid #000000;
            color: #000000;
            padding: 8px;
            margin-bottom: 20px;
            outline: none;
        }

        input[type="submit"] {
            background-color: #4CAF50;
            color: white;
            
            padding: 10px 20px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            margin-bottom: 30px;
        }

        input[type="submit"]:hover {
            background-color: #45a049;
        }

        .form-container form span {
            cursor: pointer;
            position: absolute;
            margin-left: 334px;
            margin-top: 123px;
        }

        .signup-link {
            text-align: center;
            margin-top: 10px;
        }

        .signup-link a {
            color: #4CAF50;
            text-decoration: none;
        }

        .signup-link a:hover {
            text-decoration: underline;
        }
    </style>
    <script>
        document.addEventListener('DOMContentLoaded', () => {
            const passwordInput = document.getElementById('password');
            const hideShowIcon = document.querySelector('.hide-show');

            hideShowIcon.addEventListener('click', () => {
                if (passwordInput.type === 'password') {
                    passwordInput.type = 'text';
                    hideShowIcon.classList.remove('bx-hide');
                    hideShowIcon.classList.add('bx-show');
                } else {
                    passwordInput.type = 'password';
                    hideShowIcon.classList.remove('bx-show');
                    hideShowIcon.classList.add('bx-hide');
                }
            });
        });
    </script>
</head>
<body>
    <canvas id="matrixCanvas"></canvas>
    <script>
        const canvas = document.getElementById('matrixCanvas');
        const ctx = canvas.getContext('2d');

        canvas.width = window.innerWidth;
        canvas.height = window.innerHeight;

        const letters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
        const fontSize = 16;
        const columns = canvas.width / fontSize;

        const drops = Array.from({ length: columns }, () => 1);

        function draw() {
            ctx.fillStyle = 'rgba(0, 0, 0, 0.05)';
            ctx.fillRect(0, 0, canvas.width, canvas.height);

            ctx.fillStyle = '#0f0';
            ctx.font = `${fontSize}px monospace`;

            drops.forEach((y, index) => {
                const text = letters[Math.floor(Math.random() * letters.length)];
                const x = index * fontSize;

                ctx.fillText(text, x, y * fontSize);

                if (y * fontSize > canvas.height && Math.random() > 0.975) {
                    drops[index] = 0;
                }

                drops[index]++;
            });
        }

        setInterval(draw, 33);
    </script>
    <?php include 'sidebarlogsign.php'; ?>
    <div class="form-container">
        <h2>Login Form</h2>
        <form method="post" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>">
            <label for="usernamea">Username:</label>
            <input type="text" name="usernamea" id="username" required>
            <label for="password">Password:</label>
            <input type="password" name="password" id="password" required>
            <span><i class='bx bx-hide hide-show'></i></span>
            <input type="submit" value="Login">
        </form>
        <div class="signup-link"> Don't have an account?<a href="signupmatrix.php"> Sign up here.</a> </div>
    </div>
</body>
</html>

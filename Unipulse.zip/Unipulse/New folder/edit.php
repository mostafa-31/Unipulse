<?php
include('sidebar.php'); ?>
<?php

include('dbn.php');

$message = "";

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id = intval($_POST['id']);
    $title = $_POST['title'];
    $notice_date = $_POST['notice_date'];
    $pdf_file = $_FILES['pdf_file']['name'];
    $target_dir = "uploads/";

    if ($pdf_file) {
        $target_file = $target_dir . basename($pdf_file);
        // Check if uploads directory exists, if not create it
        if (!is_dir($target_dir)) {
            mkdir($target_dir, 0755, true);
        }
        // Upload file to server
        if (move_uploaded_file($_FILES['pdf_file']['tmp_name'], $target_file)) {
            // Delete the old file
            $old_pdf_query = "SELECT pdf_file FROM notices WHERE id=$id";
            $old_pdf_result = $conn->query($old_pdf_query);
            if ($old_pdf_result->num_rows > 0) {
                $old_pdf_row = $old_pdf_result->fetch_assoc();
                $old_pdf_file = $old_pdf_row['pdf_file'];
                if (file_exists($target_dir . $old_pdf_file)) {
                    unlink($target_dir . $old_pdf_file);
                }
            }
            $sql = "UPDATE notices SET title='$title', notice_date='$notice_date', pdf_file='$pdf_file' WHERE id=$id";
        } else {
            $message = "Sorry, there was an error uploading your file.";
        }
    } else {
        $sql = "UPDATE notices SET title='$title', notice_date='$notice_date' WHERE id=$id";
    }

    if ($conn->query($sql) === TRUE) {
        $message = "Notice updated successfully.";
    } else {
        $message = "Error updating notice: " . $conn->error;
    }
} elseif (isset($_GET['id'])) {
    $id = intval($_GET['id']);
    $sql = "SELECT * FROM notices WHERE id=$id";
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
        $notice = $result->fetch_assoc();
    } else {
        $message = "No such notice found.";
        exit;
    }
} else {
    $message = "Invalid request.";
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Edit Notice</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f8f8f8;
        }

        .container {
            background: linear-gradient(135deg, #cf9aff, #95c0ff);
        }

        h1 {
            margin-top: 50px;
            text-align: center;
            margin-bottom: 20px;
            background: linear-gradient(135deg, #cf9aff, #95c0ff);
            font-family: 'Poppins', sans-serif;
        }

        form {
            margin-left: 550px;
            margin-top: 50px;
            display: flex;
            flex-direction: column;
            width: 400px;
            background: linear-gradient(135deg, #cf9aff, #95c0ff);
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        label {
            margin-bottom: 10px;
            font-weight: bold;
        }

        input[type="text"],
        input[type="date"],
        input[type="file"] {
            padding: 10px;
            margin-bottom: 20px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }

        button[type="submit"] {
            padding: 10px 20px;
            background: linear-gradient(#9418fd, #571094);
            color: #fff;
            font-weight: bold;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        button[type="submit"]:hover {
            background-color: #45a049;
        }

        .success-message {
            margin-top: 20px;
            padding: 10px;
            background-color: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
            border-radius: 5px;
        }

        .error-message {
            margin-top: 20px;
            padding: 10px;
            background-color: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
            border-radius: 5px;
        }
    </style>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@700&display=swap" rel="stylesheet">
    <script>
        function showMessage(message) {
            if (message) {
                alert(message);
                window.location.href = 'manage.php';
            }
        }
    </script>
</head>

<body onload="showMessage('<?php echo htmlspecialchars($message); ?>')">

    <div>
        <h1>Edit Notice</h1>
    </div>
    <form action="edit.php" method="post" enctype="multipart/form-data">
        <input type="hidden" name="id" value="<?php echo htmlspecialchars($notice['id']); ?>">
        <label for="title">Title:</label>
        <input type="text" name="title" id="title" value="<?php echo htmlspecialchars($notice['title']); ?>" required><br>
        <label for="notice_date">Date:</label>
        <input type="date" name="notice_date" id="notice_date" value="<?php echo htmlspecialchars($notice['notice_date']); ?>" required><br>
        <label for="pdf_file">PDF File (leave blank to keep current file):</label>
        <input type="file" name="pdf_file" id="pdf_file"><br>
        <button type="submit">Update Notice</button>
    </form>
</body>
</html>

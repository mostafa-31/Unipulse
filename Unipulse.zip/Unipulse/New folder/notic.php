<?php include 'sidebar.php';?>

<?php include('dbn.php'); ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Notices</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            /* background-color: antiquewhite; */
        }

        .no {
            /* margin-left: 268px; */
            margin-top: 50px;
        }

        h1 {
            /* margin-top: 50px; */
            text-align: center;
            margin-bottom: 20px;
            background: linear-gradient(135deg, #cf9aff,#95c0ff);
            font-family: 'Arial', sans-serif;
            font-size: 2rem;
        }

        table {
            margin: 0 auto;
            border-collapse: collapse;
            width: 68%;
            margin-left: 268px;
            border: 1px solid black;
        }

        th, td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: center;
    color: black;
   
        }

        th {
            background-color: #4CAF50;
            color:black;
            letter-spacing: 1px;
        }

        table tr:nth-child(even) {
            background-color: #f2f2f2;
        }

        table tr:hover {
            background-color: #ddd;
        }

        .button {
            display: inline-block;
            padding: 10px;
            margin: 2px 0;
            font-size: 16px;
            color: white;
            background-color: #4CAF50;
            border: none;
            border-radius: 5px;
            text-decoration: none;
            cursor: pointer;
        }

        .buttond {
            display: inline-block;
            padding: 10px;
            margin: 2px 2px;
            font-size: 16px;
            color: white;
            background-color: #af4f4c;
            border: none;
            border-radius: 5px;
            text-decoration: none;
            cursor: pointer;
        }

        .buttona {
            display: inline-block;
            padding: 10px;
            margin-left: 152px;
            margin-top: 20px;
            font-size: 16px;
            color: white;
            background-color: #4CAF50;
            border: none;
            border-radius: 5px;
            text-decoration: none;
            cursor: pointer;
        }

        .button:hover {
            background-color: #45a049;
        }

        .buttond:hover {
            background-color: #cb332d;
        }

        .boxx {
            text-align: center;
            margin-bottom: 20px;
            margin-left: 772px;
        }

        .boxx input {
            padding: 10px;
            width: 200px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }

        .boxx a {
            padding: 10px;
            color: #fff;
            background:  #007bff;
            border: none;
            border-radius: 5px;
            text-decoration: none;
            cursor: pointer;
        }
    </style>
    <script>
        function searchFun() {
            var input, filter, table, tr, td, i, j, txtValue;
            input = document.getElementById('myInput');
            filter = input.value.toLowerCase();
            table = document.querySelector("table");
            tr = table.getElementsByTagName("tr");

            for (i = 1; i < tr.length; i++) {
                tr[i].style.display = "none";
                td = tr[i].getElementsByTagName("td");
                for (j = 0; j < td.length; j++) {
                    if (td[j]) {
                        txtValue = td[j].textContent || td[j].innerText;
                        if (txtValue.toLowerCase().indexOf(filter) > -1) {
                            tr[i].style.display = "";
                            break;
                        }
                    }
                }
            }
        }
    </script>
</head>
<body>
    
    <!-- <header>
        
    </header> -->
    <section class="no">
       
       
        <div>
            <h1>Notices</h1>
            <div class="boxx">
            <input type="text" id="myInput" placeholder="Search notices" onkeyup="searchFun()">
            <a href="#">
            <i class='bx bx-search-alt' ></i>
            </a>
        </div>
        </div>

       
        <table>
            <thead>
                <tr>
                    <th>Title</th>
                    <th>Date</th>
                    <th>PDF</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $sql = "SELECT * FROM notices ORDER BY notice_date DESC";
                $result = $conn->query($sql);

                if ($result->num_rows > 0) {
                    while($row = $result->fetch_assoc()) {
                        echo "<tr>";
                        echo "<td>" . $row['title'] . "</td>";
                        echo "<td>" . $row['notice_date'] . "</td>";
                        echo "<td><a href='uploads/" . $row['pdf_file'] . "' target='_blank'>";
                        echo "<img src='pdf_icon.png' alt='PDF Icon' style='width: 40px; height: 40px;'></a></td>";
                        echo "</tr>";
                    }
                } else {
                    echo "<tr><td colspan='3'>No notices found</td></tr>";
                }
                ?>
            </tbody>
        </table>
    </section>
</body>
</html>

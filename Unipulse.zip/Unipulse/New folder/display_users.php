<?php include 'sidebar.php';?>
<?php
include('connection.php');

$query = "SELECT * FROM signup";
$result = mysqli_query($conn, $query);

?>

<!DOCTYPE html>
<html>
<head>
    <title>Display Users</title>
    <!-- <link rel="stylesheet" type="text/css" href="style3.css"> -->
     <style>
        body {
    font-family: Arial, sans-serif;
    background-color: #f4f4f4;
    margin: 0;
    padding: 0;
    display: flex;
    flex-direction: column;
    /* align-items: center; */
    /* justify-content: center; */
    height: 100vh;
}

/* h2 {
    color: #333;
    margin-bottom: 20px;
} */
h1 {
    text-align: center;
    margin-top: 50px;
    margin-bottom: 20px;
    font-family: 'Arial', sans-serif;
    margin-left: 78px;
    background: linear-gradient(135deg, #cf9aff,#95c0ff);
}
table {
    border-collapse: collapse;
    width: 80%;
    margin-left: 267px;
    background: white;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    
    overflow: hidden;
    
}

table th, table td {
    padding: 15px;
    text-align: left;
    border-bottom: 1px solid #ddd;
    border-top: 1px solid #ddd;
    border-left: 1px solid #ddd;
}

table th {
    background-color: #4CAF50;
    letter-spacing: 1px;
}

table tr:nth-child(even) {
    background-color: #f2f2f2;
}

table tr:hover {
    background-color: #ddd;
}

table td a {
    text-decoration: none;
    color: #FF6347;
    font-weight: bold;
}

table td a:hover {
    text-decoration: underline;
}

.container {
    padding: 20px;
    text-align: center;
}

.container a {
    text-decoration: none;
    color: #fff;
    background-color: #4CAF50;
    padding: 10px 20px;
    
    transition: background-color 0.3s;
}

.container a:hover {
    background-color: #45a049;
}

     </style>
</head>
<body>

    <h1>User Information</h1>
    <table border="1">
        <tr>
            <th>Username</th>
            <th>Email</th>
            <th>Password</th>
        </tr>
        <?php
        while($row = mysqli_fetch_assoc($result)) {
            echo "<tr>";
            echo "<td>".$row['username']."</td>";
            echo "<td>".$row['email']."</td>";
            echo "<td>".$row['password']."</td>";
            echo "</tr>";
        }
        ?>
    </table>
</body>
</html>

<?php 


include 'config.php';
session_start();

if (!isset($_SESSION['admin_id'])) {
    header("Location: logina.php");
    exit();
}// Get the username and profile picture from the database
$admin_id = $_SESSION['admin_id'];
$sql = "SELECT usernamea, profile_picture FROM admins WHERE id=?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $admin_id);
$stmt->execute();
$result = $stmt->get_result();
$row = $result->fetch_assoc();
$username = $row['usernamea'];
$profile_picture = $row['profile_picture'];

$stmt->close();
$conn->close();
?>
<?php include 'sidebar.php';?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>University Admission Test Resources</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: antiquewhite;
        }
        h1 {
            margin-top: 50px;
            text-align: center;
            margin-bottom: 20px;
            background: linear-gradient(135deg, #cf9aff,#95c0ff);
            font-family: 'Arial', sans-serif;
            font-size: 2rem;
        }
        .resview {
            padding-left: 18em;
            padding-right: 12em;
            padding-top: 2em;
            padding-bottom: 2em;
           
        }
        .resview .subject {
            background-color: #fff;
            margin-bottom: 1em;
            border: 1px solid #ccc;
            padding: 2em;
            padding-left: 3em;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        .resview h2 {
            color: #333;
        }
        .resview h3 {
            color: #555;
        }
        .resview ul {
            list-style-type: none;
            padding: 0;
        }
        .resview li {
            margin: 0.5em 0;

        }
        .resview .pdf-icon {
            display: flex;
            align-items: center;
            font-family: Arial, sans-serif;
        }
        .resview .video-title {
            font-weight: bold;
            margin-top: 10px;
        }
        .resview .pdf-icon i {
            font-size: 20px;
            margin-right: 5px;
        }
        .resview .video-frame {
            width: 25%;
            height: 200px;
            margin-top: 5px;
        }
    </style>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
</head>
<body>
    
        <h1>University Admission Test Resources</h1>
    
    <main class="resview">
        <div class="subject">
            <h2>Physics</h2>
            <?php displayResources('physics'); ?>
        </div>
        <div class="subject">
            <h2>Chemistry</h2>
            <?php displayResources('chemistry'); ?>
        </div>
        <div class="subject">
            <h2>Math</h2>
            <?php displayResources('math'); ?>
        </div>
    </main>
</body>
</html>

<?php
function displayResources($subject) {
    $filePath = "resources/$subject.json";
    if (!file_exists($filePath)) {
        echo "<p>No resources found for $subject.</p>";
        return;
    }

    $data = file_get_contents($filePath);
    $resources = json_decode($data, true);

    foreach ($resources as $part => $chapters) {
        echo "<h3>Part $part</h3>";
        echo "<ul>";
        foreach ($chapters as $chapter => $resources) {
            echo "<li><strong>Chapter $chapter</strong>";
            foreach ($resources as $resource) {
                echo "<ul>";
                if (isset($resource['pdf'])) {
                    $pdfPath = "uploads/{$resource['pdf']}";
                    if (file_exists($pdfPath)) {
                        echo "<li class='pdf-icon'><a href='$pdfPath' target='_blank'><img src='/new folder/pdf_icon.png' alt='PDF Icon'style='width: 40px;height: 50px;'></a>{$resource['pdf_title']}</li>";
                    } else {
                        echo "<li class='pdf-icon'><img src='/new folder/pdf_icon.png' alt='PDF Icon'style='width: 40px;height: 50px;'><span>{$resource['pdf_title']} (PDF not found)</span></li>";
                    }
                }
                if (isset($resource['video'])) {
                    $video_url = str_replace("watch?v=", "embed/", $resource['video']);
                    echo "<li class='video-title'><a href='{$resource['video']}' target='_blank'></a>{$resource['video_title']}</li>";
                    echo "<li><iframe class='video-frame' src='$video_url' frameborder='0' allowfullscreen></iframe></li>";
                }
                echo "</ul>";
            }
            echo "</li>";
        }
        echo "</ul>";
    }
}
?>

<?php include 'sidebar.php';?>
<?php

include 'db_uni.php'; // File to connect to the database

$message = ''; // Variable to store the message

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $logo_url = $_POST['logo_url'];
    $name = $_POST['name'];
    $website = $_POST['website'];
    $type = $_POST['type'];
    $details_url = $_POST['details_url'];

    $sql = "INSERT INTO universities (logo_url, name, website, type, details_url) 
            VALUES ('$logo_url', '$name', '$website', '$type', '$details_url')";
    
    if ($conn->query($sql) === TRUE) {
        $message = "New university added successfully";
    } else {
        $message = "Error: " . $sql . "<br>" . $conn->error;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Upload University</title>
    <style>
        body {
            font-family: 'Roboto', sans-serif;
            background-color: antiquewhite;
            margin: 0;
            padding: 0;
        }

        .container {
            background: #11101d;
            padding: 20px;
        }

        h1 {
            margin-top: 50px;
            text-align: center;
            margin-bottom: 10px;
            background: linear-gradient(135deg, #cf9aff, #95c0ff);
            padding: 7px;
            border-radius: 5px;
            color: black;
            font-family: 'Roboto', sans-serif;
            font-size: 31px;
        }

        form {
            margin: 0 auto;
            margin-top: 32px;
            margin-bottom: 6px;
            display: flex;
            flex-direction: column;
            width: 400px;
            background: linear-gradient(135deg, #cf9aff, #95c0ff);
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        label {
            margin-bottom: 10px;
            font-weight: bold;
            color: black;
        }

        input[type="text"],
        input[type="url"] {
            padding: 10px;
            margin-bottom: 20px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }

        button[type="submit"] {
            padding: 10px 20px;
            background: linear-gradient(#9418fd, #571094);
            color: #fff;
            font-weight: bold;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        button[type="submit"]:hover {
            background-color: #570c8e;
        }
    </style>
    <script>
        function showAlert(message) {
            if (message) {
                alert(message);
                // If the message indicates success, redirect to edit_uni.php
                if (message === "New university added successfully") {
                    window.location.href = 'edit_uni.php';
                }
            }
        }
    </script>
</head>
<body onload="showAlert('<?php echo $message; ?>')">

<header class="navbar">
    <!-- Include your sidebar content here -->
</header> 

<section class="upload">
    <h1>Upload University Details</h1>
    <form action="upload_uni.php" method="POST">
        <label for="logo_url">Logo URL:</label>
        <input type="text" name="logo_url" required><br>

        <label for="name">University Name:</label>
        <input type="text" name="name" required><br>

        <label for="website">Website:</label>
        <input type="text" name="website" required><br>

        <label for="type">Type:</label>
        <input type="text" name="type" required><br>

        <label for="details_url">Details URL:</label>
        <input type="text" name="details_url" required><br>

        <button type="submit">Upload</button>
    </form>
</section>

</body>
</html>

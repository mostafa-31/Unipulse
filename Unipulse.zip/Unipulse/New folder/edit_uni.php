<?php include 'sidebar.php';?>
<?php
include 'db_uni.php'; // File to connect to the database

// Handle deletion
if (isset($_GET['delete_id'])) {
    $delete_id = $_GET['delete_id'];
    $sql = "DELETE FROM universities WHERE id=$delete_id";
    
    if ($conn->query($sql) === TRUE) {
        echo "<script>alert('University deleted successfully'); window.location.href='edit_uni.php';</script>";
    } else {
        echo "Error deleting record: " . $conn->error;
    }
}

// Handle editing
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['update_id'])) {
    $id = $_POST['update_id'];
    $logo_url = $_POST['logo_url'];
    $name = $_POST['name'];
    $website = $_POST['website'];
    $type = $_POST['type'];
    $details_url = $_POST['details_url'];

    $sql = "UPDATE universities SET logo_url='$logo_url', name='$name', website='$website', type='$type', details_url='$details_url' WHERE id=$id";

    if ($conn->query($sql) === TRUE) {
        echo "<script>alert('University updated successfully'); window.location.href='edit_uni.php';</script>";
    } else {
        echo "Error updating record: " . $conn->error;
    }
}

// Fetch all data from universities table
$sql = "SELECT * FROM universities";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Universities</title>
    <style>
        body {
            font-family: 'Roboto', sans-serif;
            background-color: antiquewhite;
        }
        h1 {
            margin-top: 50px;
            text-align: center;
            margin-bottom: 10px;
            background: linear-gradient(135deg, #cf9aff, #95c0ff);
            padding: 7px;
            border-radius: 5px;
            color: black;
            font-family: 'Roboto', sans-serif;
            font-size: 31px;
        }

        .container {
            padding-right: 31px;
            padding-top: 65px;
            padding-left: 277px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        table, th, td {
            border: 1px solid #ccc;
        }

        th, td {
            padding: 10px;
            text-align: center;
        }

        th {
            background-color: #31e916;
}
        

        .edit-form {
            display: none;
            margin-bottom: 20px;
        }

        .edit-form input[type="text"] {
            padding: 10px;
            margin: 10px 0;
            width: 100%;
        }

        .edit-form button {
            padding: 10px 20px;
            background-color: #28a745;
            color: #fff;
            border: none;
            cursor: pointer;
        }

        .edit-form button:hover {
            background-color: #218838;
        }

        button.delete {
            background-color: #dc3545;
            color: white;
            border: none;
            padding: 10px 20px;
            cursor: pointer;
            border-radius: 5px;
        }

        button.delete:hover {
            background-color: #c82333;
        }
    </style>
</head>
<body>
<h1>Edit Universities</h1>
    
<div class="container">
    
    <table>
        <thead>
            <tr>
                <th>No.</th>
                <th>Logo</th>
                <th>Name</th>
                <th>Website</th>
                <th>Type</th>
                <th>Details</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php 
            $serialNo = 1; // Start the serial number from 1
            while($row = $result->fetch_assoc()) { ?>
                <tr>
                    <td><?php echo $serialNo++; ?></td> <!-- Increment serial number -->
                    <td><img src="<?php echo $row['logo_url']; ?>" alt="Logo" style="width: auto; height: 50px;"></td>
                    <td><?php echo $row['name']; ?></td>
                    <td><a href="<?php echo $row['website']; ?>" target="_blank"><?php echo $row['website']; ?></a></td>
                    <td><?php echo $row['type']; ?></td>
                    <td><a href="<?php echo $row['details_url']; ?>" target="_blank" style="text-decoration:none">Details</a></td>
                    <td>
                        <a href="edit_uni.php?delete_id=<?php echo $row['id']; ?>"><button class="delete">Delete</button></a>
                    </td>
                </tr>
            <?php } ?>
        </tbody>
    </table>
</div>

</body>
</html>

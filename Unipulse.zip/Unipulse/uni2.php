<?php
session_start();
if(!isset($_SESSION['loggedin'])){
  header("location:login.php");
  ob_end_flush();
}

include 'db_uni.php'; // File to connect to the database

// Fetch university data from database
$sql = "SELECT * FROM universities";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>University</title>
<!-- favicon -->
<link rel="icon" type="image/x-icon" href="images/logon3.png">
    <link rel="stylesheet" href="uni2b.css">
    <style>
        .home2 .content{
            margin-top: 102px;
        }
        .boxx{
            margin-top: 25px;
        }
    </style>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css"/>
</head>
<body>

<header class="navbar">
    <?php include 'header.php';?>
</header> 

<section class="home2">
    <div class="content" >
        <h3 class="typing">Explore Your Future University</h3> 
    </div>
    <div class="boxx">
        <input type="text" id="myInput" placeholder="search university" onkeyup="searchFun()">
        <a href="#"><i class="fas fa-search"></i></a>
    </div>
    <div> 
        <h2>Most popular universities of BD</h2>
    </div>
</section>

<section class="header_fixed">
    <table id="myTable">
        <thead>
            <tr>
                <th>S No.</th>
                <th>Logo</th>
                <th>University Name</th>
                <th>Website</th>
                <th>Type</th>
                <th>Detail</th>
            </tr>
        </thead>
        <tbody>
            <?php
            if ($result->num_rows > 0) {
                $serial_no = 1;
                while ($row = $result->fetch_assoc()) {
                    echo "<tr>";
                    echo "<td>" . $serial_no . "</td>";
                    echo "<td><img src='" . $row['logo_url'] . "' alt='" . $row['name'] . " Logo' /></td>";
                    echo "<td>" . $row['name'] . "</td>";
                    echo "<td><a href='" . $row['website'] . "'>" . $row['website'] . "</a></td>";
                    echo "<td>" . $row['type'] . "</td>";
                    echo "<td><a href='" . $row['details_url'] . "'><button>View</button></a></td>";
                    echo "</tr>";
                    $serial_no++;
                }
            } else {
                echo "<tr><td colspan='6'>No universities found</td></tr>";
            }
            ?>
        </tbody>
    </table>
</section>

<?php include 'footer.php';?>

<script>
    function searchFun() {
        let filter = document.getElementById('myInput').value.toUpperCase();
        let myTable = document.getElementById('myTable');
        let tr = myTable.getElementsByTagName('tr');
        
        for (let i = 1; i < tr.length; i++) {
            let td = tr[i].getElementsByTagName('td')[2];
            if (td) {
                let textValue = td.textContent || td.innerHTML;
                if (textValue.toUpperCase().indexOf(filter) > -1) {
                    tr[i].style.display = "";
                } else {
                    tr[i].style.display = "none";
                }
            }       
        }
    }
</script>

</body>
</html>

<?php
    session_start();
    if(!isset($_SESSION['loggedin']) || isset($_SESSION['loggedin'])!=true){
        header("location:login.php");
        exit;
    }
?>
<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet"  href="style.css">
<style>
body {
  font-family: Arial, Helvetica, sans-serif;
  background-color: #7bcd6b91;
}
.conun {
  max-width: 1000px;
  margin: 50px auto;
  padding: 20px;
  background-color: #fff;
  box-shadow: 0 0 10px rgba(0, 0, 0, 0.7);
  margin-top: 108px;
}
.conun h1 {
    font-size: 2.5em;
  color: #333;
  margin-bottom: 30px;
  
}
.conun p {
  line-height: 1.5;
  margin-bottom: 20px;
}


.conun p {
    line-height: 1.6;
  color: #555;
  margin-bottom: 15px;
}

.conun ul {
  list-style-type: disc;
  margin-left: 20px;
  padding-bottom: 30px ;
}

.conun ul li {
  margin-bottom: 5px;
  color: #555;
}

.conun ul li a {
  color: blue;
  text-decoration: none;
}

.conun ul li a a:hover {
  text-decoration: underline;
}
.conun table {
  font-family: arial, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

.conun td, th {
  border: 1px solid #dddddd;
  text-align: left;
  padding: 8px;
  /* text-decoration: none; */
}
table td a{
    text-decoration: none;
}
.conun tr:nth-child(even) {
  background-color: #dddddd;
}
</style>
</head>
<body>
<?php include 'header.php';?>
<div class="conun">

    <h1>Universities in the USA</h1>
    
    <p>Situated in North America, the USA boasts a vast landscape ranging from bustling cities to wide open natural wonder. It can boast of a renowned education system with many prestigious universities and colleges and is the world’s most popular destination for international students, with over 1 million students currently studying abroad in the United States.</p>
    
    <p>Whilst the United States does not have an official language, English is the official language in many of the 50 states and English is the most widely spoken language in the country. Of the other languages spoken throughout the country, Spanish is the second most popular.</p>
    
    <h1>Popular cities for students</h1>

<p>Some of the most popular cities in the USA for international students include:</p>

<ul>
  <li><a href="https://studylink.com/countries/usa/universities-in-san-francisco/">San Francisco</a> -  located in Northern California, on the west coast of the United States, San Francisco is one of the state of California’s most populous cities and is a hotbed of technology companies. With the iconic Golden Gates Bridge</li>
  <li><a href="https://studylink.com/countries/usa/universities-in-chicago/">Chicago </a> - Situated in the Midwestern United States in the state of Illinois, Chicago is one of the most populous cities in the USA. Based on Lake Michigan, Chicago is famous for its jazz scene and performing arts culture, its skyline and architecture</li>
  <li><a href="https://studylink.com/countries/usa/universities-in-new-york-city/">New York City </a> -In terms of population size, New York City is the largest city in the United States, with a population of over 8 million people. With points of interest and attractions as far as the eye can see, New York offers something for everyone.</li>
  <li><a href="https://studylink.com/countries/usa/universities-in-boston/">Boston </a> - The capital city of the state of Massachusetts in the north east of the United States, Boston is a city full of culture and history for international students to enjoy. In terms of education, Boston is home to some of the most prestigious universities in the world, including Harvard University and Massachusetts Institute of Technology (MIT).</li>
  <li><a href="https://studylink.com/countries/usa/universities-in-los-angeles/">Los Angeles</a>- the largest city in the north of the Netherlands, Groningen is home to 3 universities</li>
</ul>
    








<h1>The top universities in the USA</h1>

<p>The USA is home to some of the most prestigious universities anywhere in the world, some of which regularly feature at the top of various world university rankings.</p>


<h2>Table of the top ranked universities in the US</h2>

<table>

  <tr>

    <th>University</th>

    <th>Times Higher Education World University Ranking 2024</th>

    <th>Best Global Universities</th>

    <th>QS World University Ranking</th>

  </tr>

  <tr>

    <td><a href="https://www.stanford.edu/">Stanford University</a></td>

    <td>2</td>

    <td>3</td>

    <td>5</td>

  </tr>

  <tr>

    <td><a href="https://www.mit.edu/">Massachusetts Institute of Technology</a></td>

    <td>3</td>

    <td>2</td>

    <td>1</td>

  </tr>

  <tr>

    <td><a href="https://www.harvard.edu/">Harvard University</a></td>

    <td>4</td>

    <td>1</td>

    <td>4</td>

  </tr>

  <tr>

    <td><a href="https://www.princeton.edu/">Princeton University</a></td>

    <td>6</td>

    <td>16</td>

    <td>17</td>

  </tr>

  <tr>

    <td><a href="https://www.caltech.edu/">California Institute of Technology</a></td>

    <td>7</td>

    <td>9</td>

    <td>15</td>

  </tr>

  <tr>

    <td><a href="https://www.berkeley.edu/">University of California, Berkeley</a></td>

    <td>9</td>

    <td>4</td>

    <td>10</td>

  </tr>

  <tr>

    <td><a href="https://www.yale.edu/">Yale University</a></td>

    <td>10</td>

    <td>11</td>

    <td>16</td>

  </tr>

  <tr>

    <td><a href="https://www.uchicago.edu/">The University of Chicago</a></td>

    <td>13</td>

    <td>22</td>

    <td>11</td>

  </tr>

  <tr>

    <td><a href="https://www.jhu.edu/">Johns Hopkins University</a></td>

    <td>15</td>

    <td>10</td>

    <td>28</td>

  </tr>

</table>
</div>
    
</body>
</html>

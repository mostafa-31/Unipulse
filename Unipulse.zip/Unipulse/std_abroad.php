<?php
    session_start();
    if(!isset($_SESSION['loggedin']) || isset($_SESSION['loggedin'])!=true){
        header("location:login.php");
        exit;
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Study Abroad</title>
    <style>
        *{
    padding: 0;
    margin: 0;
  
}
.back{
    background-image: url(https://media.intostudy.com/image/upload/w_1200,q_auto/v1687447107/Marketing_Team/ContentfulV1/US-travel-policy-vaccine-hero-image.jpg);
    width: 100%;
height: 100vh;
background-size: cover;
background-position: center;
display: flex;
flex-direction: column;
justify-content: start;
align-items: start;
text-align: start;

}
.back h2{
    font-family: serif;
    color: bisque;
    margin-left: 311px;
  margin-top: 248px;
    font-size: 6rem;
    
}
body {
    font-family: Arial, sans-serif;
    margin: 0;
    padding: 0;
    background-color: #f8f9fa;
}

.seched {
    text-align: center;
    padding: 4rem;
    background-color: #fff;
    border-bottom: 1px solid #dee2e6;
}

.seched h1 {
    font-size: 2.5rem;
    color: #333;
    margin-bottom: 2rem;
}

.seched p {
    font-size: 1.1rem;
    color: #555;
    
  
}

.opt {
    padding: 2rem;
    background-color: #f8f9fa;
}
.opt h2 {
    text-align: center;
    font-size: 2.5rem;
    color: #333;
    margin-bottom: 2rem;
}

.card-container {
    display: flex;
    justify-content: space-around;
    flex-wrap: wrap;
}

.cardab {
    background-color: #fff;
    border: 1px solid #dee2e6;
    border-radius: 8px;
    box-shadow: 7px 7px 5px #dfdcdc;
    max-width: 300px;
    margin: 1rem;
    text-align: center;
    overflow: hidden;
}
 .cardab:hover{
cursor: pointer;
box-shadow:5px 5px 10px #dfdcdc;
/* color: darkorange; */
transition-duration: .4s;
transform: scale(1.2);
}
.cardab img {
    width: 100%;
    height: 220px;
}

.cardab h3 {
    font-size: 1.5rem;
    color: #333;
    margin: 1rem 0;
}

.cardab p {
    font-size: 1rem;
    color: #666;
    padding: 0 1rem;
}

.cardab a {
    display: inline-block;
    margin: 1rem 0 2rem;
    padding: 0.5rem 1rem;
    background-color: #004a45;
    color: #fff;
    text-decoration: none;
    border-radius: 4px;
    transition: background-color 0.3s ease;
}

.cardab a:hover {
    background-color: #00332f;
}
.why-study-abroad {
    background-color: #fff;
    padding: 2rem;
    margin: 2rem 0;
    border: 1px solid #dee2e6;
    border-radius: 8px;
    box-shadow: 0 2px 5px rgba(0,0,0,0.1);
}

.why-study-abroad h2 {
    text-align:left;
    font-size: 2.5rem;
    color: #333;
    margin-bottom: 1rem;
}

.why-study-abroad ul {
    list-style-type: disc;
    padding-left: 2rem;
    color: #666;
    font-size: 1rem;
}

.why-study-abroad ul li {
    margin: 0.5rem 0;
}
.how-to-apply {
    background-color: #fff;
    padding: 2rem;
    margin: 2rem 0;
    border: 1px solid #dee2e6;
    border-radius: 8px;
    box-shadow: 0 2px 5px rgba(0,0,0,0.1);
}

.how-to-apply h2 {
    text-align: center;
    font-size: 2.5rem;
    color: #333;
    margin-bottom: 1rem;
}

.how-to-apply p {
    text-align: center;
    font-size: 1.1rem;
    color: #666;
    margin-bottom: 2rem;
}

.steps-container {
    display: flex;
    justify-content: space-around;
    flex-wrap: wrap;
}

.step {
    background-color: #f8f9fa;
    border: 1px solid #333;
    border-radius: 8px;
    box-shadow: 0 2px 5px rgba(0,0,0,0.1);
    max-width: 250px;
    margin: 1rem;
    text-align: center;
    padding: 1rem;
    overflow: hidden;
}

.step h3 {
    font-size: 2rem;
    color: #333;
    margin: 0.5rem 0;
}

.step img {
    width: 267px;
    height: auto;
    margin-bottom: 1rem;
}

.step h4 {
    font-size: 1.2rem;
    color: #333;
}
.step p {
    font-size: 1rem;
    color: #666;
    padding: 0 1rem;
}

.apply-now {
    text-align: center;
    margin-top: 2rem;
}

.apply-now h4 {
    font-size: 1.5rem;
    color: #333;
    margin-bottom: 1rem;
}

.apply-button {
    display: inline-block;
    padding: 0.5rem 1.5rem;
    background-color: #004a45;
    color: #fff;
    text-decoration: none;
    border-radius: 4px;
    transition: background-color 0.3s ease;
    cursor: pointer;
}

.apply-button:hover {
    background-color: #00332f;
}
.visa {
    background-color: #fff;
    padding: 2rem;
    margin: 2rem 0;
    border: 1px solid #dee2e6;
    border-radius: 8px;
    box-shadow: 0 2px 5px rgba(0,0,0,0.1);
    
}

.visa h1 {
    text-align: left;
    font-size: 2.5rem;
    color: #333;
    margin-bottom: 1rem;
}

.visa p {
    font-size: 1rem;
    color: #666;
    
}

.visa .cardv {
  background-color: #fff;
  border-radius: 8px;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
  padding: 24px;
  width: 100%;
  max-width: 600px;
  margin-bottom: 24px;
  
}

.visa .card-titlev {
  font-size: 20px;
  font-weight: medium;
  margin-bottom: 16px;
  font-family: Arial, sans-serif;
  
}

.visa .card-contentv {
  font-size: 16px;
  line-height: 1.5;
  font-family: Arial, sans-serif;
  font-weight: normal;
}

.card-buttonv {
    display: inline-block;
    padding: 0.5rem 1.5rem;
    background-color: #004a45;
    color: #fff;
    text-decoration: none;
    border-radius: 4px;
    transition: background-color 0.3s ease;
    cursor: pointer;
    font-family: Arial, sans-serif;
}

.card-buttonv:hover {
    background-color: #00332f;
}

.visa .cardv .image {
  width: 100%;
  max-width: 300px;
  border-radius: 8px;
}
.ques{
    background-color: #fff;
    padding: 2rem;
    margin: 2rem 0;
    border: 1px solid #dee2e6;
    border-radius: 8px;
    box-shadow: 0 2px 5px rgba(0,0,0,0.1);
    font-family: Arial, sans-serif;
}
.ques h1, h2, h3 {
      margin-bottom: 10px;
    }
    .ques h1 {
      font-size: 2.5rem;
      color: #333;
        margin-bottom: 20px;
    }
    .ques h2 {
      font-size: 1.5rem;
      color: #321;
    }
    .ques h3 {
      font-size: 1rem;
      color: #333;
    }

    .ques p {
      margin-bottom: 15px;
      color: #555;
    }
    .ques .offer-type {
      margin-bottom: 20px;
    }
    .ques .conditions-list {
      margin-bottom: 30px;
    }
    .ques .accordion {
      background-color: #fff3ff;
      color: #323;
      font-family: Arial, sans-serif;
      cursor: pointer;
      padding: 18px;
      width: 100%;
      border: none;
      text-align: left;
      outline: none;
      font-size: 15px;
      transition: 0.4s;
      box-shadow:10px 10px 10px #dfdcdc;
    }
    .ques .accordion:hover {
      background-color: #ccc;
    }
    .ques .accordion:after {
      content: '\002B';
      font-size: 13px;
      color: #777;
      float: right;
      margin-left: 5px;
    }
    .ques .active:after {
      content: '\02212';
    }
    .ques .panel {
      padding: 0 18px;
      background-color: white;
      max-height: 0;
      overflow: hidden;
      transition: max-height 0.4s ease-out;
      font-size: 15px;
    }
    </style>
    <!-- <link rel="stylesheet" href="scholar2.css"> -->
    <link rel="stylesheet" href="style.css" >
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.2/css/all.min.css"/>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" integrity="sha512-DTOQO9RWCH3ppGqcWaEA1BIZOC6xxalwEsw9c2QQeAIftl+Vegovlnee1c9QX4TctnWMn13TZye+giMm8e2LwA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
</head>
<body>
    <!-- navigation -->
   
    <?php include 'header.php';?>
    <section>
      <div class="back">
        <h2> STUDY IN ABROAD </h2>
      </div>
      </section>
      <header class="seched">
        <h1>Study abroad - your adventure starts here</h1>
        <p>Travel to new countries. Experience different cultures. Make friends from all over the world. Studying abroad really is the opportunity of a lifetime. It’s your chance to start your journey.</p>
        <p>You’ll also get to continue your education abroad at some of the world’s best universities.</p>
    </header>
    <section class="opt">
        <h2>Popular study abroad destinations</h2>
        <div class="card-container">
            <div class="cardab">
                <img src="http://www.foreignstudents.com/sites/default/files/imagecache/blog_515/cambridge_kings_college_comp_2.jpg" alt="Study abroad in the UK">
                <h3>Study abroad in the United Kingdom</h3>
                <p>Famous for its history, traditions, culture and scenery, the UK is a unique, multicultural country.</p>
                <a href="std_usa_study.php">Discover the UK</a>
            </div>
            <div class="cardab">
                <img src="https://www.timeshighereducation.com/student/sites/default/files/styles/default/public/2021-09/harvard-university-campus.jpg?itok=SK_1MUqi" alt="Study abroad in the US">
                <h3>Study abroad in the United States of America</h3>
                <p>Huge, diverse and welcoming, the US is the number one destination for international students who want to study overseas.</p>
                <a href="std_usa_study.php">Explore the US</a>
            </div>
            <div class="cardab">
                <img src="https://foundtheworld.com/wp-content/uploads/2016/05/Amsterdam-Netherlands-4.jpg" alt="Study abroad in Australia">
                <h3>Study abroad in Nederlands</h3>
                <p>In Nederlands, overseas students represent 25% of all university students. Here’s why the country is so popular.</p>
                <a href="std_ned_study.php">Explore Nederlands</a>
            </div>
        </div>
    </section>
    <section class="why-study-abroad">
        <h2>Why study abroad?</h2>
        <ul>
            <li>Discover amazing places</li>
            <li>Gain new cultural experiences and perspectives</li>
            <li>Improve your foreign language skills</li>
            <li>Develop personally and professionally</li>
            <li>Improve your career prospects</li>
            <li>Make lifelong friends</li>
            <li>It's fun!</li>
        </ul>
    </section>
    <section class="how-to-apply">
        <h2>How to apply</h2>
        <p>Study abroad in 5 simple steps. Follow the instructions below to submit your application and start your international study journey in the UK, US or Australia.</p>
        <div class="steps-container">
            <div class="step">
                <!-- <h3>1</h3> -->
                <img src="https://media.intostudy.com/image/upload/w_1200,q_auto/v1712070676/How_to_apply_Step1.gif" alt="Complete your application form">
                <h4>Complete your application form</h4>
                <p>Look out for your confirmation email – this shows we’ve received your application.</p>
            </div>
            <div class="step">
                <!-- <h3>2</h3> -->
                <img src="https://media.intostudy.com/image/upload/w_1200,q_auto/v1712070454/How_to_apply_Step2.gif" alt="Submit your documents">
                <h4>Submit your documents</h4>
                <p>Transfer them safely and easily by signing up to My Account.</p>
            </div>
            <div class="step">
                <!-- <h3>3</h3> -->
                <img src="https://media.intostudy.com/image/upload/w_1200,q_auto/v1712070207/How_to_apply_Step3.gif" alt="Receive your offer letter">
                <h4>Receive your offer letter</h4>
                <p>This includes details of your offer, conditions, accommodation and tuition fees.</p>
            </div>
            <div class="step">
                <!-- <h3>4</h3> -->
                <img src="https://media.intostudy.com/image/upload/w_1200,q_auto/v1712069211/How_to_apply_Step4.gif" alt="Accept your place">
                <h4>Accept your place</h4>
                <p>Pay your deposit to secure your place, then meet the conditions of your offer.</p>
            </div>
            <div class="step">
                <!-- <h3>5</h3> -->
                <img src="https://media.intostudy.com/image/upload/w_1200,q_auto/v1712069455/How_to_apply_Step5.gif" alt="Apply for your visa">
                <h4>Apply for your visa</h4>
                <p>We’ll provide the documents you need, and our visa support team are here to help.</p>
            </div>
            <div class="step">
            <img src="https://media.intostudy.com/image/upload/w_1200,q_auto/v1712072172/How_to_apply_apply.gif" alt="">
                <h4>Start your application today</h4>
                <a href="https://www.intostudy.com/en/search" class="apply-button">Apply now</a>
            </div>
        </div>
    </section>
    <section class="visa">
    
  <h1>Where can I get help with my application?</h1>
  <p>We offer expert support from application to graduation - so your access to our dedicated services starts now. Get in touch to ask any further questions or for help with any aspect of your application.</p>

  <div class="cardv">
  <img src="https://static1.squarespace.com/static/57dfec41ff7c5017de119d61/5ec5908d8285ee52e4eaef3c/5edec06f45507249767d7586/1593026071056/VISA_Banner.gif?format=1500w" alt="Image" class="image">

    <div class="card-titlev">Visa support</div>
    <div class="card-contentv">Discover everything you need to know about applying for a visa to study abroad.</div>
    <a href="std_abroadvisa.php"><button class="card-buttonv">Read</button></a>
  </div>

  
    </section>
    <section class="ques">
    <h1>Your application questions, answered</h1>

<h2>What kind of offer could I receive?</h2>

<p>Once you've submitted your application form, you could receive one of the following offers:</p>

<div class="offer-type">
  <h3>Unconditional</h3>
  <p>There are no conditions you need to meet to secure your place on your chosen course.</p>
</div>

<div class="offer-type">
  <h3>Conditional</h3>
  <p>You need to meet certain conditions, such as academic and English language requirements, to secure your place. Your specific conditions will vary depending on your course type, subject, university and study length. You'll find full details in your offer letter.</p>
</div>

<h2>What conditions might I need to meet before I can accept my offer?</h2>

<p>Your offer letter will include full details of any conditions you must meet, such as:</p>

<button class="accordion">Academic requirements</button>
<div class="panel">
  <p>While our courses will equip you with the academic skills you need to excel at university, you'll need a certain amount of previous education to study with us.</p>
  <p>This usually involves completion of education for a specified length of time or to a specified study level, such as a high school diploma or undergraduate degree. </p>
</div>
<button class="accordion">English language requirements</button>
<div class="panel">
  <p>Each course has a required level of English, which is assessed using a range of approved tests</p>
  <p>Depending on the type of course you’ve applied for, you may need to take a
Secure English Language Test
such as IELTS. For some courses, such as our iCAS options, alternative English language tests may be accepted. </p>
<p>
If you don’t meet the English language requirement for your desired pathway program, don’t worry – we offer a range of courses to help you boost your score. 
</p>
</div>

<script>
  var acc = document.getElementsByClassName("accordion");
  var i;

  for (i = 0; i < acc.length; i++) {
    acc[i].addEventListener("click", function() {
      this.classList.toggle("active");
      var panel = this.nextElementSibling;
      if (panel.style.maxHeight) {
        panel.style.maxHeight = null;
      } else {
        panel.style.maxHeight = panel.scrollHeight + "px";
      } 
    });
  }
</script>
    </section>
    <?php include 'footer.php';?>
    </body>
    </html>
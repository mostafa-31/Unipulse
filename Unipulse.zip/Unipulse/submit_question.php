<?php
session_start();
if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    header("location: login.php");
    exit;
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    require 'configq.php'; // Your database configuration

    $question = $conn->real_escape_string($_POST['question']);
    $username = $_SESSION['username'];

    $sql = "INSERT INTO questions (username, question) VALUES ('$username', '$question')";
    if ($conn->query($sql) === TRUE) {
        echo "<script>
                window.onload = function() {
                    alert('Question submitted successfully!');
                    window.location.href = 'unipulse.php';
                }
              </script>";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }

    $conn->close();
}
?>

<?php
session_start();

// Ensure the user is logged in as admin
// if (!isset($_SESSION['admin_loggedin'])) {
//     header("Location: login.php");
//     exit();
// }

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $subject = $_POST['subject'];
    $file = $_FILES['questionsFile'];

    // Check if a file was uploaded and there's no error
    if ($file['error'] === 0) {
        // Set the target path for the uploaded file
        $target_dir = "./new folder/resources/";
        $target_file = $target_dir . $subject . "_questions.json";

        // Move the uploaded file to the target directory
        if (move_uploaded_file($file['tmp_name'], $target_file)) {
            echo "<p>Questions uploaded successfully!</p>";
        } else {
            echo "<p>Error uploading file.</p>";
        }
    } else {
        echo "<p>There was an error with the file upload.</p>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Upload Questions</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f0f0f0;
        }
        h2 {
            text-align: center;
            margin-top: 30px;
        }
        .upload-form {
            width: 50%;
            margin: 30px auto;
            background-color: #fff;
            padding: 20px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        .upload-form label {
            display: block;
            margin-bottom: 10px;
        }
        .upload-form select,
        .upload-form input[type="file"],
        .upload-form button {
            display: block;
            width: 100%;
            padding: 10px;
            margin-bottom: 20px;
            font-size: 16px;
        }
    </style>
</head>
<body>

<h2>Upload Questions for Quiz</h2>

<div class="upload-form">
    <form action="upload_questions.php" method="POST" enctype="multipart/form-data">
        <label for="subject">Select Subject:</label>
        <select name="subject" id="subject" required>
            <option value="physics">Physics</option>
            <option value="chemistry">Chemistry</option>
            <option value="math">Math</option>
        </select>

        <label for="questionsFile">Upload Questions JSON File (30 Questions):</label>
        <input type="file" name="questionsFile" id="questionsFile" accept=".json" required>

        <button type="submit">Upload</button>
    </form>
</div>

</body>
</html>

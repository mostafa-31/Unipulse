<?php
    session_start();
    if(!isset($_SESSION['loggedin']) || isset($_SESSION['loggedin'])!=true){
        header("location:aboutindex.php");
        exit;
    }
?>

<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <meta name="viewport" 
          content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" 
          href="abou.css">
    <title>About Us</title>
</head>

<body>
    <header>
   
    </header>

    <section class="about">
        <h1>About Us</h1>
        <p style="font-weight: bold">
          GeeksforGeeks is a leading platform...
          </p>
        <div class="about-info">
            <div class="about-img">
                <img src=
"https://media.geeksforgeeks.org/wp-content/uploads/20230824153359/
 371ba38b-8a03-4bff-916c-c3fa5396ceda.jfif" alt="Geeksforgeeks">
            </div>
            <div>
            <p> UniPulse.com has helped millions of future college students Scholarship and find the perfect college. We’ve worked with thousands of schools to make sure we have the most up-to-date information and resources for University students around the country. Whether you’re looking for an Academic degree, financial aid, career guides, University rankings, or just plain University information, we’ve got you covered. UniPulse.com is your one stop shop for all things college to help fit your University needs.
            </p>
                <button>Read More...</button>
            </div>
        </div>
    </section>

    <section class="team">
        <h1>Meet Our Team</h1>
        <div class="team-cards">
          
            <!-- Cards here -->
            <!-- Card 1 -->
          
            <div class="card">
                <div class="card-img">
                    <img src=
"avter.png" alt="User 1">
                </div>
                <div class="card-info">
                    <h2 class="card-name">Mostafa</h2>
                    <p class="card-role">Fontend Devoloper</p>
                    <p class="card-email">mostafa@gmail.com</p>
                    <p><button class="button">Contact</button></p>
                </div>
            </div>

            <!-- Card 2 -->
          
            <div class="card">
                <div class="card-img">
                    <img src=
"avter.png" alt="User 2">
                </div>
                <div class="card-info">
                    <h2 class="card-name">Shahid</h2>
                    <p class="card-role">Backend Devoloper</p>
                    <p class="card-email">shahida@gmail.com</p>
                    <p><button class="button">Contact</button></p>
                </div>
            </div>
          
            <!-- Card 3 -->
          
            <div class="card">
                <div class="card-img">
                    <img src=
"avter.png" alt="User 3">
                </div>
                <div class="card-info">
                    <h2 class="card-name">Utshab</h2>
                    <p class="card-role">Admin</p>
                    <p class="card-email">Utshab@gmail.com</p>
                    <p><button class="button">Contact</button></p>
                </div>
            </div>
        </div>
    </section>

    <footer>
        <p>&copy; 2023 GeeksforGeeks. All Rights Reserved.</p>
    </footer>
</body>

</html>

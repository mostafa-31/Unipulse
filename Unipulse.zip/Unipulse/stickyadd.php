<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sticky Advertisement</title>

    <!-- Link to Google Font (example: 'Roboto') -->
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@700&display=swap" rel="stylesheet">

    <style>
        /* Add some height to simulate a longer homepage */
        body {
            padding-bottom: 2000px;
        }

        /* Style for the sticky ad section */
        #sticky-ad {
            position: sticky;
            top: 100px; /* Ad will stick when it reaches 100px from the top */
            right: 0;
            width: 250px;
            background-color: #f9ed69;
            padding: 15px;
            text-align: center;
            box-shadow: 0px 2px 10px rgba(0, 0, 0, 0.3);
            z-index: 1000;
            border-radius: 10px 0 0 10px;
        }

        /* Close button style */
        .close-btn {
            position: absolute;
            top: 10px;
            right: 15px;
            background-color: #ff4d4d;
            color: white;
            border: none;
            border-radius: 50%;
            padding: 5px 10px;
            cursor: pointer;
            font-size: 16px;
        }

        /* Style for the image with drop shadow */
        #sticky-ad img {
            width: 200px;
            border-radius: 5px;
            filter: drop-shadow(3px 3px 3px rgba(0, 0, 0, 0.8));
        }

        /* Style for the title above the image */
        #sticky-ad h2 {
            font-family: 'Roboto', sans-serif;
            font-size: 18px;
            color: #333;
            margin-bottom: 10px;
        }

        /* Anchor (link) style */
        #sticky-ad a {
            color: #333;
            font-weight: bold;
            text-decoration: none;
            display: block;
            margin-top: 10px;
        }

        #sticky-ad a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>

    <!-- Content of the homepage -->
    <div id="content">
        <h1>Welcome to the Homepage</h1>
        <p>Scroll down to see the sticky advertisement...</p>
    </div>

    <!-- Sticky ad -->
    <div id="sticky-ad">
        <button class="close-btn" onclick="closeAd()">X</button>
        <h2>Check out our game!</h2>
        <img src="./images/snak.png" alt="Snake Game">
        <a href="snake.php" target="_blank">Play Snake Game</a>
    </div>

    <script>
        // Function to close the ad
        function closeAd() {
            document.getElementById('sticky-ad').style.display = 'none';
        }
    </script>

</body>
</html>





<?php
session_start();
include_once('connection.php');

if (isset($_POST['pwdrst'])) {
    $email = $_POST['email'];
    $check_email = mysqli_query($conn, "SELECT email FROM signup WHERE email='$email'");
    $res = mysqli_num_rows($check_email);

    if ($res > 0) {
        $message = '
            <div>
                <p><b>Hello!</b></p>
                <p>You are receiving this email because we received a password reset request for your account.</p>
                <br>
                <p><button class="btn btn-primary"><a href="http://localhost/project1/reset_password.php?secret='.base64_encode($email).'">Reset Password</a></button></p>
                <br>
                <p>If you did not request a password reset, no further action is required.</p>
            </div>';

        include_once("SMTP/class.phpmailer.php");
        include_once("SMTP/class.smtp.php");

        $mail = new PHPMailer;
        $mail->IsSMTP();
        $mail->SMTPAuth = true;                 
        $mail->SMTPSecure = "tls";      
        $mail->Host = 'smtp.gmail.com';
        $mail->Port = 587; 
        $mail->Username = "u2008031@student.cuet.ac.bd"; // Add your SMTP username here
        $mail->Password = "zlfy llnm ikes pfxj"; // Add your SMTP password here
        $mail->FromName = "UniPulse";
        $mail->AddAddress($email);
        $mail->Subject = "Reset Password";
        $mail->isHTML(true);
        $mail->Body = $message;

        if ($mail->send()) {
            $msg = "We have e-mailed your password reset link!";
        } else {
            $msg = "Failed to send the password reset email.";
        }
    } else {
        $msg = "We can't find a user with that email address.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- <link rel="stylesheet" href="logsig.css"> -->
     <style>
        *{
    padding: 0;
    margin: 0;
    box-sizing: border-box;
    
}
nav {
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    z-index: 1000; /* Ensure navigation bar stays above other content */
    
}

.container{
    /* background-color: rgb(255, 119, 0);   */
    /* background-color: #FBAB7E; */
/* background-image: linear-gradient(62deg, #FBAB7E 0%, #F7CE68 100%); */
background: linear-gradient(360deg, rgb(245, 255, 245) 0%, rgb(173, 252, 163) 100%);
    
    
   
     display: flex;
    background-position: center;
   
    align-items: center;
    justify-content: center;
    width: 100%;
    height: 100vh;
    column-gap: 0px;
    font-family:'Gill Sans', 'Gill Sans MT', Calibri, 'Trebuchet MS', sans-serif;
}

 

.form{
    position: absolute;
    max-width: 450px;
    width: 100%;
    margin: 20px;
    padding-top: 15px;
    background-color: rgb(255, 255, 255);
    border-radius: 8px;  
    box-shadow: 10px 10px 10px rgba(0, 0, 0, 0.2);
    /* border: 1px solid #333; */

  
 }

/* .form.signup{
    opacity: 0;
    pointer-events: none;
}
.forms.Show-Signup .form.signup{
    opacity: 1;
    pointer-events: auto;
} */

.forms.Show-Signup .form.login{
    opacity: 0;
    pointer-events: none;
}

.heading{
    font-size: 28px;
    text-align: center;
    font-weight: 500 ;
    
}

.line{
    background-color: rgb(195, 195, 195);
    margin: 20px;
    height: 1px;
}
.underline{
    background-color: rgb(255, 119, 0);  
    margin: 8px 120px 40px 120px;
    height: 2.5px;
}

.contentl {
    margin: 0 20px;
    margin-bottom: 30px ;
}
.field{
    width: 100%;
    height: 35px;
    position: relative;
    margin: 10px 0 ;
}
.input{
    padding: 0 20px;
}
.field input,
.field button{

    width: 100%;
    height: 100%;
    padding: 0 15px;
    border-radius: 12px;
    font-family:'Gill Sans', 'Gill Sans MT', Calibri, 'Trebuchet MS', sans-serif;
}
.field input{
    outline: none;
    border-style: none none solid none;
    border-radius: 0;
}
.input .hide-show{
    position: absolute;
    top: 50%;
    right: 20px;
    opacity: 0.6;
    cursor: pointer;
}
.field input:focus{
    border-bottom: 2px solid;
}
.field button{
    background-color: #ffa442;
    border: none;
    color: #fff;
    font-size: 18px;
    font-weight: 100;
    cursor: pointer;
}
#btn{
    background-color: #ffa442;
    /* margin-left: 196px; */
    border: none;
    color: black;
    font-size: 18px;
    font-weight: 100;
    cursor: pointer;
    border-radius: 4px;
    padding: 5px;;
}

.forg {
    margin: 10px 0 23px 0;
    text-align: right;
    padding: 0 15px;
    text-decoration: none;
    cursor: pointer;
}
.link a,
.forg a{
    text-decoration: none;
}
.link{
    text-align: center;
    margin: 20px 0;
    cursor: pointer;
}

.thirdLogin{
    /* text-align: center; */
    border: 1px solid grey;
    display: flex;
    align-items: center;
    justify-content: center;
    border-radius: 5px;
    cursor: pointer;
}

.facebook{
    border-style: none;
    background-color: #3b5998;
    color: #fff;
}
.face-icon{
    position: absolute;
    left: 0;
    width: 30px;
    /* height: 30px; */
    font-size: 25px;
    padding-left: 5px;
    /* display: flex; */
    /* align-items: center; */
}
.Logout a{
    background-color: #ffa442; 
    border: transparent;
    color: white;
    font-size: 16px;
    font-weight: 100;
    cursor: pointer;
   text-decoration: none;
    
    

}
.google{
    opacity: 0.7;
}

.space{
    margin: 25px 0 10px 0;
}


     </style>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.2/css/all.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" integrity="sha512-DTOQO9RWCH3ppGqcWaEA1BIZOC6xxalwEsw9c2QQeAIftl+Vegovlnee1c9QX4TctnWMn13TZye+giMm8e2LwA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <title>Forgot Password</title>
    <style>
        .container {
            /* max-width: 600px; */
            background-color: #f9f9f9;
            border: 1px solid #ccc;
            border-radius: 5px;
            padding: 16px;
            margin: 0 auto;
        }
        .error {
            color: red;
            font-weight: 700;
        }
        #email {
            margin-bottom: 10px;
            padding-left:0px;
        }
        .field{
            margin-bottom: 29px;
        }
        .field .btn{
           
           background-color: #ffa442;
           /* margin-left: 196px; */
           border: none;
           color: black;
           font-size: 18px;
           font-weight: 100;
           cursor: pointer;
           border-radius: 4px;
           padding: 5px;
           margin-top:8px;
       }
       .underline {
  background-color: rgb(255, 119, 0);
  margin: 8px 120px 40px 106px;
    
  height: 2.5px;
  width: 200px;
}
    </style>
</head>
<body>
    <?php include "header.php"; ?>
    <section class="container forms">
        <div class="form login">
            <h3 class="heading">Forgot Password</h3>
            <form id="validate_form" method="post" class="contentl">
                <div class="line underline"></div>
                <div class="field input">
                <label for="pwd">Email to receive reset link</label>
                    <input type="text" name="email" id="email" placeholder="Enter your Email" required data-parsley-type="email" data-parsley-trigger="keyup" class="form-control">
                </div>
                <div class="field btn">
                    <input type="submit" id="login" name="pwdrst" value="Send Password Reset Link" class="btn btn-success">
                </div>
                <p class="error"><?php if(!empty($msg)){ echo $msg; } ?></p>
            </form>
        </div>
    </section>
    <script src="./script.js"></script>
    <?php include 'footer.php'; ?>
</body>
</html>

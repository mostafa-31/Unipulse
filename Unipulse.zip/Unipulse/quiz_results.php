<?php
session_start();

// Hardcoded correct answers for simplicity
$correct_answers = [
    "q0" => "F = ma", 
    "q1" => "H2O",
    // Add correct answers for all questions
];

$score = 0;
foreach ($correct_answers as $question => $answer) {
    if ($_POST[$question] === $answer) {
        $score++;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Quiz Results</title>
   <script>
      window.onload = function() {
         alert("Your score: <?php echo $score; ?>/30");
      }
   </script>
</head>
<body>
   <h2>Thank you for completing the quiz!</h2>
</body>
</html>

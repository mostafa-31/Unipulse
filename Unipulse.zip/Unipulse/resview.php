<?php
session_start();
if(!isset($_SESSION['loggedin'])){
  header("location:login.php");
  ob_end_flush();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>University Admission Test Resources</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            /* background-color: #f0f0f0; */
            background: linear-gradient(360deg, rgb(245, 255, 245) 0%, rgb(173, 252, 163) 100%);
        }
        h1 {
            text-align: center;
            margin-bottom: 20px;
            font-family: Cambria, Cochin, Georgia, Times, 'Times New Roman', serif;
            font-size: 2.2rem;
            margin-top: 80px;
        }
        .resvie {
            padding-left: 10em;
            padding-right: 10em;
            /* padding-top: 2em; */
            padding-bottom: 2em;
        }
        .resvie .subject {
            /* background: rgb(173, 252, 163) ; */
            background:  #fff;

            margin-bottom: 1em;
            padding: 1em;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.5);
        }
        .resvie h2 {
            color: #333;
        }
        .resvie h3 {
            color: #333;
            padding-top: 10px;
        }
        .resvie ul {
            list-style-type: none;
            padding: 0;
        }
        .resvie li {
            margin: 0.5em 0;
            margin-bottom: 1.5em;
        }
        
        .resvie .pdf-icon {
            display: flex;
            align-items: center;
            font-family: Arial, sans-serif;
            text-transform: uppercase;
            margin-bottom: 8px;
        }
        .resvie .video-title  {
            font-weight: bold;
            margin-top: 10px;
            color: black;
        }
        .resvie .pdf-icon img {
            width: 40px;
            height: 50px;
            margin-right: 10px;
        }
        .resvie .video-frame {
            width: 25%;
            height: 200px;
            margin-top: 5px;
        }
    </style>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
</head>
<body>
    <?php include 'header.php'; ?>
    <h1>University Admission Test Resources</h1>
    
    <main class="resvie">
        <div class="subject">
            <h2>Physics</h2>
            <?php displayResources('physics'); ?>
        </div>
        <div class="subject">
            <h2>Chemistry</h2>
            <?php displayResources('chemistry'); ?>
        </div>
        <div class="subject">
            <h2>Math</h2>
            <?php displayResources('math'); ?>
        </div>
    </main>
    <?php include 'footer.php'; ?>
</body>
</html>

<?php
function displayResources($subject) {
    $filePath = "./new folder/resources/$subject.json";
    if (!file_exists($filePath)) {
        echo "<p>No resources found for $subject.</p>";
        return;
    }

    $data = file_get_contents($filePath);
    $resources = json_decode($data, true);

    foreach ($resources as $part => $chapters) {
        echo "<h3>Part $part</h3>";
        echo "<ul>";
        foreach ($chapters as $chapter => $resources) {
            echo "<li><strong>Chapter $chapter</strong>";
            foreach ($resources as $resource) {
                echo "<ul>";
                if (isset($resource['pdf'])) {
                    $pdfPath = "./new folder/uploads/{$resource['pdf']}";
                    echo "<!-- Debug: Checking PDF Path - $pdfPath -->"; // Debug information
                    if (file_exists($pdfPath)) {
                        echo "<li class='pdf-icon'><a href='$pdfPath' target='_blank'><img src='./new folder/pdf_icon.png' alt='PDF Icon'></a>{$resource['pdf_title']}</li>";
                    } else {
                        echo "<li class='pdf-icon'><img src='./new folder/pdf_icon.png' alt='PDF Icon'><span>{$resource['pdf_title']} (PDF not found)</span></li>";
                    }
                }
                if (isset($resource['video'])) {
                    $video_url = str_replace("watch?v=", "embed/", $resource['video']);
                    echo "<li class='video-title'><a href='{$resource['video']}' target='_blank'></a>{$resource['video_title']}</li>";
                    echo "<li><iframe class='video-frame' src='$video_url' frameborder='0' allowfullscreen></iframe></li>";
                }
                echo "</ul>";
            }
            echo "</li>";
        }
        echo "</ul>";
    }
}
?>

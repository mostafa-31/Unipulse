<!DOCTYPE html>
<html>
<head>
<title>Background Image Animation</title>
<link rel="stylesheet"  href="styl.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.2/css/all.min.css"/>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" integrity="sha512-DTOQO9RWCH3ppGqcWaEA1BIZOC6xxalwEsw9c2QQeAIftl+Vegovlnee1c9QX4TctnWMn13TZye+giMm8e2LwA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
<style type="text/css">
    body {
        margin: 0;
        /* overflow: hidden; */
    }
    .bgImage {
        position: relative;
        width: 100%;
        height: 100vh;
    }
    .bgImage img {
        position: absolute;
        width: 100%;
        height: 100%;
        object-fit: cover;
        opacity: 0;
        animation: bgChange 20s linear infinite;
    }
    .bgImage img:nth-child(1) { animation-delay: 0s; }
    .bgImage img:nth-child(2) { animation-delay: 5s; }
    .bgImage img:nth-child(3) { animation-delay: 10s; }
    .bgImage img:nth-child(4) { animation-delay: 15s; }

    @keyframes bgChange {
        0%, 20%, 100% { opacity: 1; }
        25%, 95% { opacity: 0; }
    }

    .overlay {
        position: absolute;
        width: 100%;
        height: 100%;
        top: 0;
        left: 0;
        background-color: rgba(0, 0, 0, 0.8); /* Darker overlay */
    }

    .content {
        position: relative;
        width: 100%;
        height: 100%;
        color: white;
        display: flex;
        justify-content: center;
        align-items: center;
        flex-direction: column;
        z-index: 2;
    }
    /* nav */
    .navbar {
        position: absolute; /* or fixed, depending on your layout needs */
        width: 100%;
        top: 0;
        left: 0;
        z-index: 9999; /* A high value to ensure it stays on top */
    }
    
    .content h1 {
        font-size: 60px;
        margin-bottom: 0px;
        padding-bottom: 10px;
    }
    .content h1 span {
        color: #00bf13;
    }
    .content p {
        font-size: 18px;
        width: 60%;
        padding-bottom: 10px;
        text-align: center;
    }
    .content button {
        color: white;
        border: none;
        outline: none;
        font-size: 18px;
        /* background-color: #00bf13; */
        background:transparent;
        padding: 14px 22px;
        text-transform: uppercase;
        border-radius: 25px;
        transition: .5s;
        cursor: pointer;
        border: 2px solid #00bf13;

    }
    .content button:hover {
       color: #008c0e;
    }
    #feature{
    padding: 5vw 8vw 0 8vw;
    text-align: center;
    color: rgb(44, 44, 80);
}
#feature h1{
    font-family: Cambria, Cochin, Georgia, Times, 'Times New Roman', serif;
    font-size: 3rem;
    color: rgb(44, 44, 80);
}
    .age {
    border-radius: 10px;
    display:grid;
    grid-template-columns: repeat(auto-fit,minmax(300px,auto));
    grid-gap:20px;
    justify-content: center;
    margin-top:20px;
}
 .age .card  {
    margin-top: 60px;
 height:100px;
 width:250px;
 padding:10px;
 font-family: 'Lucida Sans', 'Lucida Sans Regular', 'Lucida Grande', 'Lucida Sans Unicode', Geneva, Verdana, sans-serif;
 color: rgb(44, 44, 80);
text-align: center;
border: 1px solid #dfdcdc;
/* border:  2px solid #00bf13; */
box-shadow: 7px 7px 5px #dfdcdc;
 }
.age .card a {
    color: rgb(44, 44, 80);
    text-decoration:none;
   
}

.age .card a:hover {
    color: rgb(70, 70, 80);
    text-decoration:none;
    color: darkorange;
}
.age .card a i {
 font-size:2.5rem;
}
 .age .card:hover{
    cursor: pointer;
    box-shadow:5px 5px 10px #dfdcdc;
    /* color: darkorange; */
    transition-duration: .4s;
    transform: scale(1.2);
}
</style>
</head>
<body>
    <!-- nav -->
     <header class="navbar">
<?php include 'header.php';?>
</header>
<!-- nav end -->
    <section>
<div class="bgImage">
    <img src="images/cuet.jpg" alt="Image 1">
    <img src="images/buet.jpg" alt="Image 2">
    <img src="images/du.jpg" alt="Image 3">
    <img src="images/ru.jpg" alt="Image 4">
    <div class="overlay"></div>
    <div  class="greet">
            <h1>WELCOME <?php echo $_SESSION['username'] ?></h1>
        </div>
        
    <div class="content">
        <h1>Seize the opportunity presented by  <span>UniPlse</span></h1>
        <p>Our motive is to keep you updated providing detail informations about undedergraduation , postgraduation  and Higher studies in reputed universities.</p>
        <button>Explore Now</button>
    </div>
</div>
</section>
<section id="feature">
<h1>Awsome feature</h1>
<p>Find which is best for you</p>
<div class="age">
        <div class="card">
         
          <!-- <h3>Admission test Merit Scholarship</h3> -->
          <a href="scholarship.php">
                <i class="fas fa-graduation-cap"></i>
                <h3>Scholarship Facility</h3> </a>
                <p>Know details about Scholarship</p>
        </div>
        
        <div class="card">
          
        
               <a href="Funi.html"> <i class="fa-solid fa-building-columns"></i>
               <h3>Admission resources</h3>
            </a>
                <p>Preapre yourself ror the war </p>
            
        </div>
        </div>
</section>
</section>
    <!-- QnA  -->
     <section class="qna" style="padding-left: 58px;">
     <?php include 'QnA\qna.php';?>
     </section>
    <!-- footer  -->
    <?php include 'footer.php';?>
</body>
</html>
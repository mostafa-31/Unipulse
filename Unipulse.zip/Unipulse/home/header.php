
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="styl.css" >
</head>
<body>

<nav style="top: 0px">
        <img src="images/logon.png" alt="logo photo">
        <div class="navigation">
            <ul>
                <!-- <li class="sr">
                    <input type="text" id="text" placeholder=search> </li>
                <li class="icon"><a href="#"><i class="fas fa-search"></i></a> -->
            </li>
                <li><a href="unipulse.php">Home</a></li>
                <li><a href="about us.php">About Us</a></li>
                <li><a href="Contuct us.php">contuct us</a></li>
                <li><a href="uni2.php">University</a></li>
             
                <?php
			if(isset($_SESSION['loggedin']) && $_SESSION['loggedin'] === true) {
				echo '<li><a href="logout.php">logout</a></li>';
			} else {
				echo '<li><a href="login.php">Login</a></li>';
			}
			?>
               
            </ul>
        </div>
    </nav>
</body>
</html>
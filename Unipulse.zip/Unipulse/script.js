// script.js
document.addEventListener('DOMContentLoaded', () => {
    const passwordInput = document.getElementById('pass');
    
    const hideShowIcon = document.querySelector('.hide-show');

    hideShowIcon.addEventListener('click', () => {
        if (passwordInput.type === 'password') {
            passwordInput.type = 'text';
            hideShowIcon.classList.remove('bx-hide');
            hideShowIcon.classList.add('bx-show');
        } else {
            passwordInput.type = 'password';
            hideShowIcon.classList.remove('bx-show');
            hideShowIcon.classList.add('bx-hide');
        }
    });
});

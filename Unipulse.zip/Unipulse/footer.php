<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Footer</title>
     <!-- <link rel="stylesheet" href="style.css" > -->
      <style>
        footer{
    display: flex;
    flex-wrap: wrap;
    margin-top: auto;
    background-color: #2d2e33;
    padding: 60px 10%;
    padding-top: 50px;
    color: #fff;
    font-family: Arial, sans-serif;
    margin-left: -8px;
    margin-right:-8px;
}

ul{
    list-style: none;
}

.footer-col{
    width: 25%;
    
}
footer img {
    height: 140px;
    
    cursor: pointer;

    
}

.footer-col h4{
    position: relative;
    margin-bottom: 30px;
    font-weight: 400;
    font-size: 22px;
    color: #f1bc0d;
    text-transform: capitalize;
    margin-right: 0px;
  
}

/* .footer-col h4::before{
    content: '';
    position: absolute;
    left: 0;
    bottom: -6px;
    background-color: #27c0ac;
    height: 2px;
    width: 40px;
} */
.footer-col p{
    margin-top: -45px;margin-bottom: 8px;
    padding-right: 76px;
}
.cop{
    margin-top: -162px;margin-left: 959px;margin-right: 45px;
    padding-left: 41px;
}
.copyright{
    margin-left: 33.2px;
}
.footer-col ul li:not(:last-child){
    margin-bottom: 8px;
}
.footer-col ul{
    padding-left: 0px;
}
.footer-col ul li a{
    display: block;
    font-size: 19px;
    text-transform: capitalize;
    color: #bdb6b6;
    text-decoration: none;
    transition: 0.4s;
}

.footer-col ul li a:hover{
    color: white;
    padding-left: 2px;
}

.footer-col .links a{
    display: inline-block;
    height: 44px;
    width: 44px;
    color: white;
    background-color: rgba(40, 130, 214, 0.8);
    margin: 0 8px 8px 0;
    text-align: center;
    line-height: 44px;
    border-radius: 50%;
    transition: 0.4s;
}

.footer-col .links a:hover{
    color: #4d4f55;
    background-color: white;
}
footer .p{
    margin-bottom: 8px;margin-top: 237px;align-items: center;margin-left: -470px;
}

@media(max-width: 740px){
    .footer-col{
        width: 50%;
        margin-bottom: 30px;
        text-align: center;
    }

    .footer-col h4::before{
        all: unset;
    }
}

@media(max-width: 555px){
    .footer-col{
        width: 100%;
    }
}

      </style>
</head>
<body>
<footer>
        <div class="footer-col">
            
        <img src="./images/logon3.png " alt="logo photo" style="margin-top: -41px;margin-left: -18px;">
            <p> Stay with us to grab the opertunity to study at your dream University</p>
        </div>
        <div class="footer-col">
            <h4>Address</h4>
            <ul>
                <li>Raozan, Chottogram</li>
                <li>Bangladesh</li>
                <li>shiahidmostafa@gmail.com</li>
                <li>Contact No:01750465092</li>
                
            </ul>
        </div>
       
        <div class="footer-col">
            <h4>follow us</h4>
            <div class="links">
                <a href="#"><i class="fab fa-linkedin-in"></i></a>
                <a href="#"><i class="fab fa-facebook-f"></i></a>
                <a href="#"><i class="fab fa-twitter"></i></a>
                <a href="#"><i class="fab fa-instagram"></i></a>
            </div>
        </div> 
        <hr class="copyright">
        <div class="cop">
<p>Unipuls &copy; All right reserved </p> <p> Author S M UTSHAB</p> <p>ID : 2008031 </p> </div>
    </footer>
</body>
</html>
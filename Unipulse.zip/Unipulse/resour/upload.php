<?php
include 'db.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $subject = $_POST['subject'];
    $part = $_POST['part'];
    $chapter = $_POST['chapter'];
    $title = $_POST['title'];

    if (isset($_FILES['pdf'])) {
        $file_name = $_FILES['pdf']['name'];
        $file_tmp = $_FILES['pdf']['tmp_name'];
        $file_path = "uploads/" . $file_name;
        move_uploaded_file($file_tmp, $file_path);

        $sql = "INSERT INTO resources (subject, part, chapter, title, file_path) VALUES ('$subject', '$part', '$chapter', '$title', '$file_path')";
    } elseif (isset($_POST['video_link'])) {
        $video_link = $_POST['video_link'];

        $sql = "INSERT INTO videos (subject, part, chapter, title, video_link) VALUES ('$subject', '$part', '$chapter', '$title', '$video_link')";
    }

    if ($conn->query($sql) === TRUE) {
        echo "Record added successfully";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html>
<head>
    <title>University Admission Test Resources</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 20px;
            background-color: #f4f4f4;
        }

        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
            background: #fff;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        h1 {
            text-align: center;
            color: #333;
        }

        .subject-section, .part-section, .chapter-section {
            margin-bottom: 20px;
        }

        h2, h3, h4 {
            color: #555;
        }

        .pdf-section, .video-section {
            display: flex;
            flex-wrap: wrap;
            gap: 10px;
        }

        .pdf-item, .video-item {
            flex: 1 1 calc(33.333% - 20px);
            box-shadow: 0 0 5px rgba(0, 0, 0, 0.1);
            padding: 10px;
            background: #fff;
            border-radius: 5px;
        }

        .pdf-item {
            text-align: center;
        }

        .pdf-icon {
            width: 50px;
            height: auto;
            margin-bottom: 10px;
        }

        a {
            color: #0066cc;
            text-decoration: none;
        }

        a:hover {
            text-decoration: underline;
        }

        .video-item iframe {
            width: 100%;
            height: 250px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>University Admission Test Resources</h1>

        <?php
        include 'db.php';

        $subjects = ['Physics', 'Chemistry', 'Math'];

        foreach ($subjects as $subject) {
            echo "<div class='subject-section'><h2>$subject</h2>";
            for ($part = 1; $part <= 2; $part++) {
                echo "<div class='part-section'><h3>Part $part</h3>";
                for ($chapter = 1; $chapter <= 10; $chapter++) {
                    echo "<div class='chapter-section'><h4>Chapter $chapter</h4>";
                    
                    $sql = "SELECT * FROM resources WHERE subject='$subject' AND part='$part' AND chapter='$chapter'";
                    $result = $conn->query($sql);
                    if ($result->num_rows > 0) {
                        echo "<div class='pdf-section'>";
                        while($row = $result->fetch_assoc()) {
                            echo "<div class='pdf-item'>
                                    <img src='pdf-icon.png' alt='PDF Icon' class='pdf-icon'>
                                    <a href='" . $row['file_path'] . "'>" . $row['title'] . "</a>
                                  </div>";
                        }
                        echo "</div>";
                    }

                    $sql = "SELECT * FROM videos WHERE subject='$subject' AND part='$part' AND chapter='$chapter'";
                    $result = $conn->query($sql);
                    if ($result->num_rows > 0) {
                        echo "<div class='video-section'>";
                        while($row = $result->fetch_assoc()) {
                            $embedLink = getEmbedLink($row['video_link']);
                            echo "<div class='video-item'>
                                    <h5>" . $row['title'] . "</h5>
                                    <iframe width='560' height='315' src='$embedLink' frameborder='0' allow='accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture' allowfullscreen></iframe>
                                  </div>";
                        }
                        echo "</div>";
                    }

                    echo "</div>";
                }
                echo "</div>";
            }
            echo "</div>";
        }

        $conn->close();

        function getEmbedLink($url) {
            if (strpos($url, 'youtube.com') !== false || strpos($url, 'youtu.be') !== false) {
                preg_match("/(youtube\.com\/watch\?v=|youtu\.be\/)([^&]+)/", $url, $matches);
                return "https://www.youtube.com/embed/" . $matches[2];
            } elseif (strpos($url, 'vimeo.com') !== false) {
                preg_match("/vimeo\.com\/(\d+)/", $url, $matches);
                return "https://player.vimeo.com/video/" . $matches[1];
            } else {
                return $url; // Default to the original URL if not YouTube or Vimeo
            }
        }
        ?>
    </div>
</body>
</html>

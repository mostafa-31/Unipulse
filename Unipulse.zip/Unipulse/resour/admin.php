<!DOCTYPE html>
<html>
<head>
    <title>Admin Upload</title>
    <link rel="stylesheet" type="text/css" href="styles.css">
</head>
<body>
    <h1>Upload Resources</h1>
    <form action="upload.php" method="post" enctype="multipart/form-data">
        <label>Subject:</label>
        <select name="subject">
            <option value="Physics">Physics</option>
            <option value="Chemistry">Chemistry</option>
            <option value="Math">Math</option>
        </select><br><br>

        <label>Part:</label>
        <select name="part">
            <option value="1">Part 1</option>
            <option value="2">Part 2</option>
        </select><br><br>

        <label>Chapter:</label>
        <select name="chapter">
            <?php for ($i = 1; $i <= 10; $i++) echo "<option value='$i'>Chapter $i</option>"; ?>
        </select><br><br>

        <label>Title:</label>
        <input type="text" name="title" required><br><br>

        <label>Upload PDF:</label>
        <input type="file" name="pdf"><br><br>

        <label>Or Video Link:</label>
        <input type="text" name="video_link"><br><br>

        <input type="submit" value="Upload">
    </form>
</body>
</html>

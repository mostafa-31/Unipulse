<?php
session_start();
if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    header("location: index.php");
    exit;
}
include('new folder/dbn.php');

// Fetch the notices
$sql = "SELECT title, pdf_file, notice_date FROM notices ORDER BY notice_date DESC LIMIT 10"; // Adjust the LIMIT as needed
$result = $conn->query($sql);
$notices = [];
if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $notices[] = $row;
    }
}
?>

<!DOCTYPE html>
<html>
<head>
<title>Home</title>
<!-- favicon -->
<link rel="icon" type="image/x-icon" href="images/logon3.png">
<!-- <link rel="stylesheet" href="style.css"> -->
<link rel="stylesheet" href="QnA/stylr.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.2/css/all.min.css"/>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" integrity="sha512-DTOQO9RWCH3ppGqcWaEA1BIZOC6xxalwEsw9c2QQeAIftl+Vegovlnee1c9QX4TctnWMn13TZye+giMm8e2LwA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
<link href="https://fonts.googleapis.com/css2?family=Roboto:wght@700&display=swap" rel="stylesheet">
<style>
      @import url('https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@300..700&display=swap');
      @import url('https://fonts.googleapis.com/css2?family=Comfortaa:wght@300..700&family=Space+Grotesk:wght@300..700&display=swap');
      @import url('https://fonts.googleapis.com/css2?family=Comfortaa:wght@300..700&family=Itim&family=Space+Grotesk:wght@300..700&family=Zeyada&display=swap');
      @import url('https://fonts.googleapis.com/css2?family=Stylish&display=swap');
    *{
    margin: 0;
    padding: 0;
}
html{
    scroll-behavior: smooth;
   }
   


/* #explain{
    box-shadow: 5cap;
} */
body {
    margin: 0;
    /* overflow: hidden; */
    background-color: antiquewhite;
}

.background-container {
    position: relative;
    width: 101%;
    height: 100vh;
}

.background-image {
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    object-fit: cover;
    opacity: 0;
    transition: opacity 2s ease-in-out;
}

.background-image.active {
    opacity: 1;
}
/* .bgImage {
    position: relative;
    width: 100%;
    height: 100vh;
    
}
.bgImage img {
    position: absolute;
    width: 100%;
    height: 100%;
    object-fit: cover;
    opacity: 0;
    animation: bgChange 20s linear infinite;
    
}
.bgImage img:nth-child(1) { animation-delay: 0s; }
.bgImage img:nth-child(2) { animation-delay: 5s; }
.bgImage img:nth-child(3) { animation-delay: 10s; }
.bgImage img:nth-child(4) { animation-delay: 15s; }

@keyframes bgChange {
    0%, 20%, 100% { opacity: 1; }
    25%, 95% { opacity: 0; }
} */



/* .bgImage img {
    position: absolute;
    width: 100%;
    height: 100%;
    object-fit: cover;
    opacity: 0;
    animation: bgChange 20s linear infinite;
    animation-fill-mode: both; 
    animation-timing-function: ease-in-out; 
} */



.overlay {
    position: absolute;
    width: 100%;
    height: 100%;
    top: 0;
    left: 0;
    background-color: rgba(0, 0, 0, 0.8); /* Darker overlay */
}

.content {
    position: relative;
    width: 100%;
    height: 100%;
    color: white;
    display: flex;
    justify-content: center;
    align-items: center;
    flex-direction: column;
    z-index: 2;
    
}
.content .greet{
    color: #fff;
    font-size: 92px;
    text-transform: uppercase;

    font-family: "Zeyada", cursive;
    font-weight: 800;
    background: linear-gradient(to right,#f7f9fa 10%, #07f012 50%, #57d75b 60%);
    background-size: auto auto;
    background-clip: border-box;
    background-size: 200% auto;
    color: #fff;
    background-clip: text;
    /* text-fill-color: transparent; */
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    animation: textclip 1.5s linear infinite;
    display: inline-block;
}
@keyframes textclip {
	to {
		background-position: 200% center;
	}
} 

.content h1 {
    font-size: 60px;
    margin-bottom: 0px;
    padding-bottom: 10px;
    color: white;
    font-family: "Space Grotesk", sans-serif;
}


.content h1 span {
    color: #00bf13;
}
.content p {
    font-size: 18px;
    width: 60%;
    padding-bottom: 10px;
    text-align: center;
    font-family: "Comfortaa", sans-serif;
}
.content button {
    font-family: "Comfortaa", sans-serif;
    color: white;
    border: none;
    outline: none;
    font-size: 18px;

    background:transparent;
    margin-top:35px;
    padding: 14px 22px;
    text-transform: uppercase;
    border-radius: 25px;
    transition: .5s;
    cursor: pointer;
    border: 2px solid #00bf13;
    font-weight: 1000;

}
.content button:hover {
   color: #008c0e;
   background-color:white;
} 


@media (max-width: 1230px) {
    .se{
        font-family: "Space Grotesk", sans-serif;
        margin-left:90px;
    }
    .greet{
        margin-left:90px;
        margin-top:20px;
    }
}
/* nav */
.navbar {
    position: absolute; /* or fixed, depending on your layout needs */
    width: 100%;
    top: 0;
    left: 0;
    z-index: 9999; /* A high value to ensure it stays on top */
}
 @import url(https://fonts.googleapis.com/css?family=Righteous);
 #feature{
padding: 5vw 8vw 0 8vw;
text-align: center;
color: #333;
margin-bottom:50px;
}
#feature h1{
font-family: Cambria, Cochin, Georgia, Times, 'Times New Roman', serif;
font-size: 3rem;
color: #333;
}
.age {
border-radius: 10px;
display:grid;
grid-template-columns: repeat(auto-fit,minmax(300px,auto));
grid-gap:20px;
justify-content: center;
margin-top:20px;

}
.age .carda  {
margin-top: 60px;
height:250px;
width:250px;
padding:10px;
font-family: 'Lucida Sans', 'Lucida Sans Regular', 'Lucida Grande', 'Lucida Sans Unicode', Geneva, Verdana, sans-serif;
color: rgb(44, 44, 80);
text-align: center;
border: 1px solid #ccc;
/* border:  2px solid #00bf13; */
box-shadow: 6px 6px 10px rgba(0, 0, 0, 0.2);
background: linear-gradient(145deg, #ffffff, #f0f0f0); /* Subtle gradient */

  transition: transform 0.3s ease, box-shadow 0.3s ease; /* Smooth transition for hover effect */

}
.age .carda a {
color: rgb(44, 44, 80);
text-decoration:none;

}

.age .carda a:hover {
/* color: rgb(70, 70, 80); */

text-decoration:none;
color: darkorange;
}
.age .carda a img {
    width: 172px;
  height: 172px;
  
}
.age .carda:hover{
cursor: pointer;
/* box-shadow:5px 5px 10px #dfdcdc;

transition-duration: .4s;*/
 transform: scale(1.1);  
/* transform: translateY(-10px) ;  */
  box-shadow: 10px 10px 20px rgba(0, 0, 0, 0.2); 
  
              /* -10px -10px 20px rgba(255, 255, 255, 0.7) */
}

    .age .carda a img {
    width: 172px;
  height: 172px;
}
/* QnA Section Styles */
#qna {
    background: #f9f9f9;
    padding: 50px 20px;
    border-radius: 10px;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    max-width: 800px;
    margin-left: 30px;
    background-color: antiquewhite;
}

#qna h1 {
    text-align: left;
    font-size: 2.5em;
    color: #333;
    margin-bottom: 30px;
    text-transform: uppercase;
    letter-spacing: 1.5px;
}

#qna-form {
    display: flex;
    flex-direction: column;
    margin-bottom: 30px;
}

#qna-form textarea {
    resize: none;
    height: 100px;
    padding: 15px;
    border: 1px solid #333;
    border-radius: 8px;
    font-size: 1em;
    margin-bottom: 15px;
    box-shadow: inset 0 2px 4px rgba(0, 0, 0, 0.1);
    transition: border-color 0.3s;
    background-color: white;
}

#qna-form textarea:focus {
    border-color: #007bff;
}

#qna-form button {
    align-self: flex-end;
    background-color: #007bff;
    color: #fff;
    border: none;
    padding: 10px 20px;
    border-radius: 8px;
    cursor: pointer;
    font-size: 1em;
    margin-right: 367px;
    transition: background-color 0.3s;
}

#qna-form button:hover {
    background-color: #0056b3;
}

#questions {
    margin-top: 30px;
}

.question {
    background: #fff;
    border: 1px solid grey;
    border-radius: 10px;
    padding: 20px;
    margin-bottom: 20px;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.05);
}
.icon img {
    width: 30px;
    height: 30px;
    margin-right: 1px;
    
}
.question p {
    margin: 0 0 10px;
    font-size: 1.1em;
    color: #333;
}

.question p strong {
    color: blue;
    font-style: italic;
}

.question p small {
    display: block;
    font-size: 1em;
    color: #456;
    margin-top: 5px;
}
.scrolling-container {
    width: 700px;
  margin: 40px;
  text-align: left;
            align-items: left;
            background-color: antiquewhite;
        }

        .scrolling-box {
            width: 100%;
            height: 200px;
            overflow: hidden;
            background: #f8f9fa;
            border: 2px solid #ccc;
            border-radius: 10px;
            position: relative;
            padding: 10px;
        }
        .title-container {
            display: flex;
            align-items: center;
            justify-content: left;
            gap: 10px;
        }

        .title-container img {
            width: 40px;
            height: 40px;
            filter: drop-shadow(3px 3px 3px rgba(0, 0, 0, 0.8));
        }

        .title-container h1 {
            padding-top: 13px;
            padding-bottom: 13px;
            margin: 0;
        }
        .scrolling-box .notice-container {
            display: block;
            /* position: absolute; */
            animation: scrollUp 6s linear infinite;
            /* align-items: left; */
            text-align: left;
            padding-left: 20px;
        }

        .scrolling-box a {
            display: block;
            margin-bottom: 10px;
            color: #007bff;
            text-decoration: none;
            font-size: 1.1em;
        }

        .scrolling-box a:hover {
            text-decoration: underline;
        }

        .scrolling-box .date {
            color: #555;
            margin-left: 10px;
            font-size: 0.9em;
            font-style: italic;
        }
        @keyframes scrollUp {
            0% { transform: translateY(100%); }
            100% { transform: translateY(-100%); }
        }
        .title-container-ask {
            display: flex;
            align-items: center;
            justify-content: left;
            gap: 10px;
        }

        .title-container-ask img {
            width: 80px;
            height: 80px;
           
                margin-top: -50px;
        }
        .title-container-ask h1 {
            padding-top: 13px;
            padding-bottom: 13px;
            margin: 0;
        }
        .hidden-question {
    display: none;
}

#toggle-btn {
    align-self: flex-end;
    background-color: #007bff;
    color: #fff;
    border: none;
    padding: 10px 20px;
    border-radius: 8px;
    cursor: pointer;
    font-size: 1em;
    margin-right: 367px;
    transition: background-color 0.3s;
}

#toggle-btn:hover {
    background-color: #0056b3;
}

     /* Style for the sticky ad on the right side */
     /* #sticky-ad {
            position: sticky;
            top: 100px;
            right: 0;
            width: 250px; 
            background-color: #f9ed69;
            padding: 15px;
            text-align: center;
            box-shadow: 0px 2px 10px rgba(0, 0, 0, 0.3);
            z-index: 1000;
            border-radius: 10px;
            margin-left: 1200px;
        } */

        /* Close button style */
        /* .close-btn {
            position: absolute;
            top: 10px;
            right: 15px;
            background-color: #ff4d4d;
            color: white;
            border: none;
            border-radius: 50%;
            padding: 5px 10px;
            cursor: pointer;
            font-size: 16px;
        } */

        /* Style for the image with drop shadow */
        /* #sticky-ad img {
            width: 200px;
            border-radius: 5px;
            filter: drop-shadow(3px 3px 3px rgba(0, 0, 0, 0.8));
        } */

        /* Style for the title above the image */
      

        /* Anchor (link) style */
        
</style>
<link rel="stylesheet"
          href="https://fonts.googleapis.com/css?family=Playwrite Cuba">
    
</head>
<body>
    <!-- nav -->
    <header class="navbar">
        <?php include 'header.php'; ?>
    </header>
    <!-- nav end -->
    <section>
        <!-- <div class="bgImage"> -->
        <div class="background-container">
        <img src="images/cuet.jpg" alt="Image 1" class="background-image active">
        <img src="images/buet.jpg" alt="Image 2" class="background-image">
        <img src="images/du.jpg" alt="Image 3" class="background-image">
        <img src="images/ru.jpg" alt="Image 4" class="background-image">
            <div class="overlay"></div>
            <div class="content">
                <div class="greet">
                    <h1 style=" font-family: 'Stylish', serif;
  font-weight: 800;"data-shadow='WELCOME'>WELCOME <?php echo htmlspecialchars($_SESSION['username']); ?></h1>
                </div>
                <div class="se">
                    <h1>Seize the opportunity presented by <span >UniPulse</span></h1>
                    <!-- style=" background-color:#ffff;
                    border-radius:5px;
                    padding-left: 8px;
  padding-right: 8px;" -->
                </div>
                <p>Our motive is to keep you updated by providing detailed information about undergraduate, postgraduate, and higher studies in reputed universities.</p>
                <a href="aboutindex.php"><button>Explore More</button></a>
            </div>
        </div>
    </section>
    <section id="feature">
        <h1>Signature Offering</h1>
        <p>Find what is best for you</p>
        <div class="age">
            <div class="carda">
                <a href="scholarship.php">
                    <img style=" width: 172px;
  height: 172px;" src="./images/donation.gif" alt="">
                    <h3>Scholarship Facility</h3>
                </a>
                <p>Unlock Your Potential with a Scholarship.</p>
            </div>
            <div class="carda">
                <a href="std_abroad.php">
                    <img style=" width: 172px;
  height: 172px;   filter: drop-shadow(3px 3px 3px rgba(0, 0, 0, 0.8));" src="./images/abroad_std.png" alt="">
                    <h3>Study Abroad</h3>
                </a>
                <p>Travel Far, Learn Deep.</p>
            </div>
            <div class="carda">
                <a href="resview.php">
                    <img style=" width: 172px;
  height: 172px;" src="./images/education.gif" alt="">
                    <h3>Admission Resources</h3>
                </a>
                <p>Prepare Yourself for the Journey.</p>
            </div>
            <!-- <div class="carda">
                <a href="snake.php">
                    <img style=" width: 267px;
  height: 172px;   filter: drop-shadow(3px 3px 3px rgba(0, 0, 0, 0.8));" src="./images/snak.png" alt="">
                    <h3>Snake Game</h3>
                </a>
                <p>Master the Maze, Feed the Snake!.</p>
            </div> -->
            <div class="carda">
                <a href="uni2.php">
                    <img  src="./images/campus.gif" alt="">
                    <h3>University</h3>
                </a>
                <p>Know Details About Your Future University</p>
            </div>
        </div>
    </section>
     <!-- Sticky ad -->
     

    
        <!-- scrolling Notice-->
    <div class="scrolling-container">
       
        <div class="title-container" >
           
            <h1 style="padding-top: 13px;padding-bottom: 13px;">Notices</h1>
            <img src="./images/notification.png" alt="Notices Icon">
        </div>
        <div class="scrolling-box" onmouseover="pauseScroll()" onmouseout="resumeScroll()">
            <div class="notice-container">
                <?php foreach ($notices as $notice): ?>
                    <a href="new folder/uploads/<?php echo $notice['pdf_file']; ?>" target="_blank">
                        <span><?php echo $notice['title']; ?></span>
                        <span class="date"><?php echo date('d M Y', strtotime($notice['notice_date'])); ?></span>
                    </a>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
    <!-- end scrolling Notice-->
    <script>
        function pauseScroll() {
            document.querySelector('.notice-container').style.animationPlayState = 'paused';
        }

        function resumeScroll() {
            document.querySelector('.notice-container').style.animationPlayState = 'running';
        }
    </script>

   <!-- QnA Section -->
<section id="qna">
<div class="title-container-ask">
           
           <h1 style="padding-top: 13px;padding-bottom: 13px;">Ask a Question</h1>
           <img src="./images/brainstorming.gif" alt="Notices Icon" style="  filter: drop-shadow(3px 3px 3px rgba(0, 0, 0, 0.8));">
       </div>
    <!-- <h1>Ask a Question</h1> -->
<form id="qna-form" method="POST" action="submit_question.php" onsubmit="return showPopup();">
    <textarea name="question" placeholder="Type your question here..." required></textarea>
    <button type="submit">Ask</button>
</form>

<div id="questions">
    <?php
    require 'configq.php'; // Your database configuration
    $result = $conn->query("SELECT * FROM questions ORDER BY created_at DESC");
    $count = 0;
    while ($row = $result->fetch_assoc()) {
        $count++;
        $hidden_class = $count > 3 ? 'hidden-question' : '';
        echo '<div class="question ' . $hidden_class . '">';
        echo '<p><small><strong>' . htmlspecialchars($row['username']) . '</strong> on ' . date('F j, Y, g:i a', strtotime($row['created_at'])) . '</small></p>';
        echo '<p><span class="icon"><img src="QnA/icons/question.png" alt="Q" ></span> ' . htmlspecialchars($row['question']) . '</p>';
        echo '<p><span class="icon"><img src="QnA/icons/answer.png" alt="A" ></span> ';
        if ($row['answer']) {
            echo htmlspecialchars($row['answer']);
        } else {
            echo '<i style="color:#555;">Not answered yet</i>';
        }
        echo '</p>';
        echo '</div>';
    }
    ?>
</div>
<button id="toggle-btn" onclick="toggleQuestions()">See More</button>


    <script>
        function toggleQuestions() {
    var hiddenQuestions = document.querySelectorAll('.hidden-question');
    var toggleBtn = document.getElementById('toggle-btn');
    
    if (toggleBtn.innerHTML === "See More") {
        hiddenQuestions.forEach(function(question) {
            question.style.display = 'block';
        });
        toggleBtn.innerHTML = "See Less";
    } else {
        hiddenQuestions.forEach(function(question) {
            question.style.display = 'none';
        });
        toggleBtn.innerHTML = "See More";
    }
}


    </script>
</section>

<!-- Success Popup -->
<div id="success-popup" style="display:none;">
    <p>Question submitted successfully!</p>
</div>

<script>
function showPopup() {
    document.getElementById('success-popup').style.display = 'block';
    setTimeout(function() {
        document.getElementById('success-popup').style.display = 'none';
    }, 3000); // Hide after 3 seconds
    return true; // Allow form submission to proceed
}
</script>

  
    <!-- footer -->
    <?php include 'footer.php'; ?>
    <script>
          const images = document.querySelectorAll('.background-image');
let currentImageIndex = 0;

function changeBackground() {
    images[currentImageIndex].classList.remove('active');
    currentImageIndex = (currentImageIndex + 1) % images.length;
    images[currentImageIndex].classList.add('active');
}

setInterval(changeBackground, 5000); // Change every 5 seconds
        document.getElementById('qna-form').addEventListener('submit', function(event) {
            <?php if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true): ?>
            event.preventDefault();
            alert('You must be logged in to ask a question.');
            window.location.href = 'login.php';
            <?php endif; ?>
        });
    </script>
</body>
</html>

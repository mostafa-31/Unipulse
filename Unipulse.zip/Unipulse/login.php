<?php
session_start();
if (isset($_SESSION['username'])) {
    header("Location: welcome.php");
}



$login = false;
include('connection.php');
if (isset($_POST['submit'])) {
    $username = $_POST['user'];
    $password = $_POST['pass'];
    $sql = "SELECT * FROM signup WHERE username = '$username' OR email = '$username'";  
    $result = mysqli_query($conn, $sql);  
    $row = mysqli_fetch_array($result, MYSQLI_ASSOC);  
    $count = mysqli_num_rows($result);  
    
    if ($row && password_verify($password, $row["password"])) {  
        $login = true;
        session_start();
        $_SESSION['username'] = $row['username'];
        $_SESSION['loggedin'] = true;
       header("Location: unipulse.php");
    } else {  
        echo '<script>
                  alert("Login failed. Invalid username or password!!");
                  window.location.href = "login.php";
              </script>';
    }     
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <!-- <link rel="stylesheet" href="logsig.css"> -->
     <style>
        *{
    padding: 0;
    margin: 0;
    box-sizing: border-box;
    
}
nav {
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    z-index: 1000; /* Ensure navigation bar stays above other content */
    
}

.container{
    /* background-color: rgb(255, 119, 0);   */
    /* background-color: #FBAB7E; */
/* background-image: linear-gradient(62deg, #FBAB7E 0%, #F7CE68 100%); */
background: linear-gradient(360deg, rgb(245, 255, 245) 0%, rgb(173, 252, 163) 100%);
    
    
   
     display: flex;
    background-position: center;
   
    align-items: center;
    justify-content: center;
    width: 100%;
    height: 100vh;
    column-gap: 0px;
    font-family:'Gill Sans', 'Gill Sans MT', Calibri, 'Trebuchet MS', sans-serif;
}

 

.form{
    position: absolute;
    max-width: 450px;
    width: 100%;
    margin: 20px;
    padding-top: 15px;
    background-color: rgb(255, 255, 255);
    border-radius: 8px;  
    box-shadow: 10px 10px 10px rgba(0, 0, 0, 0.2);
    /* border: 1px solid #333; */

  
 }

/* .form.signup{
    opacity: 0;
    pointer-events: none;
}
.forms.Show-Signup .form.signup{
    opacity: 1;
    pointer-events: auto;
} */

.forms.Show-Signup .form.login{
    opacity: 0;
    pointer-events: none;
}

.heading{
    font-size: 28px;
    text-align: center;
    font-weight: 500 ;
    
}

.line{
    background-color: rgb(195, 195, 195);
    margin: 20px;
    height: 1px;
}
.underline{
    background-color: rgb(255, 119, 0);  
    margin: 8px 120px 40px 120px;
    height: 2.5px;
}

.contentl {
    margin: 0 20px;
    margin-bottom: 30px ;
}
.field{
    width: 100%;
    height: 35px;
    position: relative;
    margin: 10px 0 ;
}
.input{
    padding: 0 20px;
}
.field input,
.field button{

    width: 100%;
    height: 100%;
    padding: 0 15px;
    border-radius: 12px;
    font-family:'Gill Sans', 'Gill Sans MT', Calibri, 'Trebuchet MS', sans-serif;
}
.field input{
    outline: none;
    border-style: none none solid none;
    border-radius: 0;
}
.input .hide-show{
    position: absolute;
    top: 50%;
    right: 20px;
    opacity: 0.6;
    cursor: pointer;
}
.field input:focus{
    border-bottom: 2px solid;
}
.field button{
    background-color: #ffa442;
    border: none;
    color: #fff;
    font-size: 18px;
    font-weight: 100;
    cursor: pointer;
}
#btn{
    background-color: #ffa442;
    /* margin-left: 196px; */
    border: none;
    color: black;
    font-size: 18px;
    font-weight: 100;
    cursor: pointer;
    border-radius: 4px;
    padding: 5px;;
}

.forg {
    margin: 10px 0 23px 0;
    text-align: right;
    padding: 0 15px;
    text-decoration: none;
    cursor: pointer;
}
.link a,
.forg a{
    text-decoration: none;
}
.link{
    text-align: center;
    margin: 20px 0;
    cursor: pointer;
}

.thirdLogin{
    /* text-align: center; */
    border: 1px solid grey;
    display: flex;
    align-items: center;
    justify-content: center;
    border-radius: 5px;
    cursor: pointer;
   
}

.facebook{
    border-style: none;
    background-color: #3b5998;
    color: #fff;
}
.face-icon{
    position: absolute;
    left: 0;
    width: 30px;
    /* height: 30px; */
    font-size: 25px;
    padding-left: 5px;
    /* display: flex; */
    /* align-items: center; */
}
.Logout a{
    background-color: #ffa442; 
    border: transparent;
    color: white;
    font-size: 16px;
    font-weight: 100;
    cursor: pointer;
   text-decoration: none;
    
    

}
.google{
    opacity: 0.7;
}

.space{
    margin: 25px 0 10px 0;
}


     </style>
    
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.2/css/all.min.css"/>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" integrity="sha512-DTOQO9RWCH3ppGqcWaEA1BIZOC6xxalwEsw9c2QQeAIftl+Vegovlnee1c9QX4TctnWMn13TZye+giMm8e2LwA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <title>LogIn</title>
</head>
<body>
    <?php include "header.php"; ?>
    <section class="container forms">
        <div class="form login">
            <h3 class="heading">Login-Form</h3>
            <form name="form" action="login.php" method="POST" class="contentl">
                <div class="line underline"></div>
                <div class="field input">
                    <input type="text" id="user" name="user" placeholder="Enter your Username/Email" />
                </div>
                <div class="field input">
                    <input type="password" id="pass" name="pass" placeholder="Enter your Password" class="password" />
                    <i class='bx bx-hide hide-show'></i>
                </div>
                <div class="forg">
                <a href="forgot_password.php" class="forget">Forget password?</a>

                </div>
                <div class="field btn">
                    <input type="submit" id="btn" value="Login" name="submit"/>
                </div>
                <div class="link sign-login">
                    <span>Don't have an Account!</span>
                    <a href="signup.php" class="forget">Sign up</a>
                </div>
                <div class="line"></div>
                <!-- <div class="thirdLogin field facebook">
                    <i class='bx bxl-facebook-circle face-icon'></i>
                    <span>Login with facebook</span>
                </div>
                <div class="thirdLogin field google">
                    <i class='bx bxl-google face-icon'></i>
                    <span>Login with google</span>
                </div> -->
                <div class="thirdLogin field facebook">
                    
                <span><a href="./new folder/logina.php" style="text-decoration:none; color:#fff;">Login As An Admin</a></span>
                </div>
            </form>
        </div>
    </section>
    <script src="./script.js"></script>
    <?php include 'footer.php';?>  
</body>
</html>

<?php
include('connection.php');

// Delete user if delete action is triggered
if (isset($_GET['delete'])) {
    $id = $_GET['delete'];
    $query = "DELETE FROM signup WHERE id = $id";
    mysqli_query($conn, $query);
}

// Fetch all users
$query = "SELECT * FROM signup";
$result = mysqli_query($conn, $query);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Edit Display Users</title>
    <link rel="stylesheet" type="text/css" href="style3.css">
</head>
<body>
    <h1> Edit User Information</h1>
    <table border="1">
        <tr>
            <th>Username</th>
            <th>Email</th>
            <th>Password</th>
            <th>Action</th>
        </tr>
        <?php
        while ($row = mysqli_fetch_assoc($result)) {
            echo "<tr>";
            echo "<td>".$row['username']."</td>";
            echo "<td>".$row['email']."</td>";
            echo "<td>".$row['password']."</td>";
            echo "<td><a href='edit_display_users.php?delete=".$row['id']."'>Delete</a></td>";
            echo "</tr>";
        }
        ?>
    </table>
</body>
</html>

<?php
    session_start();
    if(!isset($_SESSION['loggedin']) || isset($_SESSION['loggedin'])!=true){
        header("location:login.php");
        exit;
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Highlighted Courses and Degree Courses</title>
   <style>
    /* styles.css */
body {
    font-family: Arial, sans-serif;
    line-height: 1.6;
    margin: 0;
    padding: 0;
  
    background-color: #7bcd6b91;
}

.containern {
    max-width: 1000px;
    margin: 75px auto;
    padding: 30px;
    background: #fff;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.7);
    /* border-radius: 8px; */
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.7);
}

h1 {
    color: #333;
    margin-bottom: 20px;
}
.containern p {
    color: #555;
    margin-bottom: 20px;
}
.course-card {
    border: 1px solid #ddd;
    padding: 20px;
    margin-bottom: 20px;
    border-radius: 8px;
}

.course-info {
    display: flex;
    align-items: center;
    
}

.course-info img {
    max-width: 120px;
    max-height: 80px;
    margin-right: 20px;
}

.course-details {
    flex: 1;
}

.course-details a {
    color: #0066cc;
    font-weight: bold;
    text-decoration: none;
}

.course-details a:hover {
    text-decoration: underline;
}

.badge {
    background-color: #e0e0e0;
    border-radius: 12px;
    padding: 3px 8px;
    font-size: 12px;
    margin-left: 10px;
}

.location {
    background-color: #e0e0e0;
    border-radius: 12px;
    padding: 3px 8px;
    font-size: 12px;
}

.button {
    display: inline-block;
    background-color: #007bff;
    color: black;
    padding: 10px 20px;
    text-align: center;
    border-radius: 5px;
    text-decoration: none;
    transition: background-color 0.3s ease;
    margin-top: 10px;
}
.course-details .button {
    color: white;
    
}
.button:hover {
    background-color: #0056b3;
}

.accordion {
    margin-top: 20px;
}

.accordion-item {
    background: #f9f9f9;
    border: 1px solid #ddd;
    border-radius: 5px;
    margin-bottom: 10px;
    overflow: hidden;
}

.accordion-button {
    width: 100%;
    /* color: white; */
    padding: 15px;
    text-align: left;
    background: #f9f9f9;
    border: none;
    cursor: pointer;
    font-size: 16px;
    transition: background-color 0.3s ease;
}

.accordion-button:hover {
    background: #e9e9e9;
}

.accordion-content {
    padding: 15px;
    display: none;
}

   </style>
</head>
<body>
<?php include 'header.php';?>
    <div class="containern">
    <h1>Degrees in the USA</h1>
    <p>In the USA, bachelor’s degrees are offered at a wide range of institutions including public and private universities, liberal arts colleges, and specialised schools. These programs typically award degrees such as Bachelor of Science (BSc), Bachelor of Arts (BA), or Bachelor of Engineering (BEng), as well as other qualifications.</p>

<p>English is the teaching language across all institutions, making the USA a popular destination for international students from around the globe.</p>
   
    <h1>How to Apply for a Degree in the USA</h1>
    <p>
    International students can apply directly to their chosen institution in the USA. Many universities use the Common Application or Coalition Application systems, which allow students to apply to multiple institutions at the same time. Required documents generally include academic transcripts, a motivation letter, a resume or CV, and letters of recommendation.

</p>

<p>

    Required documents usually include a personal statement, a resume or CV, academic transcripts, and proof of language proficiency. For non-native English speakers, language tests like IELTS, TOEFL, or Cambridge English exams are often necessary. Academic requirements may involve a minimum GPA, and maybe specific subjects.
</p>
        <h1>Highlighted courses in The Netherlands</h1>
        <div class="course-card">
            <div class="course-info">
                <img src="https://media.studylink.com/provider/columbia-university-school-of-professional-studies/columbia-university-school-of-professional-studies-logo.webp">
                <div class="course-details">
                    <a href="https://sps.columbia.edu/academics/masters/technology-management?utm_campaign=nn-studylink-2324-profile&utm_source=studylink&utm_medium=profile-course-listings">Technology Management</a> <span class="badge">MSc</span>
                    <p>Columbia University, School of Professional Studies  <span class="location">United States</span></p>
                    <a href="https://sps.columbia.edu/academics/masters/technology-management?utm_campaign=nn-studylink-2324-profile&utm_source=studylink&utm_medium=profile-course-listings" class="button">Find out more</a>
                </div>
            </div>
        </div>
        <div class="course-card">
            <div class="course-info">
                <img src="https://media.studylink.com/provider/university-of-chicago/university-of-chicago-logo.webp" alt="Erasmus School of Social and Behavioural Sciences">
                <div class="course-details">
                    <a href="https://college.uchicago.edu/academics/summer-session?utm_source=studylink&utm_medium=profile&utm_campaign=studylink">Building the New Venture</a> <span class="badge">Other UG Award, Summer Course</span>
                    <p>University of Chicago <span class="location">United States</span></p>
                    <a href="https://college.uchicago.edu/academics/summer-session?utm_source=studylink&utm_medium=profile&utm_campaign=studylink" class="button">Find out more</a>
                </div>
            </div>
        </div>
        <div class="course-card">
            <div class="course-info">
                <img src="https://media.studylink.com/provider/john-jay-college-of-criminal-justice/john-jay-college-of-criminal-justice-logo.webp" alt="Erasmus School of Economics">
                <div class="course-details">
                    <a href="https://www.eur.nl/en/ese/research-master/research-master-economics?utm_campaign=studylink&utm_content=Economics&utm_medium=profile&utm_source=studylink">Fraud Examination and Financial Forensics</a> <span class="badge">BS</span>
                    <p>John Jay College of Criminal Justice<span class="location">United States</span></p>
                    <a href="https://www.eur.nl/en/ese/research-master/research-master-economics?utm_campaign=studylink&utm_content=Economics&utm_medium=profile&utm_source=studylink" class="button">Find out more</a>
                </div>
            </div>
            </div>

            <div class="course-card">
            <div class="course-info">
                <img src="https://media.studylink.com/provider/city-university-of-seattle/city-university-of-seattle-logo.webp" alt="Erasmus School of Economics">
                <div class="course-details">
                    <a href="https://www.cityu.edu/?utm_source=studylink&utm_medium=profile&utm_campaign=studylink">Master of Science in Computer Science</a> <span class="badge">MSCS</span>
                    <p>City University of Seattle <span class="location">United States</span></p>
                    <a href="https://www.cityu.edu/?utm_source=studylink&utm_medium=profile&utm_campaign=studylink"class="button">Find out more</a>
                </div>
            </div>
            </div>
            <div class="course-card">
            <div class="course-info">
                <img src="https://media.studylink.com/provider/ball-state-university/ball-state-university-logo.webp">
                <div class="course-details">
                    <a href="https://www.bsu.edu/?utm_source=studylink&utm_medium=profile&utm_campaign=studylink">Master's Degree in Residential Property Management </a> <span class="badge">MA, MSc</span>
                    <p>Ball State University<span class="location">United States</span></p>
                    <a href="https://www.bsu.edu/?utm_source=studylink&utm_medium=profile&utm_campaign=studylink"class="button">Find out more</a>
                </div>
            </div>
            </div>
            <div class="course-card">
            <div class="course-info">
                <img src="https://media.studylink.com/provider/university-of-central-florida/university-of-central-florida-logo.webp">
                <div class="course-details">
                    <a href="https://www.ucf.edu/?utm_source=studylink&utm_medium=profile&utm_campaign=studylink">Interactive Entertainment (MS) </a> <span class="badge">MSc</span>
                    <p>University of Central Florida <span class="location">United States</span></p>
                    <a href="https://www.ucf.edu/?utm_source=studylink&utm_medium=profile&utm_campaign=studylink"class="button">Find out more</a>
                </div>
            </div>
        </div>

        <h1>Degree courses you may be interested in studying in USA</h1>
        <div class="accordion">
            <div class="accordion-item">
                <button class="accordion-button">Agriculture degree courses in the USA</button>
            </div>
            <div class="accordion-item">
                <button class="accordion-button">Architecture degree courses in the USA</button>
            </div>
            <div class="accordion-item">
                <button class="accordion-button">Humanities degree courses in the USA</button>
            </div>
            <div class="accordion-item">
                <button class="accordion-button">Business degree courses in the USA</button>
            </div>
            <div class="accordion-item">
                <button class="accordion-button">Computing degree courses in the USA</button>
            </div>
            <div class="accordion-item">
                <button class="accordion-button">Creative degree courses in the USA</button>
            </div>
            <div class="accordion-item">
                <button class="accordion-button">Education degree courses in the USA</button>
            </div>
            <div class="accordion-item">
                <button class="accordion-button">Engineering degree courses in USA</button>
            </div>
            <div class="accordion-item">
                <button class="accordion-button">English degree courses in the USA</button>
            </div>
            <div class="accordion-item">
                <button class="accordion-button">Health degree courses in the USA</button>
            </div>
        </div>
    </div>

    <script >
document.querySelectorAll('.accordion-button').forEach(button => {
    button.addEventListener('click', () => {
        const accordionContent = button.nextElementSibling;

        button.classList.toggle('accordion-button-active');

        if (button.classList.contains('accordion-button-active')) {
            accordionContent.style.display = 'block';
        } else {
            accordionContent.style.display = 'none';
        }
    });
});
</script>
<?php include 'footer.php';?>
</body>
</html>

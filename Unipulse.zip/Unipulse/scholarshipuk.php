<?php
    session_start();
    if(!isset($_SESSION['loggedin']) || isset($_SESSION['loggedin'])!=true){
        header("location:login.php");
        exit;
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>scholarship in UK</title>
    <!-- <link rel="stylesheet" href="scholuk.css"> -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.2/css/all.min.css"/>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" integrity="sha512-DTOQO9RWCH3ppGqcWaEA1BIZOC6xxalwEsw9c2QQeAIftl+Vegovlnee1c9QX4TctnWMn13TZye+giMm8e2LwA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <style>
        * {
    padding: 0;
    margin: 0;

}
body{
    
    background-color: #7bcd6b57;
}
.img {
    background-image: linear-gradient(to top, rgba(1, 1, 5, 0.853), rgba(2, 2, 12, 0.233)), url(images/uk_flag1.png);
    width: 70%;
    height: 400px;
    background-repeat: no-repeat;
    background-size: cover;
    margin-top: 98px;
    margin-left: 250px;
    border-radius: 15px;

}

.imagtitle {
    padding-top: 375px;
    padding-left: 21px;
    color: whitesmoke;
    font-family: 'Franklin Gothic Medium', 'Arial Narrow', Arial, sans-serif;

}

.bar {
    height: 50px;
    width: 500px;
    background-color: rgb(255, 162, 0);
    margin-top: 50px;
    margin-left: 300px;
    margin-right: 300px;

    border-radius: 5px;
    font-family: 'Gill Sans', 'Gill Sans MT', Calibri, 'Trebuchet MS', sans-serif;


}

.bar p {
    margin-left: 18px;
    padding-top: 14px;

}

.bar p a {
    text-decoration: none;
    color: black;
}

.bar:hover {
    background-color: rgba(255, 162, 0, 0.684);
}

.con1 {
    margin-top: 50px;
    margin-left: 300px;
    margin-right: 300px;
    font-family: Cambria, Cochin, Georgia, Times, 'Times New Roman', serif;
    color: rgb(39, 37, 37);
    line-height: 1.5;
    font-size: 1.1rem;
}
.con2{
    margin-top: 50px;
    margin-left: 300px;
    margin-right: 300px;
    font-family: Cambria, Cochin, Georgia, Times, 'Times New Roman', serif;
    color: rgb(39, 37, 37);
    font-size: 2.5rem;
    line-height: 1.5;
    
}
.con3{
    margin-top: 50px;
    margin-left: 300px;
    margin-right: 300px;
    font-family: Georgia, 'Times New Roman', Times, serif;
    color: rgb(39, 37, 37);
    line-height: 1.5;
   padding-bottom: 30px;

}
.con3 a {
    text-decoration: none;
    line-height: 1.5;

    color: rgba(31, 6, 251, 0.836);
}

.con3 a:hover {

    color: rgb(31, 6, 251);
}
    </style>
</head>
<body>
    <?php include 'header.php';?>
    
    <div class="img">
        <div class="imagtitle">Scholarships to Study in the UK </div>
    </div>
<div class="bar">
    <p> <a href="std_uk_study.php">Find out all you need to know about studying in the UK!</a></p>
</div>
    <div class="con1">
    <p>UK education doesn’t come cheap these days, making scholarships and similar funding opportunities highly sought-after. Although this means that scholarship funding is extremely competitive, it also means a growing number of scholarships are being offered as UK universities seek to attract the most talented international students.
</p>
<br>
       <p>
        Below you’ll find a selection of scholarships to study in the UK, some funded by the UK government, some by external organizations, and many by individual UK universities.</p>
    </div>
    <div class="con2">
        Government-funded UK scholarships for international students
    </div>
    <div class="con3">
        <ul>
            <li><a href="https://www.chevening.org/">British Chevening Scholarships </a> UK scholarships for international students funded by the UK Foreign and Commonwealth Office and partner organizations. The scholarships provide full or part funding for full-time graduate programs in any subject</li> <br> <br>
            <li><a href="http://cscuk.dfid.gov.uk/">Commonwealth Scholarships for Developing Commonwealth Countries </a>  Scholarships for international students from developing countries in the Commonwealth, for studies at master’s and PhD level. The full list of eligible countries is available here.</li> <br> <br>
            <li><a href="http://www.marshallscholarship.org/">Marshall Scholarships </a>  – Postgraduate scholarships for US students showing academic merit, leadership potential and ambassadorial potential to study in the UK. Excludes MBAs and certain courses.</li>
        </ul>
    </div>
    <div class="con2">
        Non-governmental UK scholarships for international students
    </div>
    <div class="con3">
        <ul>
            <li><a href="https://www.euraxess.org.uk/united-kingdom/funding-opportunities/fundin">Euraxess UK </a>   Euraxess is an initiative of the European Commission, providing support for researchers in Europe. The UK branch of the scheme is run by the British Council, offering various graduate research scholarships for international students from around the world</li> <br> <br>
            <li><a href="http://castlesmart.com/on-load-popup/">CastleSmart Scholarship </a>  Estate agent CastleSmart offers £6,000 annually for an undergraduate student in the UK (open to all nationalities). Applicants must create a compelling YouTube video outlining their study and career plans.</li> <br> <br>
            <li><a href="https://surfshark.com/student-discount">Surfshark Privacy and Security Scholarship</a>A $2,000 prize is available to a student currently enrolled in the UK or another study destination as a high school, undergraduate or graduate student. You will need to submit an essay to apply and the scholarship is open to all nationalities. </li><br> <br>
            <li><a href="https://royalsociety.org/grants/">The Royal Society Grants</a>Various grants and fellowships are available for talented researchers in the UK and beyond </li>

        </ul>
    </div>
    <?php include 'footer.php';?>
</body>
</html>
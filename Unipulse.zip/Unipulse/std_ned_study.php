<?php
    session_start();
    if(!isset($_SESSION['loggedin']) || isset($_SESSION['loggedin'])!=true){
        header("location:login.php");
        exit;
    }
?>
<!DOCTYPE html>
<html>
<head>
<style>
body {
  font-family: Arial, sans-serif;
  margin: 0;
  padding: 0;
  background-color: #f8f9fa;
}

.why {
    margin-top: 108px;
  max-width: 1000px;
  margin: 50px auto;
  padding: 20px;
  background-color: #fff;
  box-shadow: 0 0 10px rgba(0, 0, 0, 0.7);
}

.why h1 {
  font-size: 2.5em;
  color: #333;
  margin-bottom: 20px;
}

.why p {
  line-height: 1.6;
  color: #555;
  margin-bottom: 15px;
}

.why p a {
  color: #007bff;
  text-decoration: none;
}

.why p a:hover {
  text-decoration: underline;
}

.buttond {
  display: inline-block;
  padding: 10px 20px;
  background-color: #004a45;
  color: #fff;
  border: none;
  border-radius: 5px;
  cursor: pointer;
  margin-right: 10px;
}

.buttond:hover {
  background-color: #00332f;
}
.about {
  display: flex;
  flex-direction: column;
  width: 600px;
  margin: 0 auto;
  padding: 20px;
  border: 1px solid #ccc;
  border-radius: 5px;
  background-color: #f9f9f9;
}
.headera {
  font-size: 24px;
  font-weight: bold;
  margin-bottom: 20px;
}
.info-row {
  display: flex;
  justify-content: space-between;
  margin-bottom: 10px;
}
.info-label {
  font-weight: bold;
}
.info-value {
  text-align: right;
}
a {
  color: blue;
  text-decoration: none;
}
a:hover {
  text-decoration: underline;
}
.qs {
  max-width: 1000px;
  margin: 50px auto;
  padding: 20px;
  background-color: #fff;
  box-shadow: 0 0 10px rgba(0, 0, 0, 0.7);
}
.qs h1 {
  margin-top: 40px;
  font-size: 2.5em;
  color: #333;
  margin-bottom: 20px;
}
.qs h1 {
  margin-top: 40px;
}
.qs  h2 {
  margin-top: 40px;
  color: #331;
}
.qs p {
  margin-bottom: 10px;
    line-height: 1.6;
  color: #555;
  margin-bottom: 15px;
  
}

.qs a {
  color: #007bff;
  text-decoration: none;
}

.qs a:hover {
  text-decoration: underline;
}

.howapp {
  max-width: 1000px;
  margin: 50px auto;
  padding: 20px;
  background-color: #fff;
  box-shadow: 0 0 10px rgba(0, 0, 0, 0.7);
}
.howapp h1 {
  margin-top: 40px;
  font-size: 2.5em;
  color: #333;
  margin-bottom: 20px;
}
.howapp p {
  margin-bottom: 10px;
    line-height: 1.6;
  color: #555;
  margin-bottom: 15px;
  
}
.howapp ul {
  list-style-type: disc;
  margin-left: 20px;
  color: #555;
}
.howapp a {
  color: #007bff;
  text-decoration: none;
}
.howapp a:hover {
  text-decoration: underline;
}
</style>
</head>
<body>
<?php include 'header.php';?>
<div class="why" style="margin-top: 108px;">
  <h1>Why study abroad in the Netherlands</h1>
  <p>Sitting in a region of Europe called the Low Countries, the Netherlands is a well developed and diverse country. The country's location, as well as the sights and locations, make it a very popular destination for both international students and tourists alike.</p>
  <p>There is a lot to see and do in the Netherlands, and it has great transport links with its surrounding countries, meaning you will have freedom to travel and sightsee within mainland Europe with relative ease.</p>
  <p>There are two types of higher education institutions in the Netherlands: <a href="https://en.wikipedia.org/wiki/Vocational_university#Netherlands">universities of applied sciences</a> (hogescholen; HBO), and research universities (universiteiten; WO). Both universities award globally recognised degree classifications. You can find out more about this on our <a href="https://en.wikipedia.org/wiki/List_of_universities_in_the_Netherlands">universities in the Netherlands</a> page.</p>
  <p>As a European country, the Netherlands follows the Bologna Process and ECTS, meaning that your qualifications will be recognised throughout the rest of Europe. This is useful if you choose to pursue further studies or for your future career.</p>
  <p>Throughout the Netherlands you will find many interesting and welcoming cities. These include the capital <a href="https://en.wikipedia.org/wiki/Amsterdam">Amsterdam</a>, Leiden, Rotterdam, Utrecht and The Hague. Any of these cities would be an excellent choice for you as an international student.</p>
  <a href="std_ned_deg.php"><button class="buttond">Degrees in the Netherlands</button></a>
  <a href="scholarshipned.php"><button class="buttond">Scholarship in the Netherlands</button></a>
  <a href="std_ned_uni.php"><button class="buttond">All universities in the Netherlands</button></a>
</div>
<div class="why">
  <h1 class="headera">About the Netherlands</h1>
  <!-- <div class="info-row">
    <div class="info-label">Continent</div>
    <div class="info-value"><a href="https://en.wikipedia.org/wiki/Europe">Europe</a></div>
  </div> -->
  <div class="info-row">
    <div class="info-label">Language(s) of tuition</div>
    <div class="info-value">English, Dutch</div>
  </div>
  <div class="info-row">
    <div class="info-label">Universities on StudyLink</div>
    <div class="info-value"><a href="https://en.wikipedia.org/wiki/University_of_Amsterdam">42 universities</a></div>
  </div>
  <div class="info-row">
    <div class="info-label">Major Student Cities</div>
    <div class="info-value"><a href="https://en.wikipedia.org/wiki/Amsterdam">Amsterdam (capital), Leiden, The Hague, Rotterdam, Utrecht</a></div>
  </div>
</div>
<div class="qs">
<h1>Common student questions</h1>

<h2>Can I study in the Netherlands for free?</h2>
<p>Public higher education is government subsidized in the Netherlands, meaning that international students from the EU/EEA pay a fixed fee each year. This fee is normally updated every year, in line with inflation and the general cost of living. If you are from a country outside of the EU/EEA, your tuition fee is not fixed, and universities can charge you more. If you study at a private university, your tuition fees can be higher, regardless of where you are from.</p>

<h2>Can I study in the Netherlands as an international student?</h2>
<p>The Netherlands has a large international population, and this translates into its student population. As a founding member of many international organisations, the Netherlands is very welcoming to all international students. As an international student, you will likely need to obtain a visa in order to study in the Netherlands. For more information about this, take a look at our <a href="#">Netherlands Student Visas</a> article.</p>

<h2>Can I study in the Netherlands with English?</h2>
<p>The Netherlands is a country that is very diverse in terms of the languages spoken and understood. Many Dutch universities offer their courses in English as well as Dutch. If your first language is not English, you will need to provide evidence of your language proficiency. Most Dutch universities accept an IELTS or TOEFL certificate.</p>

</div>
<div class="howapp">
<h1>How to apply</h1>
<p>Applying to university in the Netherlands as an international student is a straightforward process. You can either choose to apply to each university individually, or can use the ‘Studielink’ system, which is centralised and allows you to apply to all the universities you are interested in. You will have to pay an application fee for each university you apply to.</p>
<p>Common application requirements for universities in the USA include</p>
<ul>
  <li>High school diploma</li>
  <li>Transcripts</li>
  <li>Standardised test scores (SAT or ACT)</li>
  <li>English language proficiency test scores (TOEFL or IELTS)</li>
  <li>Letters of recommendation</li>
  <li>Recommendation letters</li>
</div>
<div class="howapp">
<h1>Cost of studying in the Netherlands for international students</h1>
<p>The Netherlands uses the Euro (€) as its currency..</p>
<p>Tuition fees for EU/EEA students at public universities in the Netherlands are subsidised by the Dutch government, meaning that you will pay a fixed fee of €2,530 per year (as of the 2024/25 academic year), which is the same as domestic Dutch students.</p>
<p>If you are from a country outside of the EU/EEA area, then you should expect to pay between €6,000 and €15,000 per year for an undergraduate course, and between €8,000 and €20,000 per year for a postgraduate course. If you choose to go to a private higher education institution, you can expect to pay a higher tuition fee whether you are an EU/EEA or international student.</p>
<p>Your living costs will depend on where you live in the Netherlands. The bigger cities will be more expensive than the smaller cities and towns. On average, you should budget between €500 and €1,500 per month for accommodation, travel, food and other living expenses. Many bars, restaurants and tourist attractions offer student discounts when you show your institution student card. </p>
</div>
<div class="howapp">
<h1>Student visa</h1>
<p>International students who wish to study in the Netherlands might be required to obtain a valid student visa. If you are from an EU/EEA country (or Switzerland) you will be exempt from any visa requirements. If you are from any other country, you will need to apply for an MVV or Entry visa, which is a long term visa. For more information about student visas and how to apply for one as an international student, see  <a href="https://studylink.com/countries/netherlands/netherlands-student-visa-guide/"> USA Student Visa Guide</a>.</p>
</div>
<?php include 'footer.php';?>
</body>
</html>
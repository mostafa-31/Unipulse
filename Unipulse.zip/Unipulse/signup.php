<?php
    session_start();
    if(isset($_SESSION['username'])){
        header("Location: welcome.php");
        exit();
    }
?>
<?php
    include("connection.php");
    if(isset($_POST['submit'])){
        $username = mysqli_real_escape_string($conn, $_POST['user']);
        $email = mysqli_real_escape_string($conn, $_POST['email']);
        $password = mysqli_real_escape_string($conn, $_POST['pass']);
        $cpassword = mysqli_real_escape_string($conn, $_POST['cpass']);
        
        $sql="select * from signup where username='$username'";
        $result = mysqli_query($conn, $sql);
        $count_user = mysqli_num_rows($result);

        $sql="select * from signup where email='$email'";
        $result = mysqli_query($conn, $sql);
        $count_email = mysqli_num_rows($result);

        if($count_user == 0 && $count_email == 0){
            if($password == $cpassword){
                $hash = password_hash($password, PASSWORD_DEFAULT);
                $sql = "INSERT INTO signup(username, email, password) VALUES('$username', '$email', '$hash')";
                $result = mysqli_query($conn, $sql);
                if($result){
                    echo '<script>
                        alert("Sign up successful");
                        window.location.href = "login.php";
                    </script>';
                    exit();
                }
            } else {
                echo '<script>
                    alert("Passwords do not match");
                    window.location.href = "signup.php";
                </script>';
            }
        } else {
            if($count_user > 0){
                echo '<script>
                    alert("Username already exists!!");
                    window.location.href="signup.php";
                </script>';
            }
            if($count_email > 0){
                echo '<script>
                    alert("Email already exists!!");
                    window.location.href="signup.php";
                </script>';
            }
        }
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        * {
            padding: 0;
            margin: 0;
            box-sizing: border-box;
        }

        nav {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            z-index: 1000; /* Ensure navigation bar stays above other content */
        }

        .container {
            background: linear-gradient(360deg, rgb(245, 255, 245) 0%, rgb(173, 252, 163) 100%);
            display: flex;
            background-position: center;
            align-items: center;
            justify-content: center;
            width: 100%;
            height: 100vh;
            column-gap: 0px;
            font-family: 'Gill Sans', 'Gill Sans MT', Calibri, 'Trebuchet MS', sans-serif;
        }

        .form {
            position: absolute;
            max-width: 450px;
            width: 100%;
            margin: 20px;
            padding-top: 15px;
            background-color: rgb(255, 255, 255);
            border-radius: 8px;
            box-shadow: 10px 10px 10px rgba(0, 0, 0, 0.2);
        }

        .forms.Show-Signup .form.login {
            opacity: 0;
            pointer-events: none;
        }

        .heading {
            font-size: 28px;
            text-align: center;
            font-weight: 500;
        }

        .line {
            background-color: rgb(195, 195, 195);
            margin: 20px;
            height: 1px;
        }

        .underline {
            background-color: rgb(255, 119, 0);
            margin: 8px 120px 40px 120px;
            height: 2.5px;
        }

        .contentl {
            margin: 0 20px;
            margin-bottom: 30px;
        }

        .field {
            width: 100%;
            height: 35px;
            position: relative;
            margin: 10px 0;
        }

        .input {
            padding: 0 20px;
        }

        .field input,
        .field button {
            width: 100%;
            height: 100%;
            padding: 0 15px;
            border-radius: 12px;
            font-family: 'Gill Sans', 'Gill Sans MT', Calibri, 'Trebuchet MS', sans-serif;
        }

        .field input {
            outline: none;
            border-style: none none solid none;
            border-radius: 0;
        }

        .input .hide-show,
        .input .hide-show-retype {
            position: absolute;
            top: 50%;
            right: 20px;
            opacity: 0.6;
            cursor: pointer;
            transform: translateY(-50%);
        }

        .field input:focus {
            border-bottom: 2px solid;
        }

        .field button {
            background-color: #ffa442;
            border: none;
            color: #fff;
            font-size: 18px;
            font-weight: 100;
            cursor: pointer;
        }

        #btn {
            background-color: #ffa442;
            border: none;
            color: black;
            font-size: 18px;
            font-weight: 100;
            cursor: pointer;
            border-radius: 4px;
            padding: 5px;
        }

        .forg {
            margin: 10px 0 23px 0;
            text-align: right;
            padding: 0 15px;
            text-decoration: none;
            cursor: pointer;
        }

        .link a,
        .forg a {
            text-decoration: none;
        }

        .link {
            text-align: center;
            margin: 20px 0;
            cursor: pointer;
        }

        .thirdLogin {
            border: 1px solid grey;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 5px;
            cursor: pointer;
        }

        .facebook {
            border-style: none;
            background-color: #3b5998;
            color: #fff;
        }

        .face-icon {
            position: absolute;
            left: 0;
            width: 30px;
            font-size: 25px;
            padding-left: 5px;
        }

        .Logout a {
            background-color: #ffa442;
            border: transparent;
            color: white;
            font-size: 16px;
            font-weight: 100;
            cursor: pointer;
            text-decoration: none;
        }

        .google {
            opacity: 0.7;
        }

        .space {
            margin: 25px 0 10px 0;
        }
    </style>
    <link href="https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css" rel="stylesheet">
    <title>Signup</title>
</head>
<body>
    <?php include "header.php"; ?>
    <section class="container forms">
        <div class="form signup">
            <h3 class="heading">SignUp-Form</h3>
            <form name="form" action="signup.php" method="POST" class="contentl">
                <div class="line underline"></div>
                <div class="field input">
                    <input type="text" id="user" name="user" placeholder="Enter username" required>
                </div>
                <div class="field input">
                    <input type="email" id="email" name="email" placeholder="Enter your Email" required>
                </div>
                <div class="field input">
                    <input type="password" id="pass" name="pass" placeholder="Enter your new Password" class="password" required>
                    <i class="bx bx-hide hide-show"></i>
                </div>
                <div class="field input">
                    <input type="password" id="cpass" name="cpass" placeholder="Confirm Password" class="password" required>
                    <i class="bx bx-hide hide-show-retype"></i>
                </div>
                <div class="space"></div>
                <div class="field btn">
                    <input type="submit" id="btn" value="Sign Up" name="submit"/>
                </div>
                <div class="link sign-login">
                    <span>Already have an Account!</span>
                    <a href="login.php" class="forget">Login</a>
                </div>
                <div class="line"></div>
                <!-- <div class="thirdLogin field facebook">
                    <i class="bx bxl-facebook-circle face-icon"></i>
                    <span>SignUp with Facebook</span>
                </div>
                <div class="thirdLogin field google">
                    <i class="bx bxl-google face-icon"></i>
                    <span>SignUp with Google</span>
                </div> -->
                <div class="thirdLogin field facebook">
                    
                    <span><a href="./new folder/signupa.php" style="text-decoration:none; color:#fff;">Sign Up As An Admin</a></span>
                    </div>
            </form>
        </div>
    </section>
    <script>
        document.addEventListener('DOMContentLoaded', () => {
            const hideShowIcon1 = document.querySelector('.hide-show');
            const passwordInput1 = document.getElementById('pass');

            hideShowIcon1.addEventListener('click', () => {
                if (passwordInput1.type === 'password') {
                    passwordInput1.type = 'text';
                    hideShowIcon1.classList.replace('bx-hide', 'bx-show');
                } else {
                    passwordInput1.type = 'password';
                    hideShowIcon1.classList.replace('bx-show', 'bx-hide');
                }
            });

            const hideShowIcon2 = document.querySelector('.hide-show-retype');
            const passwordInput2 = document.getElementById('cpass');

            hideShowIcon2.addEventListener('click', () => {
                if (passwordInput2.type === 'password') {
                    passwordInput2.type = 'text';
                    hideShowIcon2.classList.replace('bx-hide', 'bx-show');
                } else {
                    passwordInput2.type = 'password';
                    hideShowIcon2.classList.replace('bx-show', 'bx-hide');
                }
            });
        });
    </script>
    <?php include 'footer.php';?>
</body>
</html>


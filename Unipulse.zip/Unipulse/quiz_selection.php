<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Select Subjects</title>
   <style>
      .selection-form {
         text-align: center;
         margin-top: 50px;
      }
      .selection-form label {
         margin-right: 20px;
      }
      .selection-form button {
         padding: 10px 20px;
         margin-top: 20px;
      }
   </style>
</head>
<body>
   <div class="selection-form">
      <h2>Select Subjects for Quiz</h2>
      <form action="quiz.php" method="POST">
         <label><input type="checkbox" name="subjects[]" value="physics"> Physics</label>
         <label><input type="checkbox" name="subjects[]" value="chemistry"> Chemistry</label>
         <label><input type="checkbox" name="subjects[]" value="math"> Math</label>
         <br>
         <button type="submit">Start Quiz</button>
      </form>
   </div>
</body>
</html>

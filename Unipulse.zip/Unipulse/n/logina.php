<?php
include 'config.php';
session_start();

if (isset($_SESSION['admin_id'])) {
    header("Location: profile.php");
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'];
    $password = $_POST['password'];

    $sql = "SELECT id, password FROM admins WHERE username=?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        if (password_verify($password, $row['password'])) {
            $_SESSION['admin_id'] = $row['id'];
            $_SESSION['admin_loggedin'] = true;
            header("Location: dashboard.php");
            exit();
        } else {
            echo '<script>
                    alert("Invalid password.");
                    window.location.href = "logina.php";
                  </script>';
        }
    } else {
        echo '<script>
                alert("No user found with that username.");
                window.location.href = "logina.php";
              </script>';
    }

    $stmt->close();
    $conn->close();
}
?>

<!DOCTYPE html>
<html>
<head>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f2f2f2;
            color: #ffffff;
        }

        .form-container {
            background-color: #11101d;
            padding: 20px;
            border-radius: 8px;
            width: 400px;
            height: 400px;
            margin: 0 auto;
            margin-top: 100px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.5);
        }

        .form-container h2 {
            text-align: center;
            margin-bottom: 40px;
        }

        .form-container form {
            display: flex;
            flex-direction: column;
        }

        input[type="text"],
        input[type="password"] {
            background: transparent;
            border: none;
            border-bottom: 2px solid #ffffff;
            color: #ffffff;
            padding: 2px;
            margin-bottom: 30px;
            outline: none;
        }

        input[type="submit"] {
            background-color: #4CAF50;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            margin-bottom: 30px;
        }

        input[type="submit"]:hover {
            background-color: #45a049;
        }

        .form-container form span {
            cursor: pointer;
            position: absolute;
            margin-left: 334px;
            margin-top: -36px;
        }

        .signup-link {
            text-align: center;
            margin-top: 10px;
        }

        .signup-link a {
            color: #4CAF50;
            text-decoration: none;
        }

        .signup-link a:hover {
            text-decoration: underline;
        }
    </style>
    <script>
        function togglePasswordVisibility(id) {
            var passwordField = document.getElementById(id);
            if (passwordField.type === "password") {
                passwordField.type = "text";
            } else {
                passwordField.type = "password";
            }
        }
    </script>
</head>
<body>
<?php include 'sidebar.php'; ?>
    <div class="form-container">
        <h2>Login Form</h2>
        <form method="post" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>">
            <label for="username">Username:</label>
            <input type="text" name="username" id="username" required>
            <label for="password">Password:</label>
            <input type="password" name="password" id="password" required>
            <span onclick="togglePasswordVisibility('password')" style="margin-top: 102px;">👁️</span>
            <input type="submit" value="Login">
        </form>
        <div class="signup-link"> Don't have an account?<a href="signupa.php"> Sign up here.</a> </div>
    </div>
</body>
</html>

<?php
include 'config.php';
session_start();

if (isset($_SESSION['admin_id'])) {
    header("Location: profile.php");
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['email'];
    $username = $_POST['username'];
    $password = $_POST['password'];
    $retype_password = $_POST['retype_password'];

    if ($password !== $retype_password) {
        echo '<script>
                alert("Passwords do not match.");
                window.location.href = "signupa.php";
              </script>';
    } else {
        // Check if username already exists
        $sql = "SELECT id FROM admins WHERE username=?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("s", $username);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            echo '<script>
                    alert("Username already exists.");
                    window.location.href = "signupa.php";
                  </script>';
        } else {
            $hashed_password = password_hash($password, PASSWORD_DEFAULT);
            $sql = "INSERT INTO admins (email, username, password) VALUES (?, ?, ?)";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("sss", $email, $username, $hashed_password);

            if ($stmt->execute() === TRUE) {
                header("Location: logina.php");
                exit();
            } else {
                echo "Error: " . $sql . "<br>" . $conn->error;
            }
        }

        $stmt->close();
    }

    $conn->close();
}
?>

<!DOCTYPE html>
<html>
<head>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f2f2f2;
            color: #ffffff;
        }

        .form-container {
            background-color: #11101d;
            padding: 20px;
            border-radius: 8px;
            width: 400px;
            margin: 0 auto;
            margin-top: 100px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.5);
        }

        .form-container h2 {
            text-align: center;
            padding-bottom: 25px;
        }

        .form-container form {
            display: flex;
            flex-direction: column;
        }

        input[type="text"],
        input[type="email"],
        input[type="password"] {
            background: transparent;
            border: none;
            border-bottom: 2px solid #ffffff;
            color: #ffffff;
            padding: 2px;
            margin-bottom: 30px;
            outline: none;
        }

        .form-container input[type="submit"] {
            background-color: #4CAF50;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }

        .form-container input[type="submit"]:hover {
            background-color: #45a049;
        }

        .form-container span {
            cursor: pointer;
            position: absolute;
        }

        .eye-icon {
            margin-left: 334px;
        }

        .eye-icon-password {
            margin-top: 188px;
            
        }

        .eye-icon-retype {
            margin-top: 268px;
        }

        .login-link {
            text-align: center;
            margin-top: 10px;
        }

        .login-link a {
            color: #4CAF50;
            text-decoration: none;
        }

        .login-link a:hover {
            text-decoration: underline;
        }
    </style>
    <script>
        function togglePasswordVisibility(id) {
            var passwordField = document.getElementById(id);
            if (passwordField.type === "password") {
                passwordField.type = "text";
            } else {
                passwordField.type = "password";
            }
        }
    </script>
</head>
<body>
<?php include 'sidebar.php'; ?>
    <div class="form-container">
        <h2>Signup Form</h2>
        <form method="post" action="<?php echo $_SERVER['PHP_SELF'];?>">
            Email: <input type="email" name="email" required><br>
            Username: <input type="text" name="username" required><br>
            Password: 
            <input type="password" name="password" id="password" required>
            <span class="eye-icon eye-icon-password" onclick="togglePasswordVisibility('password')">👁️</span><br>
            Retype Password: 
            <input type="password" name="retype_password" id="retype_password" required>
            <span class="eye-icon eye-icon-retype" onclick="togglePasswordVisibility('retype_password')">👁️</span><br>
            <input type="submit" value="Signup">
        </form>
        <div class="login-link">
            Already have an account? <a href="logina.php">Login</a>
        </div>
    </div>
</body>
</html>

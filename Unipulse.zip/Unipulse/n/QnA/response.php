<!DOCTYPE html>
<html>
<head>
    <title>Respond to Questions</title>
</head>
<body>
    <h1>Respond to Questions</h1>
    <?php
    $conn = new mysqli('localhost', 'root', '', 'qna_system');

    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        $id = (int)$_POST['id'];
        $answer = $conn->real_escape_string($_POST['answer']);
        $conn->query("UPDATE questions SET answer='$answer' WHERE id=$id");
    }

    $result = $conn->query("SELECT * FROM questions WHERE answer IS NULL ORDER BY created_at DESC");
    while ($row = $result->fetch_assoc()) {
        echo "<form method='post' action='response.php'>";
        echo "<p><strong>Question:</strong> " . htmlspecialchars($row['question']) . "</p>";
        echo "<textarea name='answer' required></textarea><br>";
        echo "<input type='hidden' name='id' value='" . $row['id'] . "'>";
        echo "<input type='submit' value='Answer'>";
        echo "</form><hr>";
    }

    $conn->close();
    ?>
</body>
</html>

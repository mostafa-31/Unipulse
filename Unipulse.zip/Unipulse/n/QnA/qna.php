<!DOCTYPE html>
<html>
<head>
    <title>Q&A System</title>
</head>
<body>
    <h1>Ask a Question</h1>
    <form method="post" action="qna.php">
        <textarea name="question" required></textarea><br>
        <input type="submit" value="Ask">
    </form>

    <h2>Questions and Answers</h2>
    <?php
    $conn = new mysqli('localhost', 'root', '', 'qna_system');

    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        $question = $conn->real_escape_string($_POST['question']);
        $conn->query("INSERT INTO questions (question) VALUES ('$question')");
    }

    $result = $conn->query("SELECT * FROM questions ORDER BY created_at DESC");
    while ($row = $result->fetch_assoc()) {
        echo "<div>";
        echo "<p><strong>Question:</strong> " . htmlspecialchars($row['question']) . "</p>";
        echo "<p><strong>Answer:</strong> " . htmlspecialchars($row['answer']) . "</p>";
        echo "<a href='edit.php?id=" . $row['id'] . "'>Edit/Delete</a>";
        echo "</div><hr>";
    }

    $conn->close();
    ?>
</body>
</html>

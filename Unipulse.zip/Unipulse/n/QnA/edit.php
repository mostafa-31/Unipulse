<!DOCTYPE html>
<html>
<head>
    <title>Edit or Delete Q&A</title>
</head>
<body>
    <h1>Edit or Delete Q&A</h1>
    <?php
    $conn = new mysqli('localhost', 'root', '', 'qna_system');

    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        if (isset($_POST['delete'])) {
            $id = (int)$_POST['id'];
            $conn->query("DELETE FROM questions WHERE id=$id");
        } elseif (isset($_POST['update'])) {
            $id = (int)$_POST['id'];
            $question = $conn->real_escape_string($_POST['question']);
            $answer = $conn->real_escape_string($_POST['answer']);
            $conn->query("UPDATE questions SET question='$question', answer='$answer' WHERE id=$id");
        }
    }

    if (isset($_GET['id'])) {
        $id = (int)$_GET['id'];
        $result = $conn->query("SELECT * FROM questions WHERE id=$id");
        $row = $result->fetch_assoc();
        ?>
        <form method="post" action="edit.php">
            <textarea name="question" required><?php echo htmlspecialchars($row['question']); ?></textarea><br>
            <textarea name="answer"><?php echo htmlspecialchars($row['answer']); ?></textarea><br>
            <input type="hidden" name="id" value="<?php echo $row['id']; ?>">
            <input type="submit" name="update" value="Update">
            <input type="submit" name="delete" value="Delete">
        </form>
        <?php
    }

    $conn->close();
    ?>
</body>
</html>

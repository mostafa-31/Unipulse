<?php
    session_start();
    if(!isset($_SESSION['loggedin']) || isset($_SESSION['loggedin'])!=true){
        header("location:index.php");
        exit;
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Unipulse</title>
    <link rel="stylesheet" href="style.css" >
    <link rel="stylesheet" href="QnA\stylr.css" >
     
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.2/css/all.min.css"/>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" integrity="sha512-DTOQO9RWCH3ppGqcWaEA1BIZOC6xxalwEsw9c2QQeAIftl+Vegovlnee1c9QX4TctnWMn13TZye+giMm8e2LwA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
   
</head>
<!-- navigation -->
<body>
   
    <?php include 'header.php';?>
    <!-- content  -->
    <section id="home">
    <div  class="greet">
            <h1>WELCOME <?php echo $_SESSION['username'] ?></h1>
        </div>
        
        <h2>Seize the opportunity presented by <span class="un">UniPulse</span></h2>
        <p>Our motive is to keep you updated providing detail informations about undedergraduation , postgraduation  and Higher studies in reputed universities. </p>
        <div class="link">
            <!-- <a class="bl" href="#">See More</a> -->
            <a class="gr" href="latest_updates.php">Visit latest updates</a>
        </div>
        
    </section>
    <!-- featues  -->
    <section id="feature">
        <h1>Awsome feature</h1>
        <p>Find which is best for you</p>
        <div  class="fea-base">
            <div class="fea-box">
                <a href="scholarship.php">
                <i class="fas fa-graduation-cap"></i>
                <h3>Scholarship Facility</h3> </a>
                <p>Know details about Scholarship</p>
            </div>
            <div class="fea-box">
               <a href="Funi.html"> <i class="fa-solid fa-building-columns"></i></a>
                <h3>Find Suitable University For You</h3>
                <p>Apply now to </p>
            </div>

</div>

    </section>
    <!-- QnA  -->
     <section class="qna" style="padding-left: 58px;">
     <?php include 'QnA\qna.php';?>
     </section>
    <!-- footer  -->
    <?php include 'footer.php';?>
</body>
</html>
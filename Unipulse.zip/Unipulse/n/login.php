<?php
session_start();
if (isset($_SESSION['username'])) {
    header("Location: welcome.php");
}



$login = false;
include('connection.php');
if (isset($_POST['submit'])) {
    $username = $_POST['user'];
    $password = $_POST['pass'];
    $sql = "SELECT * FROM signup WHERE username = '$username' OR email = '$username'";  
    $result = mysqli_query($conn, $sql);  
    $row = mysqli_fetch_array($result, MYSQLI_ASSOC);  
    $count = mysqli_num_rows($result);  
    
    if ($row && password_verify($password, $row["password"])) {  
        $login = true;
        session_start();
        $_SESSION['username'] = $row['username'];
        $_SESSION['loggedin'] = true;
        header("Location: unipulse.php");
    } else {  
        echo '<script>
                  alert("Login failed. Invalid username or password!!");
                  window.location.href = "login.php";
              </script>';
    }     
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="stylesheet" href="logsig.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.2/css/all.min.css"/>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" integrity="sha512-DTOQO9RWCH3ppGqcWaEA1BIZOC6xxalwEsw9c2QQeAIftl+Vegovlnee1c9QX4TctnWMn13TZye+giMm8e2LwA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <title>LogIn</title>
</head>
<body>
    <?php include "header.php"; ?>
    <section class="container forms">
        <div class="form login">
            <h3 class="heading">Login-Form</h3>
            <form name="form" action="login.php" method="POST" class="content">
                <div class="line underline"></div>
                <div class="field input">
                    <input type="text" id="user" name="user" placeholder="Enter your Username/Email" />
                </div>
                <div class="field input">
                    <input type="password" id="pass" name="pass" placeholder="Enter your Password" class="password" />
                    <i class='bx bx-hide hide-show'></i>
                </div>
                <div class="forg">
                    <a href="#" class="forget">Forget password?</a>
                </div>
                <div class="field btn">
                    <input type="submit" id="btn" value="Login" name="submit"/>
                </div>
                <div class="link sign-login">
                    <span>Don't have an Account!</span>
                    <a href="signup.php" class="forget">Sign up</a>
                </div>
                <div class="line"></div>
                <div class="thirdLogin field facebook">
                    <i class='bx bxl-facebook-circle face-icon'></i>
                    <span>Login with facebook</span>
                </div>
                <div class="thirdLogin field google">
                    <i class='bx bxl-google face-icon'></i>
                    <span>Login with google</span>
                </div>
            </form>
        </div>
    </section>
    <script src="./script.js"></script>
    <?php include 'footer.php';?>  
</body>
</html>
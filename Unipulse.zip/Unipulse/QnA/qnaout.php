<?php
session_start(); // Start the session to use session variables

// Assume user is logged in and user_id is stored in session
// In real scenario, you will have login logic here
$_SESSION['user_id'] = 1; // For demonstration, setting user_id to 1

// Database connection
$conn = new mysqli('localhost', 'root', '', 'qna_system');
$user_conn = new mysqli('localhost', 'root', '', 'db'); // Connection to the users database

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($user_conn->connect_error) {
    die("Connection failed: " . $user_conn->connect_error);
}

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_SESSION['user_id'])) {
    $question = $conn->real_escape_string($_POST['question']);
    $user_id = $_SESSION['user_id'];
    
    // Ensure user_id and question are valid before inserting
    if (!empty($question) && !empty($user_id)) {
        $sql = "INSERT INTO questions (question, user_id) VALUES ('$question', $user_id)";
        if ($conn->query($sql) === TRUE) {
            header('Location: qna.php'); // Redirect to the same page to prevent form resubmission
            exit();
        } else {
            echo "Error: " . $sql . "<br>" . $conn->error;
        }
    } else {
        echo "Question cannot be empty.";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Q&A System</title>
    <link rel="stylesheet" href="stylrr.css">
</head>
<body>
    <h1>Ask a Question</h1>
    <form method="post" action="qna.php">
        <textarea name="question" required></textarea><br>
        <input class="bt" type="submit" value="Ask">
    </form>

    <h2><span class='icon'><img src='icons/qna.png' alt='Question'style='
    width: 40px;
    height: 40px;
    margin-right: 10px;'  ></span> <span >Questions and Answers</span></h2>
    <?php
    $result = $conn->query("SELECT q.*, u.username, q.created_at FROM questions q JOIN db.signup u ON q.user_id = u.id ORDER BY q.created_at DESC");
    while ($row = $result->fetch_assoc()) {
        echo "<div class='question-answer'>";
        echo "<p><strong>Username:</strong> " . htmlspecialchars($row['username']) . " <span class='timestamp'>" . htmlspecialchars($row['created_at']) . "</span></p>";
        echo "<p><span class='icon'><img src='icons/question.png' alt='Question'style='
    width: 24px;
    height: 24px;
    margin-right: 1px;
     align-items: center;
    '  ></span> " . htmlspecialchars($row['question']) . "</p>";
    echo "<p><span class='icon'><img src='icons/answer.png' alt='Answer' style='width: 24px; height: 24px; margin-right: 1px;
     align-items: center;
    '></span> <span class='answer-text'>" . htmlspecialchars($row['answer']) . "</span></p>";
        
        echo "</div><hr>";
    }

    $conn->close();
    $user_conn->close();
    ?>
</body>
</html>

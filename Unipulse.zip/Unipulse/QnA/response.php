<!DOCTYPE html>
<html>
<head>
    <title>Respond to Questions</title>
    <style>
        *{
            margin: 0;
            padding: 0;
        }
        body{
            background-color: #f4f4f4;
            padding: 20px;
        }
        h1{
            color: #333;
            margin-bottom: 20px;
        }
        textarea{
            border: none;
            border-bottom: 1px solid #333;
            background-color: transparent;
            padding: 5px;
            width: 30%;
        }
        form{

margin-bottom: 10px;
font-size: 17px;
font-family: 'Times New Roman', Times, serif;
}
form p{
margin-bottom: 10px;
}
        input[type="submit"]{
            margin-top: 10px;
            background-color: green;
            color: #fff;
            padding: 5px 10px;
            border: none;
            cursor: pointer;
            border-radius: 5px;
            margin-bottom: 20px;
            font-size: large;
            font-family: Cambria, Cochin, Georgia, Times, 'Times New Roman', serif;
        }
        input[type="submit"]:hover{
            background-color: #333;
        }
    </style>
</head>
<body>
    <h1>Respond to Questions</h1>
    <?php
    $conn = new mysqli('localhost', 'root', '', 'qna_system');
    $user_conn = new mysqli('localhost', 'root', '', 'db'); // Connection to the users database

    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        $id = (int)$_POST['id'];
        $answer = $conn->real_escape_string($_POST['answer']);
        $conn->query("UPDATE questions SET answer='$answer' WHERE id=$id");
    }

    $result = $conn->query("SELECT q.*, u.username FROM questions q JOIN db.signup u ON q.user_id = u.id WHERE q.answer IS NULL ORDER BY q.created_at DESC");
    while ($row = $result->fetch_assoc()) {
        echo "<form method='post' action='response.php'>";
        echo "<p><strong>Username:</strong> " . htmlspecialchars($row['username']) . "</p>";
        echo "<p><strong>Question:</strong> " . htmlspecialchars($row['question']) . "</p>";
        echo "<textarea name='answer' required></textarea><br>";
        echo "<input type='hidden' name='id' value='" . $row['id'] . "'>";
        echo "<input type='submit' value='Answer'>";
        
    }

    $conn->close();
    $user_conn->close();
    ?>
</body>
</html>

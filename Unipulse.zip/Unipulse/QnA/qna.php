<?php
// session_start(); // Start the session to use session variables

// Database connection
$conn = new mysqli('localhost', 'root', '', 'qna_system');
$user_conn = new mysqli('localhost', 'root', '', 'db'); // Connection to the users database

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($user_conn->connect_error) {
    die("Connection failed: " . $user_conn->connect_error);
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Q&A System</title>
    <link rel="stylesheet" href="stylrr.css">
</head>
<body>
    <h2><span class='icon'><img src='QnA/icons/qna.png' alt='Q&A' style='width: 40px; height: 40px; margin-right: 10px;'></span> <span>Questions and Answers</span></h2>
    <?php
    $result = $conn->query("SELECT q.*, u.username FROM questions q JOIN db.signup u ON q.user_id = u.id ORDER BY q.created_at DESC");
    while ($row = $result->fetch_assoc()) {
        echo "<div class='question-answer'>";
        echo "<p><span class='username'>" . htmlspecialchars($row['username']) . "</span> <span class='timestamp'>" . htmlspecialchars($row['created_at']) . "</span></p>";
        echo "<p><span class='icon'><img src='QnA/icons/question.png' alt='Question' ></span> " . htmlspecialchars($row['question']) . "</p>";
        echo "<p><span class='icon'><img src='QnA/icons/answer.png' alt='Answer' ><span class='answer-text'>" . htmlspecialchars($row['answer']) . "</span></p>";
        echo "<a href='edit.php?id=" . $row['id'] . "'>Edit/Delete</a>";
        echo "</div><hr>";
    }

    $conn->close();
    $user_conn->close();
    ?>
</body>
</html>



<?php
session_start();
if (isset($_SESSION['username'])) {
    unset($_SESSION['username']);
    unset($_SESSION['loggedin']);

    // Echo JavaScript code to show the alert and then redirect
    echo '<script>
              alert("Logout successful!");
              window.location.href = "index.php";
          </script>';
} else {
    // If no user is logged in, just redirect
    header("Location: index.php");
    exit();
}
?>

<!-- session_start();
if (isset($_SESSION['username'])) {
    unset($_SESSION['username']);
    unset($_SESSION['loggedin']);
}

header("Location: index.php");
exit(); -->

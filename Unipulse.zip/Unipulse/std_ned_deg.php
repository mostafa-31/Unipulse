<?php
    session_start();
    if(!isset($_SESSION['loggedin']) || isset($_SESSION['loggedin'])!=true){
        header("location:login.php");
        exit;
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Highlighted Courses and Degree Courses</title>
   <style>
    /* styles.css */
body {
    font-family: Arial, sans-serif;
    line-height: 1.6;
    margin: 0;
    padding: 0;
  
    background-color: #f8f9fa;
}

.containern {
    max-width: 1000px;
    margin: 50px auto;
    padding: 30px;
    background: #fff;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    /* border-radius: 8px; */
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.2);
    margin-top: 108px;
}

h1 {
    color: #333;
    margin-bottom: 20px;
}
.containern p {
    color: #555;
    margin-bottom: 20px;
}
.course-card {
    border: 1px solid #ddd;
    padding: 20px;
    margin-bottom: 20px;
    border-radius: 8px;
}

.course-info {
    display: flex;
    align-items: center;
    
}

.course-info img {
    max-width: 120px;
    max-height: 80px;
    margin-right: 20px;
}

.course-details {
    flex: 1;
}

.course-details a {
    color: #0066cc;
    font-weight: bold;
    text-decoration: none;
}

.course-details a:hover {
    text-decoration: underline;
}

.badge {
    background-color: #e0e0e0;
    border-radius: 12px;
    padding: 3px 8px;
    font-size: 12px;
    margin-left: 10px;
}

.location {
    background-color: #e0e0e0;
    border-radius: 12px;
    padding: 3px 8px;
    font-size: 12px;
}

.button {
    display: inline-block;
    background-color: #007bff;
    color: black;
    padding: 10px 20px;
    text-align: center;
    border-radius: 5px;
    text-decoration: none;
    transition: background-color 0.3s ease;
    margin-top: 10px;
}
.course-details .button {
    color: white;
    
}
.button:hover {
    background-color: #0056b3;
}

.accordion {
    margin-top: 20px;
}

.accordion-item {
    background: #f9f9f9;
    border: 1px solid #ddd;
    border-radius: 5px;
    margin-bottom: 10px;
    overflow: hidden;
}

.accordion-button {
    width: 100%;
    /* color: white; */
    padding: 15px;
    text-align: left;
    background: #f9f9f9;
    border: none;
    cursor: pointer;
    font-size: 16px;
    transition: background-color 0.3s ease;
}

.accordion-button:hover {
    background: #e9e9e9;
}

.accordion-content {
    padding: 15px;
    display: none;
}

   </style>
</head>
<body>
<?php include 'header.php';?>
    <div class="containern">
    <h1>Degrees in the Netherlands</h1>
    <p>In the Netherlands, bachelor’s degrees, also known as undergraduate degrees, are offered across various types of institutions including universities of applied sciences (Hogescholen), research universities, and specialised institutions such as business schools. These bachelor programs, leading to qualifications such as Bachelor of Science (BSc), Bachelor of Arts (BA), Bachelor of Engineering (BEng), and Bachelor of Business Administration (BBA), typically span three to four years</p>
    <p>
    English-taught programs are increasingly common in the Netherlands. However, Dutch remains the primary language for a number of courses, particularly at the undergraduate level. This should be kept in mind when considering your university education in the Netherlands.
    </p>
    <h1>How to Apply for a Degree in the Netherlands</h1>
    <p>
    Applications to universities in the Netherlands for international students can be done either through a centralised system known as ‘Studielink’, or directly to your chosen university. This will depend on the institution’s application 

</p>

<p>

    Required documents usually include a personal statement, a resume or CV, academic transcripts, and proof of language proficiency. For non-native English speakers, language tests like IELTS, TOEFL, or Cambridge English exams are often necessary. Academic requirements may involve a minimum GPA, and maybe specific subjects.
</p>
        <h1>Highlighted courses in The Netherlands</h1>
        <div class="course-card">
            <div class="course-info">
                <img src="https://media.studylink.com/provider/pid-mi-nl-5711/tio-university-of-applied-sciences-logo.webp" alt="Tio Business School">
                <div class="course-details">
                    <a href="https://www.tio.nl/en/international_business_management/?utm_source=studylink&utm_medium=profile&utm_campaign=studylink&utm_content=International%20Business%20Management">International Business Management</a> <span class="badge">BBA</span>
                    <p>Tio Business School <span class="location">Netherlands</span></p>
                    <a href="https://www.tio.nl/en/international_business_management/?utm_source=studylink&utm_medium=profile&utm_campaign=studylink&utm_content=International%20Business%20Management" class="button">Find out more</a>
                </div>
            </div>
        </div>
        <div class="course-card">
            <div class="course-info">
                <img src="https://media.studylink.com/provider/erasmus-school-of-social-and-behavioural-sciences/erasmus-school-of-social-and-behavioural-sciences-logo.webp" alt="Erasmus School of Social and Behavioural Sciences">
                <div class="course-details">
                    <a href="https://www.eur.nl/en/essb/education/find-your-study?utm_source=studylink&utm_medium=profile&utm_campaign=studylink">Clinical Psychology</a> <span class="badge">Master Degree</span>
                    <p>Erasmus School of Social and Behavioural Sciences (ESSB), Erasmus University Rotterdam <span class="location">Netherlands</span></p>
                    <a href="https://www.eur.nl/en/essb/education/find-your-study?utm_source=studylink&utm_medium=profile&utm_campaign=studylink" class="button">Find out more</a>
                </div>
            </div>
        </div>
        <div class="course-card">
            <div class="course-info">
                <img src="https://media.studylink.com/provider/erasmus-school-of-economics/erasmus-school-of-economics-logo.webp" alt="Erasmus School of Economics">
                <div class="course-details">
                    <a href="https://www.eur.nl/en/ese/research-master/research-master-economics?utm_campaign=studylink&utm_content=Economics&utm_medium=profile&utm_source=studylink">Economics</a> <span class="badge">Masters by Research</span>
                    <p>Erasmus School of Economics, Erasmus University Rotterdam <span class="location">Netherlands</span></p>
                    <a href="https://www.eur.nl/en/ese/research-master/research-master-economics?utm_campaign=studylink&utm_content=Economics&utm_medium=profile&utm_source=studylink" class="button">Find out more</a>
                </div>
            </div>
            </div>

            <div class="course-card">
            <div class="course-info">
                <img src="https://media.studylink.com/provider/fontysaci/fontysaci-logo.webpp" alt="Erasmus School of Economics">
                <div class="course-details">
                    <a href="https://www.fontys.nl/en/Study-at-Fontys/Programmes/Trend-Research-Concept-Creation-in-Lifestyle.htm?utm_source=studylink&utm_medium=profile&utm_campaign=studylink&utm_content=Trend%20Research%20&%20Concept%20Creation%20in%20Lifestyle">Trend Research & Concept Creation in Lifestyle</a> <span class="badge">Bachelor Degree</span>
                    <p>Fontys Academy for the Creative Economy<span class="location">Netherlands</span></p>
                    <a href="https://www.fontys.nl/en/Study-at-Fontys/Programmes/Trend-Research-Concept-Creation-in-Lifestyle.htm?utm_source=studylink&utm_medium=profile&utm_campaign=studylink&utm_content=Trend%20Research%20&%20Concept%20Creation%20in%20Lifestyle"class="button">Find out more</a>
                </div>
            </div>
            </div>
            <div class="course-card">
            <div class="course-info">
                <img src="https://media.studylink.com/provider/ic-university-of-applied-sciences/ic-university-of-applied-sciences-logo.webp">
                <div class="course-details">
                    <a href="https://web.ic-university-amsterdam.com/bba-english-international?utm_source=Affiliate&utm_medium=Studylink.com&utm_campaign=Listing">Bachelor of Business Administration</a> <span class="badge">BBA</span>
                    <p>Fontys Academy for the Creative Economy<span class="location">Netherlands</span></p>
                    <a href="https://www.fontys.nl/en/Study-at-Fontys/Programmes/Trend-Research-Concept-Creation-in-Lifestyle.htm?utm_source=studylink&utm_medium=profile&utm_campaign=studylink&utm_content=Trend%20Research%20&%20Concept%20Creation%20in%20Lifestyle"class="button">Find out more</a>
                </div>
            </div>
            </div>
            <div class="course-card">
            <div class="course-info">
                <img src="https://media.studylink.com/provider/amsterdam-tech/amsterdam-tech-logo.webp">
                <div class="course-details">
                    <a href="https://amsterdam.tech/?utm_source=studylink&utm_medium=profile&utm_campaign=studylink">Software Engineering </a> <span class="badge">BSc</span>
                    <p>Amsterdam Tech<span class="location">Netherlands</span></p>
                    <a href="https://amsterdam.tech/?utm_source=studylink&utm_medium=profile&utm_campaign=studylink"class="button">Find out more</a>
                </div>
            </div>
        </div>

        <h1>Degree courses you may be interested in studying in The Netherlands</h1>
        <div class="accordion">
            <div class="accordion-item">
                <button class="accordion-button">Agriculture degree courses in the Netherlands</button>
            </div>
            <div class="accordion-item">
                <button class="accordion-button">Architecture degree courses in the Netherlands</button>
            </div>
            <div class="accordion-item">
                <button class="accordion-button">Humanities degree courses in the Netherlands</button>
            </div>
            <div class="accordion-item">
                <button class="accordion-button">Business degree courses in the Netherlands</button>
            </div>
            <div class="accordion-item">
                <button class="accordion-button">Computing degree courses in the Netherlands</button>
            </div>
            <div class="accordion-item">
                <button class="accordion-button">Creative degree courses in the Netherlands</button>
            </div>
            <div class="accordion-item">
                <button class="accordion-button">Education degree courses in the Netherlands</button>
            </div>
            <div class="accordion-item">
                <button class="accordion-button">Engineering degree courses in the Netherlands</button>
            </div>
            <div class="accordion-item">
                <button class="accordion-button">English degree courses in the Netherlands</button>
            </div>
            <div class="accordion-item">
                <button class="accordion-button">Health degree courses in the Netherlands</button>
            </div>
        </div>
    </div>

    <script >
document.querySelectorAll('.accordion-button').forEach(button => {
    button.addEventListener('click', () => {
        const accordionContent = button.nextElementSibling;

        button.classList.toggle('accordion-button-active');

        if (button.classList.contains('accordion-button-active')) {
            accordionContent.style.display = 'block';
        } else {
            accordionContent.style.display = 'none';
        }
    });
});
</script>
<?php include 'footer.php';?>
</body>
</html>

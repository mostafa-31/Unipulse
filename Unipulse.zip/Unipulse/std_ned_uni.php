<?php
    session_start();
    if(!isset($_SESSION['loggedin']) || isset($_SESSION['loggedin'])!=true){
        header("location:login.php");
        exit;
    }
?>
<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet"  href="style.css">
<style>
body {
  font-family: Arial, Helvetica, sans-serif;
  background-color: #f8f9fa;
}
.conun {
  max-width: 1000px;
  margin: 50px auto;
  padding: 20px;
  background-color: #fff;
  box-shadow: 0 0 10px rgba(0, 0, 0, 0.2);
  margin-top: 108px;
}
.conun h1 {
    font-size: 2.5em;
  color: #333;
  margin-bottom: 30px;
  
}
.conun p {
  line-height: 1.5;
  margin-bottom: 20px;
}


.conun p {
    line-height: 1.6;
  color: #555;
  margin-bottom: 15px;
}

.conun ul {
  list-style-type: disc;
  margin-left: 20px;
}

.conun ul li {
  margin-bottom: 5px;
  color: #555;
}

.conun ul li a {
  color: blue;
  text-decoration: none;
}

.conun ul li a a:hover {
  text-decoration: underline;
}
.conun table {
  font-family: arial, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

.conun td, th {
  border: 1px solid #dddddd;
  text-align: left;
  padding: 8px;
  /* text-decoration: none; */
}
table td a{
    text-decoration: none;
}
.conun tr:nth-child(even) {
  background-color: #dddddd;
}
</style>
</head>
<body>
<?php include 'header.php';?>
<div class="conun">

    <h1>Universities in the Netherlands</h1>
    
    <p>Bordering Germany and Belgium in north-west Europe, the Netherlands is an excellent destination for international students due to its location in Europe, high quality education and interesting history and culture, with plenty of experiences to explore.</p>
    
    <p>The official language spoken in the Netherlands is Dutch, but you will find that many in the country speak English to a good standard, which will help you to get by whilst you pick up the local language.</p>
    
    <h1>Popular cities for students</h1>

<p>Some of the most popular cities in the Netherlands for international students include:</p>

<ul>
  <li><a href="#">Amsterdam</a> - the capital of the Netherlands, home to over 10 universities</li>
  <li><a href="#">Rotterdam</a> - a major port city in the Netherlands, with 6 universities</li>
  <li><a href="#">Utrecht</a> - one of the largest cities in the Netherlands, with 5 universities</li>
  <li><a href="#">Leiden</a> - located in the province of South Holland, with 3 universities</li>
  <li>Groningen - the largest city in the north of the Netherlands, Groningen is home to 3 universities</li>
</ul>
    
<h1>List of universities in The Netherlands</h1>
<p>Browse higher education providers in The Netherlands</p>

<table>
  <tr>
    <!-- <th></th> -->
    <!-- <th></th> -->
  </tr>
  <tr>
    <td><a href="https://www.amsterdamtech.com/">Amsterdam Tech</a></td>
    <td><a href="https://www.auc.nl/">Amsterdam University College (AUC)</a></td>
  </tr>
  <tr>
    <td><a href="https://www.amsterdamuas.com/">Amsterdam University of Applied Sciences</a></td>
    <td><a href="https://www.bsn.nl/">Business School Netherlands</a></td>
  </tr>
  <tr>
    <td><a href="https://www.tudelft.nl/">Delft University of Technology (TU Delft)</a></td>
    <td><a href="https://www.eur.nl/en/essb">Erasmus School of Economics, Erasmus University Rotterdam</a></td>
  </tr>
  <tr>
    <td><a href="https://www.eur.nl/en/essb">Erasmus School of Social and Behavioural Sciences (ESSB), Erasmus University Rotterdam</a></td>
    <td><a href="https://www.eur.nl/en/euc">Erasmus University College, Erasmus University Rotterdam</a></td>
  </tr>
  <tr>
    <td><a href="https://www.eur.nl/en">Erasmus University Rotterdam</a></td>
    <td><a href="https://www.fontys.nl/en/schools/fontys-academy-for-the-creative-economy/">Fontys Academy for the Creative Economy</a></td>
  </tr>
  <tr>
    <td><a href="https://www.fontys.nl/en/schools/fontys-school-of-fine-and-performing-arts/">Fontys Fine and Performing Arts</a></td>
    <td><a href="https://www.fontys.nl/en/">Fontys University of Applied Science</a></td>
  </tr>
  <tr>
    <td><a href="https://www.hasuniversity.nl/en/">HAS green academy</a></td>
    <td><a href="https://www.hotelschoolthehague.com/">Hotelschool The Hague</a></td>
  </tr>
  <tr>
    <td><a href="https://www.hu.nl/en/">HU University of Applied Sciences Utrecht</a></td>
    <td><a href="https://www.icn.nl/en/">IC University of Applied Sciences - Amsterdam</a></td>
  </tr>
  <tr>
    <td><a href="https://www.un-ihe.org/">IHE Delft Institute for Water Education</a></td>
    <td><a href="https://www.inholland.com/en/">Inholland University of Applied Sciences</a></td>
  </tr>
</table>
</div>
    
</body>
</html>

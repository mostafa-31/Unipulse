<?php
    session_start();
    if(!isset($_SESSION['loggedin']) || isset($_SESSION['loggedin'])!=true){
        header("location:login.php");
        exit;
    }
?>
<!DOCTYPE html>
<html>
<head>
<style>
body {
  font-family: Arial, sans-serif;
  margin: 0;
  padding: 0;
  background-color: #7bcd6b91;
}

.why {
    margin-top: 108px;
  max-width: 1000px;
  margin: 50px auto;
  padding: 20px;
  background-color: #fff;
  box-shadow: 0 0 10px rgba(0, 0, 0, 0.7);
}

.why h1 {
  font-size: 2.5em;
  color: #333;
  margin-bottom: 20px;
}

.why p {
  line-height: 1.6;
  color: #555;
  margin-bottom: 15px;
}

.why p a {
  color: #007bff;
  text-decoration: none;
}

.why p a:hover {
  text-decoration: underline;
}

.buttond {
  display: inline-block;
  padding: 10px 20px;
  background-color: #004a45;
  color: #fff;
  border: none;
  border-radius: 5px;
  cursor: pointer;
  margin-right: 10px;
}

.buttond:hover {
  background-color: #00332f;
}
.about {
  display: flex;
  flex-direction: column;
  width: 600px;
  margin: 0 auto;
  padding: 20px;
  border: 1px solid #ccc;
  border-radius: 5px;
  background-color: #f9f9f9;
}
.headera {
  font-size: 24px;
  font-weight: bold;
  margin-bottom: 20px;
}
.info-row {
  display: flex;
  justify-content: space-between;
  margin-bottom: 10px;
}
.info-label {
  font-weight: bold;
}
.info-value {
  text-align: right;
}
a {
  color: blue;
  text-decoration: none;
}
a:hover {
  text-decoration: underline;
}
.qs {
  max-width: 1000px;
  margin: 50px auto;
  padding: 20px;
  background-color: #fff;
  box-shadow: 0 0 10px rgba(0, 0, 0, 0.7);
}
.qs h1 {
  margin-top: 40px;
  font-size: 2.5em;
  color: #333;
  margin-bottom: 20px;
}
.qs h1 {
  margin-top: 40px;
}
.qs  h2 {
  margin-top: 40px;
  color: #331;
}
.qs p {
  margin-bottom: 10px;
    line-height: 1.6;
  color: #555;
  margin-bottom: 15px;
  
}

.qs a {
  color: #007bff;
  text-decoration: none;
}

.qs a:hover {
  text-decoration: underline;
}
.howapp {
  max-width: 1000px;
  margin: 50px auto;
  padding: 20px;
  background-color: #fff;
  box-shadow: 0 0 10px rgba(0, 0, 0, 0.7);
}
.howapp h1 {
  margin-top: 40px;
  font-size: 2.5em;
  color: #333;
  margin-bottom: 20px;
}
.howapp p {
  margin-bottom: 10px;
    line-height: 1.6;
  color: #555;
  margin-bottom: 15px;
  
}
.howapp ul {
  list-style-type: disc;
  margin-left: 20px;
  color: #555;
}
</style>
</head>
<body>
<?php include 'header.php';?>
<div class="why" style="margin-top: 108px;">
  <h1>Why study abroad in the USA</h1>
  <p>Many international students choose to study in the USA each year. It is an incredibly popular choice, and appeals to students who are interested in a variety of subject areas, due to its highly-ranked universities offering well-regarded degrees across the board. Some of the most well-known universities in the USA are members of the Ivy League, which is a group of 8 universities and colleges.</p>
  <p>Higher education is delivered in institutions sometimes referred to as colleges, which are split into two main types. Public colleges are state-funded, have lower tuition fees and a larger capacity for students. Private colleges are funded by donations, tuition fees and grants, meaning that they have higher tuition fees, but fewer students.</p>
  <p>he USA is a very large country, and the experience you have in an east coast state such as Massachusetts will be different to a west coast state like <a href="https://studylink.com/countries/usa/study-in-california/">California</a>. This is an exciting prospect, as the opportunities are endless, with 50 states for you to choose from to take the next step in your international education journey.</p>
  <p>As a European country, the Netherlands follows the Bologna Process and ECTS, meaning that your qualifications will be recognised throughout the rest of Europe. This is useful if you choose to pursue further studies or for your future career.</p>
  <p>TThe east coast has bustling cities like New York, Boston and Chicago, where residents experience all 4 seasons, and have access to places like The Hamptons, Myrtle Beach and Miami. The west coast has cities like <a href="https://studylink.com/countries/usa/universities-in-san-francisco/">San  Francisco</a>, <a href="https://studylink.com/countries/usa/universities-in-los-angeles/">Los Angeles</a>, Portland and Seattle, where you can enjoy beach life in the summer and snowsports in the winter. The areas in the middle of the USA, which are sometimes called the ‘flyover states’, are not to be ignored. From Yellowstone National Park, which straddles Wyoming, Montana and Idaho, to the Grand Canyon in Arizona, there is plenty to be found in the less popular states.</p>
  <a href="std_usa_deg.php"><button class="buttond">Degrees in the USA</button></a>
  <a href="scholarshipusa.php"><button class="buttond">Scholarship in the USA</button></a>
  <a href="std_usa_uni.php"><button class="buttond">All universities in the USA</button></a>
</div>
<div class="why">
  <h1 class="headera">About the USA</h1>
  <div class="info-row">
    <div class="info-label">Continent</div>
    <div class="info-value"><a href="https://en.wikipedia.org/wiki/Europe">Europe</a></div>
  </div>
  <div class="info-row">
    <div class="info-label">Language(s) of tuition</div>
    <div class="info-value">English, Dutch</div>
  </div>
  <div class="info-row">
    <div class="info-label">No of Universities </div>
    <div class="info-value"><a href="https://www.statista.com/statistics/915603/universities-in-the-united-kingdom-uk/#:~:text=There%20were%20288%20higher%20education%20institutions%20in%20the,with%20the%20previous%20year%20when%20there%20were%20295.">288 universities</a></div>
  </div>
  <div class="info-row">
    <div class="info-label">Major Student Cities</div>
    <div class="info-value"><a href="https://studylink.com/countries/usa/universities-in-new-york-city/">Washington D.C. (capital), New York City, San Francisco, Los Angeles</a></div>
  </div>
</div>
<div class="qs">
<h1>Common student questions</h1>

<h2>Can I get free tuition in the USA?</h2>
<p>Can I get free tuition in the USA?
Most universities and colleges in the USA charge tuition fees for international students. However, the resources available for financial aid, such as scholarships and grants, are plentiful. For more information about scholarships in the USA, take a look at our <a href="scholarshipusa.php">How to Get a Scholarship for the USA </a>page.</p>

<h2>Can I study as an international student in the USA?</h2>
<p>The USA is a fantastic country to study in as an international student. Many of the big cities are incredibly diverse, and the universities are highly popular with international students. This popularity means that they will have a large international community waiting to welcome you.</p>

<h2>Do I need IELTS to attend college in the USA?</h2>
<p>If your first language is not English, you will likely have to provide evidence of your English language proficiency. Most universities and colleges in the USA accept TOEFL and IELTS qualifications.</p>

</div>
<div class="howapp">
<h1>How to apply</h1>
<p>Applying to an American university is done either with directly to each university, or through a system such as Common Application or Coalition Application. These allow you to apply to more than one university at a time. You might be required to pay an application fee for each university regardless of how you apply.</p>
<p>Common application requirements for universities in the USA include</p>
<ul>
  <li>High school diploma</li>
  <li>Transcripts</li>
  <li>Standardised test scores (SAT or ACT)</li>
  <li>English language proficiency test scores (TOEFL or IELTS)</li>
  <li>Letters of recommendation</li>
  <li>Recommendation letters</li>
</div>
<div class="howapp">
<h1>Cost of studying in the USA for international students</h1>
<p>The USA uses the USD ($) as its currency.</p>
<p>Tuition fees in the US can vary widely, and are influenced by a range of factors. Public universities, which are funded by state governments, generally offer lower tuition rates for state residents, but international students won’t qualify for these in state rates. This means that international students generally pay out of state tuition fees for public universities.</p>
<p>Private universities, on the other hand, tend to have higher tuition rates, but these rates will sometimes be the same for domestic and international students. Most of the highly prestigious universities and colleges in the US are private, and can charge upwards of $50,000 annually for their programs.</p>
<p>Living costs in the US can also be high, especially in major cities. You should budget for around $10,000 to $20,000 per year for living expenses, depending on your lifestyle and location.</p>
</div>
<div class="howapp">
<h1>Student visa</h1>
<p>If you are an international student looking to study in the USA, you will need to get a valid student visa. The most common visa is the F1 student visa, which is applicable for any degree programs that require more than 18 hours of study per week. You can find more information about USA student visas and how to apply for them, see <a href="https://studylink.com/countries/usa/usa-student-visa-guide/"> USA Student Visa Guide</a>.</p>
</div>
<?php include 'footer.php';?>
</body>
</html>
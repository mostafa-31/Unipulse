<?php
include('connection.php');

$query = "SELECT * FROM signup";
$result = mysqli_query($conn, $query);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Display Users</title>
    <link rel="stylesheet" type="text/css" href="style3.css">
</head>
<body>
    <h1>User Information</h1>
    <table border="1">
        <tr>
            <th>Username</th>
            <th>Email</th>
            <th>Password</th>
        </tr>
        <?php
        while($row = mysqli_fetch_assoc($result)) {
            echo "<tr>";
            echo "<td>".$row['username']."</td>";
            echo "<td>".$row['email']."</td>";
            echo "<td>".$row['password']."</td>";
            echo "</tr>";
        }
        ?>
    </table>
</body>
</html>

<?php
    session_start();
    if(!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] != true){
        header("location:aboutindex.php");
        exit;
    }
?>

<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <meta name="viewport" 
          content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" 
          href="aboutte.css">
          <style>
            .card-email{
                margin-bottom: 29px;
            }
            .button {
    border: none;
    outline: 0;
    padding: 10px;
    margin: 2rem;
    font-size: 1rem;
    color: white;
    background-color: #40b736;
    text-align: center;
    cursor: pointer;
    width: 15rem;
    border-radius: 4px;
    text-decoration: none;
}

.button:hover {
    background-color: #1f9405;
}
          </style>
    <title>About Us</title>
</head>

<body>
    <header>
    <?php include 'header.php';?>
    </header>

    <section class="about">
        <h1>About Us</h1>
        <p style="font-weight: bold">
          Unipulse is a leading platform...
        </p>
        <div class="about-info">
            <div class="about-img">
                <img src="about/about.jpg" alt="Geeksforgeeks">
            </div>
            <div>
            <p>UniPulse.com has helped millions of future college students Scholarship and find the perfect college. We’ve worked with thousands of schools to make sure we have the most up-to-date information and resources for University students around the country. Whether you’re looking for an Academic degree, financial aid, career guides, Admission aid, University rankings, or just plain University information, we’ve got you covered. UniPulse.com is your one stop shop for all things college to help fit your University needs.
            </p>
            <a href="#team"><button>Read More...</button></a>
            </div>
        </div>
    </section>

    <section class="team">
        <h1>Meet Our Team</h1>
        <div class="team-cards">
          
            <!-- Card 1 -->
            <div class="card">
                <div class="card-img">
                    <img src="about/avter.png" alt="User 1">
                </div>
                <div class="card-info">
                    <h2 class="card-name">Mostafa</h2>
                    <p class="card-role">Fontend Developer</p>
                    <p class="card-email">mostafa@gmail.com</p>
                    <p><a href="https://mail.google.com/mail/?view=cm&fs=1&to=mostafa@gmail.com" target="_blank" class="button">Contact</a></p>
                </div>
            </div>

            <!-- Card 2 -->
            <div class="card">
                <div class="card-img">
                    <img src="about/avter.png" alt="User 2">
                </div>
                <div class="card-info">
                    <h2 class="card-name">Shahid</h2>
                    <p class="card-role">Backend Developer</p>
                    <p class="card-email">shahid@gmail.com</p>
                    <p><a href="https://mail.google.com/mail/?view=cm&fs=1&to=shahid@gmail.com" target="_blank" class="button">Contact</a></p>
                </div>
            </div>
          
            <!-- Card 3 -->
            <div class="card">
                <div class="card-img">
                    <img src="about/avter.png" alt="User 3">
                </div>
                <div class="card-info">
                    <h2 class="card-name">Utshab</h2>
                    <p class="card-role">Admin</p>
                    <p class="card-email">Utshab@gmail.com</p>
                    <p><a href="https://mail.google.com/mail/?view=cm&fs=1&to=Utshab@gmail.com" target="_blank" class="button">Contact</a></p>
                </div>
            </div>
        </div>
    </section>

    <?php include 'footer.php';?>
    
</body>

</html>

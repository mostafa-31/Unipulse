<?php
    session_start();
    if(!isset($_SESSION['loggedin']) || isset($_SESSION['loggedin'])!=true){
        header("location:login.php");
        exit;
    }
?>
<!DOCTYPE html>
<html>
<head>
    <title>DU</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" integrity="sha512-SnH5WK+bZxgPHs44uWIX+LLJAJ9/2PkPKZ5QiAj6Ta86w+fsb2TkcmfRyVX3pBnMFcV7oQPJkl9QevSCWr3W6A==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <!-- <link rel="stylesheet" href="cssfile.css"> -->
     <style>
        
/* 1 */
*{
	margin: 0;
	padding: 0;
	box-sizing: border-box;
	font-family: sans-serif;
}
.navbar {
        position: absolute;
        width: 100%;
        top: 0;
        left: 0;
        z-index: 9999; 
    }
/* /1 */

/* 2 */
.slider{
	position: relative;
	width: 100%;
	background: #2c3e50; /* darckblue */
}
.myslide{
	height: 680px;
	display: none;
	overflow: hidden;
}

.prev, .next{
	position: absolute;
	top: 50%;
	transform: translate(0, -50%);
	font-size: 50px;
	padding: 15px;
	cursor: pointer;
	color: #fff;
	transition: 0.1s;
	user-select: none;
}
.prev:hover, .next:hover{
	color: #00a7ff; /* blue */
}
.next{
	right: 0;
}
.dotsbox{
	position: absolute;
	left: 50%;
	transform: translate(-50%);
	bottom: 20px;
	cursor: pointer;
}
.dot{
	display: inline-block;
	width: 15px;
	height: 15px;
	border: 3px solid #fff;
	border-radius: 50%;
	margin: 0 10px;
	cursor: pointer;
}
.overlayr {
    position: absolute;
    width: 100%;
    height: 100%;
    top: 0;
    left: 0;
    background-color: rgba(0, 0, 0, 0.5); /* Darker overlay */
    color: white;
}

.overlayr h2 {
    position: absolute;
    top: 50%;
    left: 50%;
    font-size: 50px;
    font-family: times new roman;
    line-height: 1.5;
    letter-spacing: 1px;
    transform: translate(-50%, -50%);
    text-align: center;
}
/* /2 */

/* javascript */
.active, .dot:hover{
	border-color: #00a7ff; /* blue */
}
/* /javascript */

/* muslide add fade */
.fade {
  -webkit-animation-name: fade;
  -webkit-animation-duration: 1.5s;
  animation-name: fade;
  animation-duration: 1.5s;
}

@-webkit-keyframes fade {
  from {opacity: 0.8}
  to {opacity: 1}
}

@keyframes fade {
  from {opacity: 0.8}
  to {opacity: 1}
}
/* /muslide add fade */

/* 3 */
.txt{
	position: absolute;
	color: #fff;
	letter-spacing: 2px;
	line-height: 35px;
	top: 40%;
	left: 15%;
	-webkit-animation-name: posi;
  	-webkit-animation-duration: 2s;
  	animation-name: posi;
  	animation-duration: 2s;
	z-index: 1;
}

@-webkit-keyframes posi {
  from {left: 25%;}
  to {left: 15%;}
}


@keyframes posi {
  from {left: 25%;}
  to {left: 15%;}
}

/* .txt h1{
	color: #00a7ff; 
	font-size: 50px;
	margin-bottom: 20px;
} */
.txt p{
	font-weight: bold;
	font-size: 20px;
    margin-top: 311px;
   
}
/* /3 */

/* 4 */
img{
	transform: scale(1.5, 1.5);
	-webkit-animation-name: zoomin;
  	-webkit-animation-duration: 40s;
  	animation-name: zoomin;
  	animation-duration: 40s;
}
@-webkit-keyframes zoomin {
  from {transform: scale(1, 1);}
  to {transform: scale(1.5, 1.5);}
}


@keyframes zoomin {
  from {transform: scale(1, 1);}
  to {transform: scale(1.5, 1.5);}
}
/* /4 */



/* 5 */
@media screen and (max-width: 800px){
	.myslide{
		height: 500px;
	}
	.txt p{
		letter-spacing: 2px;
		line-height: 25px;
		top: 50%;
		left: 50%;
		transform: translate(-50%, -50%);
		-webkit-animation-name: posi2;
		-webkit-animation-duration: 2s;
		animation-name: posi2;
		animation-duration: 2s;
	}

	@-webkit-keyframes posi2 {
	  from {top: 35%;}
	  to {top: 50%;}
	}


	@keyframes posi2 {
	  from {top: 35%;}
	  to {top: 50%;}
	}

	.txt h1{
		font-size: 40px;
	}
	.txt p{
		font-size: 13px;
        /* margin-top: 311px; */
	}

}
/* /5 */

/* 6 */
@media screen and (max-width: 520px){
	.txt h1{
		font-size: 30px;
		margin-bottom: 20px;
	}
	.sign{
		margin-right: 20px;
	}
	.sign a{
		font-size: 12px;
	}
}
/* nimber */
.statistics {
    display: flex;
    justify-content: space-around;
    padding: 50px 0;
    background-color: #f4f4f4;
    text-align: center;
}

.stat {
    flex: 1;
    margin: 0 20px;
}

.stat i {
    font-size: 3em;
    color: #333;
    margin-bottom: 10px;
}

.count {
    display: block;
    font-size: 2em;
    font-weight: bold;
    color: #e74c3c;
}

.stat p {
    font-size: 1.2em;
    margin-top: 10px;
    color: #555;
}

.details {
    padding: 70px;
    background-color: white;
    /* text-align: center; */
}

.details h2 {
    font-size: 2em;
    margin-bottom: 20px;
}
.details h3 {
    font-size: 1.5em;
    margin-bottom: 20px;
    text-align: left;
}
.details .intr p {
    font-size: 1.2em;
    line-height: 1.6;
    color:#333;
    justify-content: left;
    align-items: left;
    /* text-align: center; */
    margin-bottom: 40px;
}
.details p {
    font-size: 1.2em;
    line-height: 1.6;
    color:#333;
    justify-content: center;
    text-align: left;
    margin-bottom: 20px;
}
.fact h2 {
    font-size: 2em;
    margin-bottom: 10px;
    padding: 50px;
    background-color: white;
    text-align: center;
}


.acc table {
    width: 100%;
    border-collapse: collapse;
    margin: 20px 0;
    box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
}

.dtails th, td {
    padding: 12px;
    text-align: left;
    border-bottom: 1px solid #ddd;
}

.dtails th {
    background-color: #f2f2f2;
    font-weight: bold;
}

.dtails tr:nth-child(even) {
    background-color: #f9f9f9;
}

.dtails tr:hover {
    background-color: #f1f1f1;
}

.dtails a {
    color: #1a73e8;
    text-decoration: none;
}

.dtails a:hover {
    text-decoration: underline;
}

.dtails td:nth-child(4), .dtails td:nth-child(5), .dtails td:nth-child(6) {
    text-align: center;
}

.dtails td:nth-child(4)::before, .dtails td:nth-child(5)::before, .dtails td:nth-child(6)::before {
    content: '\2713';
    color: green;
    display: inline-block;
    visibility: hidden;
}

td:nth-child(4).check::before,
td:nth-child(5).check::before,
td:nth-child(6).check::before {
    visibility: visible;
}

     </style>
</head>
<body style="height: 2000px;">

<header class="navbar">
<?php include 'header.php';?>
</header> 
    <section class="slider">
   
		<!-- fade css -->
		<div class="myslide fade">
            
			<div class="txt">
				
				<p>DU MOSQUE</p>
			</div>
			<img src="images/du_mosq.jpg" style="width: 100%; height: 100%;">
            <div class="overlayr"><h2>UNIVERSITY OF DHAKA</h2></div>
		</div>
		
		<div class="myslide fade">
			<div class="txt">
				<!-- <h1>IMAGE 2</h1> -->
				<p>DU CARZON HALL</p>
			</div>
			<img src="images/du.jpg" style="width: 100%; height: 100%;">
            <div class="overlayr"><h2>UNIVERSITY OF DHAKA</h2></div>
		</div>
		
		<div class="myslide fade">
            
			<div class="txt">
				
				<p>DU TSC</p>
			</div>
			<img src="images/du_tsc.jpg" style="width: 100%; height: 100%;">
            <div class="overlayr"> <h2>UNIVERSITY OF DHAKA</h2></div>
            
		</div>
       
		<!-- /fade css -->
		
		<!-- onclick js -->
		<a class="prev" onclick="plusSlides(-1)">&#10094;</a>
  		<a class="next" onclick="plusSlides(1)">&#10095;</a>
		
		<div class="dotsbox" style="text-align:center">
			<span class="dot" onclick="currentSlide(1)"></span>
			<span class="dot" onclick="currentSlide(2)"></span>
			<span class="dot" onclick="currentSlide(3)"></span>
			
		</div>
		<!-- /onclick js -->
</section>


	
<script >const myslide = document.querySelectorAll('.myslide'),
	  dot = document.querySelectorAll('.dot');
let counter = 1;
slidefun(counter);

let timer = setInterval(autoSlide, 8000);
function autoSlide() {
	counter += 1;
	slidefun(counter);
}
function plusSlides(n) {
	counter += n;
	slidefun(counter);
	resetTimer();
}
function currentSlide(n) {
	counter = n;
	slidefun(counter);
	resetTimer();
}
function resetTimer() {
	clearInterval(timer);
	timer = setInterval(autoSlide, 8000);
}

function slidefun(n) {
	
	let i;
	for(i = 0;i<myslide.length;i++){
		myslide[i].style.display = "none";
	}
	for(i = 0;i<dot.length;i++) {
		dot[i].className = dot[i].className.replace(' active', '');
	}
	if(n > myslide.length){
	   counter = 1;
	   }
	if(n < 1){
	   counter = myslide.length;
	   }
	myslide[counter - 1].style.display = "block";
	dot[counter - 1].className += " active";
}</script>
   <!--number-->
   <div class="fact"><h2>Facts about DU</h2></div>
   <section class="statistics">
  
    <div class="stat">
        <i class="fas fa-user-graduate"></i>
        <span class="count" data-count="5000">0</span>
        <p>Students</p>
    </div>
    <div class="stat">
        <i class="fas fa-chalkboard-teacher"></i>
        <span class="count" data-count="300">0</span>
        <p>Teachers</p>
    </div>
    <div class="stat">
    <i class="fa-solid fa-building-columns"></i>
        <span class="count" data-count="15">0</span>
        <p>Depertments</p>
    </div>
    <div class="stat">
    <i class="fa-solid fa-map-location-dot"></i>
        <span class="count" data-count="121">0</span>
        <p>ACRES AREA</p>
</section>

<!-- detail -->
<section class="details">
    <h2>About DU</h2>
    <p>DU is committed to providing a high-quality education...</p>
    <div class="intr"><P>The University of Dhaka (Bengali: ঢাকা বিশ্ববিদ্যালয়, romanized: Ḍhākā biśbabidyālaẏa) also known as Dhaka University or DU is a public research university located in Dhaka, Bangladesh. Established in 1921, it is the oldest active university in Bangladesh. The university was founded in 1921 under the Dacca University Act 1920 of the Indian Legislative Council.[6] Nawab Bahadur Sir Khwaja Salimullah, who pioneered the university in Dhaka, donated 600 acres of land from his estate for this purpose.[7][8] It is modeled after British Universities.[9] Currently it is the largest public research university in Bangladesh, with a student body of 46,150 and a faculty of 1,992.</P></div>
    <h3>Libraries</h3>
    <p>The University Library, housed in three separate buildings, is the biggest in Bangladesh. The library holds a collection of more than 617,000 volumes, including bound volumes of periodicals. In addition, it has a collection of over 30,000 manuscripts in other languages and a large number of microfilms, microfiche, and CDs. It subscribes to over 300 foreign journals.[28]

The Dhaka University Library comprises three buildings: The administrative building, the main library building, and the science library building. The administrative building has administrative offices, a book acquisition section, a book processing section, a reprographic section, a bookbinding section, a manuscript section, and a seminar section.[29]

Besides the Faculty of Business Studies of the university has an E-Library which is the largest in the Asia of its kind.[30] This advanced level E-Library is connected with 35 internationally renowned libraries and publication houses in the world. Teachers, students, and researchers can read all journals, books research papers, and articles of these leading libraries, including Dhaka University, Oxford University, and Cambridge University libraries, by using the E-Library facilities.[citation needed]

This e-library was built in collaboration with Robi Axiata Limited in August 2015. It can accommodate around 1400 students altogether. The 12,000 square feet library has three sections: a computer section, a silent zone, and a discussion zone. Some 7,000 students and 208 teachers of the faculty are being directly benefited from the facility. </p>
    <h3>Academic</h3>
    <section class="acc"><table class="departments-table">
        <thead>
            <tr>
                <th>Name of Faculties</th>
                <th>Departments</th>
                <th>Abbrev.</th>
                <th>Undergraduate</th>
                <th>Graduate</th>
                <th>Postgraduate</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td rowspan="4">Faculty of Electrical & Computer Engineering</td>
                <td><a href="#">Electrical and Electronic Engineering</a></td>
                <td>EEE</td>
                <td>&#10004;</td>
                <td>&#10004;</td>
                <td>&#10004;</td>
            </tr>
            <tr>
                <td><a href="#">Computer Science and Engineering</a></td>
                <td>CSE</td>
                <td>&#10004;</td>
                <td>&#10004;</td>
                <td>&#10004;</td>
            </tr>
            <tr>
                <td><a href="#">Electronic & Telecommunication Engineering</a></td>
                <td>ETE</td>
                <td>&#10004;</td>
                <td>&#10004;</td>
                <td></td>
            </tr>
            <tr>
                <td><a href="#">Biomedical Engineering</a></td>
                <td>BME</td>
                <td>&#10004;</td>
                <td></td>
                <td></td>
            </tr>
            <tr>
                <td rowspan="3">Faculty of Civil Engineering</td>
                <td><a href="#">Civil Engineering</a></td>
                <td>CE</td>
                <td>&#10004;</td>
                <td>&#10004;</td>
                <td>&#10004;</td>
            </tr>
            <tr>
                <td><a href="#">Water Resources Engineering</a></td>
                <td>WRE</td>
                <td>&#10004;</td>
                <td></td>
                <td></td>
            </tr>
            <tr>
                <td><a href="#">Disaster & Environmental Engineering</a></td>
                <td>DEE</td>
                <td></td>
                <td>&#10004;</td>
                <td></td>
            </tr>
            <tr>
                <td rowspan="3">Faculty of Mechanical Engineering</td>
                <td><a href="#">Mechanical Engineering</a></td>
                <td>ME</td>
                <td>&#10004;</td>
                <td>&#10004;</td>
                <td>&#10004;</td>
            </tr>
            <tr>
                <td><a href="#">Petroleum & Mining Engineering</a></td>
                <td>PME</td>
                <td>&#10004;</td>
                <td></td>
                <td></td>
            </tr>
            <tr>
                <td><a href="#">Mechatronics and Industrial Engineering</a></td>
                <td>MIE</td>
                <td>&#10004;</td>
                <td></td>
                <td></td>
            </tr>
            <tr>
                <td rowspan="3">Faculty of Architecture & Planning</td>
                <td><a href="#">Architecture</a></td>
                <td>ARCH</td>
                <td>&#10004;</td>
                <td></td>
                <td></td>
            </tr>
            <tr>
                <td><a href="#">Urban & Regional Planning</a></td>
                <td>URP</td>
                <td>&#10004;</td>
                <td></td>
                <td></td>
            </tr>
            <tr>
                <td><a href="#">Humanities</a></td>
                <td>HUM</td>
                <td></td>
                <td></td>
                <td></td>
            </tr>
            <tr>
                <td rowspan="3">Faculty of Engineering & Technology</td>
                <td><a href="#">Physics</a></td>
                <td>PHY</td>
                <td>&#10004;</td>
                <td>&#10004;</td>
                <td></td>
            </tr>
            <tr>
                <td><a href="#">Mathematics</a></td>
                <td>MATH</td>
                <td>&#10004;</td>
                <td>&#10004;</td>
                <td></td>
            </tr>
            <tr>
                <td><a href="#">Chemistry</a></td>
                <td>CHEM</td>
                <td></td>
                <td>&#10004;</td>
                <td></td>
            </tr>
            <tr>
    <td rowspan="4">Faculty of Electrical & Computer Engineering</td>
    <td><a href="#">Electrical and Electronic Engineering</a></td>
    <td>EEE</td>
    <td class="check"></td>
    <td class="check"></td>
    <td class="check"></td>
</tr>
<tr>
    <td><a href="#">Computer Science and Engineering</a></td>
    <td>CSE</td>
    <td class="check"></td>
    <td class="check"></td>
    <td class="check"></td>
</tr>

        </tbody>
    </table></section>
    <h3>Halls of residence</h3>
    <p>There are five men's and three women's dormitories.</p>
    <table border="1" style="margin-bottom: 39px;">
  <tr>
    <th>Male Dormitories</th>
    <th>Total</th>
    <th>Female Dormitories</th>
    <th>Total</th>
  </tr>
  <tr>
    <td>Shaheed Mohammad Shah Hall</td>
    <td></td>
    <td>Sufia Kamal Hall</td>
    <td></td>
  </tr>
  <tr>
    <td>Dr. Qudrat-E-Khuda Hall</td>
    <td></td>
    <td></td>
    <td></td>
  </tr>
  <tr>
    <td>Bangabandhu hall</td>
    <td>5</td>
    <td>Shamsennahar khan Hall</td>
    <td>3</td>
  </tr>
  <tr>
    <td>Shaheed Tareq Huda Hall</td>
    <td></td>
    <td></td>
    <td></td>
  </tr>
  <tr>
    <td>Sheikh Russel Hall</td>
    <td></td>
    <td>Tapashi Rabeya Hall[6]</td>
    <td></td>
  </tr>
</table>
<h3>Transportation</h3>
<p>The university runs its own regular bus service to and from the city for benefit of the students residing there, every office day. Friday and Saturday are weekly holidays. Currently 11 buses are available for students and staffs of the university.</p>
<h3>Medical Center</h3>
<p>The University Medical Center is equipped for primary care, quarantine, sickbed exam appearance, few diagnostics but serious cases are referred to a local hospital 10 kilometers away or to the city hospital. As present, construction of a new building for the medical center is underway. </p>
</section>

<script>
   document.addEventListener("DOMContentLoaded", () => {
    const counters = document.querySelectorAll('.count');
    const speed = 200; // The lower the slower

    counters.forEach(counter => {
        const updateCount = () => {
            const target = +counter.getAttribute('data-count');
            const count = +counter.innerText;

            const inc = target / speed;

            if (count < target) {
                counter.innerText = Math.ceil(count + inc);
                setTimeout(updateCount, 1);
            } else {
                counter.innerText = target;
            }
        };

        updateCount();
    });
});

</script>
<?php include 'footer.php';?>
</body>
</html>


